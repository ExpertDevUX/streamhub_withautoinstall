#!/bin/bash

# Ensure DATABASE_URL is available
if [ -z "$DATABASE_URL" ]; then
  echo "ERROR: DATABASE_URL environment variable is not set"
  exit 1
fi

# Run drizzle-kit push in non-interactive mode
echo "Initializing database schema..."
echo "yes" | npx drizzle-kit push:pg --schema=./shared/schema.ts
echo "Database schema initialized"