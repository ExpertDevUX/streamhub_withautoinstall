#!/bin/bash

# Application Deployment Script for Stream Manager
# This script packages and deploys the Stream Manager application to an EC2 instance

# Color codes for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Set up error handling
set -e

# Parse command line arguments
SSH_KEY=""
EC2_HOST=""
USERNAME="ubuntu"
SOURCE_DIR="."

while [[ $# -gt 0 ]]; do
    case $1 in
        --key)
            SSH_KEY="$2"
            shift 2
            ;;
        --host)
            EC2_HOST="$2"
            shift 2
            ;;
        --username)
            USERNAME="$2"
            shift 2
            ;;
        --source)
            SOURCE_DIR="$2"
            shift 2
            ;;
        *)
            print_message "Unknown parameter: $1" "$RED"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$SSH_KEY" ]; then
    print_message "SSH key file is required. Use --key to specify." "$RED"
    exit 1
fi

if [ -z "$EC2_HOST" ]; then
    print_message "EC2 host (IP or DNS) is required. Use --host to specify." "$RED"
    exit 1
fi

# Check if we can connect to the instance
print_message "Testing SSH connection to $EC2_HOST..." "$BLUE"
if ! ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o ConnectTimeout=10 "$USERNAME@$EC2_HOST" echo "SSH connection successful"; then
    print_message "Failed to connect to $EC2_HOST via SSH. Please check your key file and security group rules." "$RED"
    exit 1
fi

# Create a temporary deploy directory
DEPLOY_DIR=$(mktemp -d)
print_message "Created temporary directory: $DEPLOY_DIR" "$BLUE"

# Copy application files to deployment directory
print_message "Copying application files to deployment directory..." "$BLUE"
rsync -av --exclude='node_modules' --exclude='.git' "$SOURCE_DIR/" "$DEPLOY_DIR/"

# Package the application
print_message "Packaging the application..." "$BLUE"
cd "$DEPLOY_DIR"
tar -czf stream-manager-app.tar.gz ./*

# Create deployment script
cat > deploy-app.sh << 'EOL'
#!/bin/bash

# Set up logging
exec > >(tee /var/log/deploy-app.log) 2>&1
echo "Starting application deployment at $(date)"

# Create application directory
sudo mkdir -p /opt/stream-manager
cd /opt/stream-manager

# Extract application files
echo "Extracting application files..."
sudo tar -xzf ~/stream-manager-app.tar.gz -C /opt/stream-manager/

# Install dependencies
echo "Installing npm dependencies..."
sudo npm install

# Set environment variables
echo "Configuring environment variables..."
sudo bash -c 'cat > /opt/stream-manager/.env << EOF
DATABASE_URL=postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager
NODE_ENV=production
PORT=8080
EOF'

# Run database migrations
echo "Running database migrations..."
sudo npm run db:push

# Create systemd service
echo "Creating systemd service..."
sudo bash -c 'cat > /etc/systemd/system/stream-manager.service << EOF
[Unit]
Description=Stream Manager Application
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stream-manager
ExecStart=/usr/bin/npm run start
Restart=always
Environment=NODE_ENV=production
EnvironmentFile=/opt/stream-manager/.env

[Install]
WantedBy=multi-user.target
EOF'

# Reload systemd and start service
sudo systemctl daemon-reload
sudo systemctl enable stream-manager.service
sudo systemctl start stream-manager.service

# Configure nginx as reverse proxy
sudo bash -c 'cat > /etc/nginx/sites-available/stream-manager << EOF
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF'

# Enable site and restart nginx
sudo ln -sf /etc/nginx/sites-available/stream-manager /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo systemctl restart nginx

# Get public IP address
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

echo "=========================================================="
echo "Stream Manager Application Deployment Complete!"
echo "=========================================================="
echo "Your application is now running at: http://$PUBLIC_IP"
echo "Admin credentials: admin / admin123"
echo "=========================================================="
EOL

# Upload application package and deployment script to EC2
print_message "Uploading application package to $EC2_HOST..." "$BLUE"
scp -i "$SSH_KEY" stream-manager-app.tar.gz "$USERNAME@$EC2_HOST:~/"
scp -i "$SSH_KEY" deploy-app.sh "$USERNAME@$EC2_HOST:~/"

# Execute deployment script on EC2
print_message "Executing deployment script on $EC2_HOST..." "$BLUE"
ssh -i "$SSH_KEY" "$USERNAME@$EC2_HOST" "chmod +x ~/deploy-app.sh && bash ~/deploy-app.sh"

print_message "Application deployment completed!" "$GREEN"
print_message "Your Stream Manager is now running at: http://$EC2_HOST" "$GREEN"
print_message "Admin credentials: admin / admin123" "$GREEN"

# Clean up
rm -rf "$DEPLOY_DIR"

exit 0