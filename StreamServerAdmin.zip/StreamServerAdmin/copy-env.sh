#!/bin/bash

# Script to copy environment variables from .env.production to target system

# Check if target directory is provided
if [ -z "$1" ]; then
  TARGET_DIR="/root/newhub/StreamServerAdmin"
else
  TARGET_DIR="$1"
fi

echo "Copying environment settings to $TARGET_DIR..."

# Check if target directory exists
if [ ! -d "$TARGET_DIR" ]; then
  echo "Target directory does not exist. Creating it..."
  mkdir -p "$TARGET_DIR"
fi

# Copy .env.production file to target as .env
cp .env.production "$TARGET_DIR/.env"

echo "Setting up permissions..."
chmod 600 "$TARGET_DIR/.env"  # Set secure permissions (owner read/write only)

echo "Environment variables have been set up successfully in $TARGET_DIR/.env"
echo "You can now run the application using:"
echo "cd $TARGET_DIR"
echo "npm install"  # Install dependencies
echo "npx tsx init-db.ts"  # Initialize database
echo "npm run dev"  # Start application