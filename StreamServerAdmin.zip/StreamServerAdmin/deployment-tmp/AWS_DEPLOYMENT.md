# Stream Manager Deployment Guide for AWS EC2

This guide provides detailed instructions for deploying the Stream Manager application to an AWS EC2 instance.

## Deployment Methods

There are two main ways to deploy Stream Manager to AWS EC2:

1. **Direct Deployment**: Use the provided `deploy-to-ec2.sh` script to deploy directly from your local machine.
2. **Manual Deployment**: Download the deployment package and install it manually on your EC2 instance.

## Prerequisites

- An AWS EC2 instance (recommended: t2.medium or better)
- Ubuntu 20.04 LTS or newer as the operating system
- SSH access to your EC2 instance
- Security group allowing inbound traffic on ports:
  - 22 (SSH)
  - 80 (HTTP)
  - 443 (HTTPS)
  - 1935 (RTMP) 

## Option 1: Direct Deployment

This method uses the `deploy-to-ec2.sh` script to deploy directly from your local machine.

1. **Download the deployment package**:
   - Download `stream-manager-deploy.tar.gz` and `deploy-to-ec2.sh` to your local machine

2. **Make the deployment script executable**:
   ```bash
   chmod +x deploy-to-ec2.sh
   ```

3. **Run the deployment script**:
   ```bash
   ./deploy-to-ec2.sh --instance-id i-01c8351c620388fc0 --key-file /path/to/your-key.pem --region ap-southeast-1 --username ubuntu
   ```

   Replace the parameters with your specific values:
   - `--instance-id`: Your EC2 instance ID
   - `--key-file`: Path to your private key file (.pem)
   - `--region`: AWS region where your instance is located (default: ap-southeast-1)
   - `--username`: SSH username for your instance (default: ubuntu)

4. **Access the application**:
   After successful deployment, you can access the Stream Manager at:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```

   Use the default admin credentials:
   - Username: admin
   - Password: Check /etc/stream-manager/credentials.conf on your server

## Option 2: Manual Deployment

If you prefer to deploy manually or if the direct deployment method doesn't work for you:

1. **Download the deployment package**:
   - Download `stream-manager-deploy.tar.gz` to your local machine

2. **Copy the package to your EC2 instance**:
   ```bash
   scp -i /path/to/your-key.pem stream-manager-deploy.tar.gz ubuntu@YOUR_EC2_PUBLIC_IP:~
   ```

3. **SSH into your EC2 instance**:
   ```bash
   ssh -i /path/to/your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
   ```

4. **Create a deployment directory and extract the package**:
   ```bash
   mkdir -p ~/stream-manager
   mv ~/stream-manager-deploy.tar.gz ~/stream-manager/
   cd ~/stream-manager
   tar -xzf stream-manager-deploy.tar.gz
   ```

5. **Run the AWS installation script**:
   ```bash
   chmod +x aws-install.sh
   sudo ./aws-install.sh
   ```

   Alternatively, to use the default admin password instead of a random one:
   ```bash
   sudo ./aws-install.sh --default-admin-password
   ```

6. **Access the application**:
   After successful installation, you can access the Stream Manager at:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```

## Post-Deployment Configuration

After deploying the Stream Manager, you should:

1. **Change the default admin password**:
   - Log in with the default admin credentials
   - Go to Settings > User Management
   - Change the admin password to a secure one

2. **Configure HTTPS** (recommended for production):
   - Go to Settings > SSL Configuration
   - Follow the instructions to set up SSL with Let's Encrypt

3. **Configure your RTMP server**:
   - Go to Settings > RTMP Server Configuration
   - Configure your stream settings according to your needs

## Troubleshooting

If you encounter any issues during deployment or while using the Stream Manager:

1. **Check the application logs**:
   ```bash
   sudo journalctl -u stream-manager.service -f
   ```

2. **Check the NGINX logs** (if RTMP streaming issues occur):
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

3. **Restart the service**:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

4. **Verify database connection**:
   ```bash
   grep DATABASE_URL /opt/stream-manager/.env
   sudo -u postgres psql -c "SELECT datname FROM pg_database;"
   ```

5. **Check if RTMP module is installed**:
   ```bash
   sudo nginx -V 2>&1 | grep rtmp
   ```

## Support

If you need further assistance, please contact support at:
- Email: info@hwosecurity.org
- Reference your EC2 instance ID in your support request

---

## Advanced Configuration

### Customizing the Database Connection

To use a different PostgreSQL database:

1. Edit the environment file:
   ```bash
   sudo nano /opt/stream-manager/.env
   ```

2. Update the DATABASE_URL value:
   ```
   DATABASE_URL=postgresql://username:password@hostname:5432/dbname
   ```

3. Restart the service:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

### Setting Up a Domain Name

1. Configure your domain's DNS to point to your EC2 instance's public IP address

2. Update the application URL:
   ```bash
   sudo nano /opt/stream-manager/.env
   ```

3. Add or update the APP_URL:
   ```
   APP_URL=http://your-domain.com
   ```

4. Restart the service:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

5. Set up SSL for your domain via the Stream Manager's SSL Configuration page