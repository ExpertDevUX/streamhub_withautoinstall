#!/bin/bash

# EC2 Auto-Deployment Script for Stream Manager
# This script automatically deploys an EC2 instance with the Stream Manager application

set -e

echo "=========================================================="
echo "  Stream Manager - EC2 Automatic Deployment"
echo "=========================================================="

# Set AWS region
AWS_REGION=${AWS_REGION:-us-west-2}
echo "Using AWS Region: $AWS_REGION"

# Instance configuration
INSTANCE_TYPE="t2.medium"
KEY_NAME="stream-manager-key"
SECURITY_GROUP_NAME="stream-manager-sg"
AMI_ID="ami-0c79a55dda52434da" # Ubuntu 22.04 LTS in us-west-2 (Oregon)

# Stream Manager configuration 
APP_DIRECTORY="/opt/stream-manager"
DATABASE_NAME="stream_manager"
DATABASE_USER="stream_manager"
DATABASE_PASSWORD="stream_manager_pwd"

# Create key pair if it doesn't exist
if ! aws ec2 describe-key-pairs --key-names $KEY_NAME --region $AWS_REGION &> /dev/null; then
    echo "Creating new key pair: $KEY_NAME"
    aws ec2 create-key-pair --key-name $KEY_NAME --query 'KeyMaterial' --output text --region $AWS_REGION > ${KEY_NAME}.pem
    chmod 400 ${KEY_NAME}.pem
    echo "Private key saved to ${KEY_NAME}.pem"
else
    echo "Key pair $KEY_NAME already exists"
fi

# Create security group if it doesn't exist
if ! aws ec2 describe-security-groups --group-names $SECURITY_GROUP_NAME --region $AWS_REGION &> /dev/null; then
    echo "Creating security group: $SECURITY_GROUP_NAME"
    SECURITY_GROUP_ID=$(aws ec2 create-security-group --group-name $SECURITY_GROUP_NAME --description "Security group for Stream Manager" --region $AWS_REGION --query 'GroupId' --output text)
    
    echo "Configuring security group rules"
    # Allow SSH (port 22)
    aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 22 --cidr 0.0.0.0/0 --region $AWS_REGION
    
    # Allow HTTP (port 80)
    aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 80 --cidr 0.0.0.0/0 --region $AWS_REGION
    
    # Allow HTTPS (port 443)
    aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 443 --cidr 0.0.0.0/0 --region $AWS_REGION
    
    # Allow RTMP (port 1935)
    aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 1935 --cidr 0.0.0.0/0 --region $AWS_REGION
    
    # Allow custom port range for applications (8000-9000)
    aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 8000-9000 --cidr 0.0.0.0/0 --region $AWS_REGION
else
    echo "Security group $SECURITY_GROUP_NAME already exists"
    SECURITY_GROUP_ID=$(aws ec2 describe-security-groups --group-names $SECURITY_GROUP_NAME --region $AWS_REGION --query 'SecurityGroups[0].GroupId' --output text)
fi

# Create user data script
cat > user-data.sh << 'EOF'
#!/bin/bash

# Set up logging
exec > >(tee /var/log/user-data.log) 2>&1
echo "Starting Stream Manager installation at $(date)"

# Update system
apt-get update
apt-get upgrade -y

# Install required packages
echo "Installing required packages..."
apt-get install -y curl git postgresql postgresql-contrib nginx build-essential python3-pip unzip

# Install Node.js 20.x
echo "Installing Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# Setup database
echo "Setting up PostgreSQL database..."
systemctl start postgresql
systemctl enable postgresql

# Create database and user
su - postgres -c "psql -c \"CREATE USER stream_manager WITH PASSWORD 'stream_manager_pwd';\""
su - postgres -c "psql -c \"CREATE DATABASE stream_manager;\""
su - postgres -c "psql -c \"GRANT ALL PRIVILEGES ON DATABASE stream_manager TO stream_manager;\""
su - postgres -c "psql -c \"ALTER USER stream_manager WITH SUPERUSER;\""

# Get public IP address
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Clone the repository or download the code
echo "Setting up Stream Manager application..."
mkdir -p /opt/stream-manager
cd /opt/stream-manager

# Create temporary deployment directory
DEPLOY_DIR=$(mktemp -d)
cd $DEPLOY_DIR

# Clone your repository or download the code
# Option 1: Download from S3 bucket (if available)
# aws s3 cp s3://your-bucket/stream-manager.zip .
# unzip stream-manager.zip -d .

# Option 2: Clone from GitHub (if available)
# git clone https://github.com/yourusername/stream-manager.git .

# Option 3: Create a temporary tar file and upload it directly to the server
# For this demo, we'll create the basic structure manually
mkdir -p client/src/{components,hooks,lib,pages}
mkdir -p server
mkdir -p shared

# Create package.json
cat > package.json << 'PKGJSON'
{
  "name": "stream-manager",
  "version": "1.0.0",
  "description": "A powerful video stream server management platform",
  "main": "index.js",
  "scripts": {
    "dev": "tsx server/index.ts",
    "build": "vite build",
    "start": "node dist/index.js",
    "db:push": "drizzle-kit push:pg"
  },
  "dependencies": {
    "@hookform/resolvers": "^3.3.2",
    "@neondatabase/serverless": "^0.6.0",
    "@radix-ui/react-accordion": "^1.1.2",
    "@radix-ui/react-alert-dialog": "^1.0.5",
    "@radix-ui/react-aspect-ratio": "^1.0.3",
    "@radix-ui/react-avatar": "^1.0.4",
    "@radix-ui/react-checkbox": "^1.0.4",
    "@radix-ui/react-collapsible": "^1.0.3",
    "@radix-ui/react-context-menu": "^2.1.5",
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-dropdown-menu": "^2.0.5",
    "@radix-ui/react-hover-card": "^1.0.7",
    "@radix-ui/react-label": "^2.0.2",
    "@radix-ui/react-menubar": "^1.0.4",
    "@radix-ui/react-navigation-menu": "^1.1.4",
    "@radix-ui/react-popover": "^1.0.7",
    "@radix-ui/react-progress": "^1.0.3",
    "@radix-ui/react-radio-group": "^1.1.3",
    "@radix-ui/react-scroll-area": "^1.0.5",
    "@radix-ui/react-select": "^1.2.2",
    "@radix-ui/react-separator": "^1.0.3",
    "@radix-ui/react-slider": "^1.1.2",
    "@radix-ui/react-slot": "^1.0.2",
    "@radix-ui/react-switch": "^1.0.3",
    "@radix-ui/react-tabs": "^1.0.4",
    "@radix-ui/react-toast": "^1.1.5",
    "@radix-ui/react-toggle": "^1.0.3",
    "@radix-ui/react-toggle-group": "^1.0.4",
    "@radix-ui/react-tooltip": "^1.0.7",
    "@tanstack/react-query": "^5.10.0",
    "axios": "^1.6.2",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "cmdk": "^0.2.0",
    "connect-pg-simple": "^9.0.1",
    "date-fns": "^2.30.0",
    "drizzle-orm": "^0.29.0",
    "drizzle-zod": "^0.5.1",
    "embla-carousel-react": "^8.0.0-rc14",
    "express": "^4.18.2",
    "express-session": "^1.17.3",
    "framer-motion": "^10.16.5",
    "hls.js": "^1.4.12",
    "input-otp": "^0.2.1",
    "lucide-react": "^0.292.0",
    "memorystore": "^1.6.7",
    "node-media-server": "^2.6.2",
    "passport": "^0.7.0",
    "passport-local": "^1.0.0",
    "pg": "^8.11.3",
    "react": "^18.2.0",
    "react-day-picker": "^8.9.1",
    "react-dom": "^18.2.0",
    "react-hook-form": "^7.48.2",
    "react-icons": "^4.12.0",
    "react-resizable-panels": "^0.0.55",
    "recharts": "^2.10.1",
    "tailwind-merge": "^2.0.0",
    "tailwindcss-animate": "^1.0.7",
    "vaul": "^0.7.7",
    "vite": "^5.0.2",
    "wouter": "^2.12.1",
    "ws": "^8.14.2",
    "zod": "^3.22.4",
    "zod-validation-error": "^2.1.0"
  },
  "devDependencies": {
    "@types/connect-pg-simple": "^7.0.3",
    "@types/express": "^4.17.21",
    "@types/express-session": "^1.17.10",
    "@types/node": "^20.9.4",
    "@types/passport": "^1.0.16",
    "@types/passport-local": "^1.0.38",
    "@types/react": "^18.2.38",
    "@types/react-dom": "^18.2.17",
    "@types/ws": "^8.5.10",
    "@vitejs/plugin-react": "^4.2.0",
    "autoprefixer": "^10.4.16",
    "drizzle-kit": "^0.20.6",
    "postcss": "^8.4.31",
    "tailwindcss": "^3.3.5",
    "tsx": "^4.5.0",
    "typescript": "^5.3.2"
  }
}
PKGJSON

# Install dependencies
cd /opt/stream-manager
cp -r $DEPLOY_DIR/* .
npm install

# Create necessary files (in a real deployment, these would come from your repo or zip file)

# Create database connection file
cat > server/db.ts << 'EOF'
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from '../shared/schema';

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });
EOF

# Create schema.ts
cat > shared/schema.ts << 'EOF'
import { pgTable, serial, text, boolean, timestamp, integer, primaryKey, varchar, numeric, json } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

export const CLOUD_PROVIDERS = {
  AWS: 'aws',
  DIGITAL_OCEAN: 'digital_ocean',
  OVH: 'ovh',
  SURFCLOUD: 'surfcloud',
} as const;

export const VIDEO_QUALITY = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  ULTRA: 'ultra',
} as const;

export const qualityProfiles = pgTable("quality_profiles", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  resolution: varchar("resolution", { length: 20 }).notNull(),
  bitrate: integer("bitrate").notNull(),
  fps: integer("fps").notNull(),
  quality: varchar("quality", { length: 20 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertQualityProfileSchema = createInsertSchema(qualityProfiles).pick({
  name: true,
  resolution: true,
  bitrate: true,
  fps: true,
  quality: true,
});

// User Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }),
  fullName: varchar("full_name", { length: 255 }),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  isAdmin: true,
});

// Stream Schema
export const streams = pgTable("streams", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  streamKey: varchar("stream_key", { length: 255 }).notNull().unique(),
  userId: integer("user_id").notNull(),
  isLive: boolean("is_live").default(false).notNull(),
  viewers: integer("viewers").default(0).notNull(),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  duration: integer("duration"),
  description: text("description"),
  qualityProfileId: integer("quality_profile_id"),
  recordEnabled: boolean("record_enabled").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertStreamSchema = createInsertSchema(streams).pick({
  name: true,
  streamKey: true,
  userId: true,
  description: true,
  qualityProfileId: true,
  recordEnabled: true,
});

// Server Schema
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  host: varchar("host", { length: 255 }).notNull(),
  port: integer("port").notNull(),
  rtmpPort: integer("rtmp_port").default(1935).notNull(),
  httpPort: integer("http_port").default(80).notNull(),
  status: varchar("status", { length: 50 }).default("offline").notNull(),
  provider: varchar("provider", { length: 50 }),
  region: varchar("region", { length: 50 }),
  instanceType: varchar("instance_type", { length: 50 }),
  config: json("config"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertServerSchema = createInsertSchema(servers).pick({
  name: true,
  host: true,
  port: true,
  rtmpPort: true,
  httpPort: true,
  provider: true,
  region: true,
  instanceType: true,
  config: true,
});

// Activity Schema
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  type: varchar("type", { length: 50 }).notNull(),
  action: varchar("action", { length: 50 }).notNull(),
  details: json("details"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: varchar("user_agent", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  userId: true,
  type: true,
  action: true,
  details: true,
  ipAddress: true,
  userAgent: true,
});

// Integration Schema
export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  config: json("config").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertIntegrationSchema = createInsertSchema(integrations).pick({
  name: true,
  type: true,
  config: true,
  enabled: true,
});

// WPStream Config Schema
export const wpStreamConfigSchema = z.object({
  wpUrl: z.string().url(),
  apiKey: z.string().min(1),
  apiSecret: z.string().min(1),
  syncStreams: z.boolean().default(true),
  syncEvents: z.boolean().default(true),
});

// Cloud Provider Schema
export const cloudProviders = pgTable("cloud_providers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  config: json("config").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCloudProviderSchema = createInsertSchema(cloudProviders).pick({
  userId: true,
  name: true,
  type: true,
  config: true,
  enabled: true,
});

// Bandwidth Allocation Schema
export const bandwidthAllocations = pgTable("bandwidth_allocations", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  streamId: integer("stream_id"),
  allocation: numeric("allocation").notNull(),
  used: numeric("used").default("0").notNull(),
  unit: varchar("unit", { length: 10 }).default("GB").notNull(),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBandwidthAllocationSchema = createInsertSchema(bandwidthAllocations).pick({
  serverId: true,
  streamId: true,
  allocation: true,
  unit: true,
  periodStart: true,
  periodEnd: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stream = typeof streams.$inferSelect;
export type InsertStream = z.infer<typeof insertStreamSchema>;

export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;

export type WpStreamConfig = z.infer<typeof wpStreamConfigSchema>;

export type CloudProvider = typeof cloudProviders.$inferSelect;
export type InsertCloudProvider = z.infer<typeof insertCloudProviderSchema>;

export type BandwidthAllocation = typeof bandwidthAllocations.$inferSelect;
export type InsertBandwidthAllocation = z.infer<typeof insertBandwidthAllocationSchema>;

export type QualityProfile = typeof qualityProfiles.$inferSelect;
export type InsertQualityProfile = z.infer<typeof insertQualityProfileSchema>;

// AWS Config Schema
export const awsConfigSchema = z.object({
  accessKeyId: z.string().min(1),
  secretAccessKey: z.string().min(1),
  region: z.string().min(1),
  bucketName: z.string().optional(),
});

// Digital Ocean Config Schema
export const digitalOceanConfigSchema = z.object({
  apiToken: z.string().min(1),
  region: z.string().min(1),
});

// OVH Config Schema
export const ovhConfigSchema = z.object({
  applicationKey: z.string().min(1),
  applicationSecret: z.string().min(1),
  consumerKey: z.string().min(1),
  endpoint: z.string().min(1),
});

// Surfcloud Config Schema
export const surfcloudConfigSchema = z.object({
  apiKey: z.string().min(1),
  region: z.string().min(1),
});

export type AwsConfig = z.infer<typeof awsConfigSchema>;
export type DigitalOceanConfig = z.infer<typeof digitalOceanConfigSchema>;
export type OvhConfig = z.infer<typeof ovhConfigSchema>;
export type SurfcloudConfig = z.infer<typeof surfcloudConfigSchema>;

// Site Configuration
export const siteConfig = pgTable("site_config", {
  id: serial("id").primaryKey(),
  siteName: varchar("site_name", { length: 255 }).default("Stream Manager").notNull(),
  logo: varchar("logo", { length: 255 }),
  primaryColor: varchar("primary_color", { length: 20 }).default("#4F46E5").notNull(),
  accentColor: varchar("accent_color", { length: 20 }).default("#10B981").notNull(),
  allowRegistration: boolean("allow_registration").default(true).notNull(),
  maintenanceMode: boolean("maintenance_mode").default(false).notNull(),
  footerText: varchar("footer_text", { length: 255 }).default("© 2023 Stream Manager").notNull(),
  maxStreamDuration: integer("max_stream_duration").default(1440).notNull(), // In minutes, default 24 hours
  defaultStreamQuality: varchar("default_stream_quality", { length: 20 }).default("medium").notNull(),
  adminEmail: varchar("admin_email", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSiteConfigSchema = createInsertSchema(siteConfig).pick({
  siteName: true,
  logo: true,
  primaryColor: true,
  accentColor: true,
  allowRegistration: true,
  maintenanceMode: true,
  footerText: true,
  maxStreamDuration: true,
  defaultStreamQuality: true,
  adminEmail: true,
});

export type SiteConfig = typeof siteConfig.$inferSelect;
export type InsertSiteConfig = z.infer<typeof insertSiteConfigSchema>;
EOF

# Create authentication file
cat > server/auth.ts << 'EOF'
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "../shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

async function createDefaultAdminUser() {
  try {
    const existingAdmin = await storage.getUserByUsername("admin");
    if (!existingAdmin) {
      const adminPassword = "admin123";
      await storage.createUser({
        username: "admin",
        password: await hashPassword(adminPassword),
        email: "admin@example.com",
        fullName: "System Administrator",
        isAdmin: true,
      });
      console.log("Default admin user created: admin / admin123");
    }
  } catch (error) {
    console.error("Error creating default admin user:", error);
  }
}

export function setupAuth(app: Express) {
  createDefaultAdminUser();

  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "stream-manager-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }

      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
EOF

# Create storage.ts
cat > server/storage.ts << 'EOF'
import { 
  User, InsertUser, Stream, InsertStream, Server, InsertServer, 
  Activity, InsertActivity, Integration, InsertIntegration,
  CloudProvider, InsertCloudProvider, BandwidthAllocation, InsertBandwidthAllocation,
  SiteConfig, InsertSiteConfig, QualityProfile, InsertQualityProfile
} from "../shared/schema";
import { db } from "./db";
import { eq, desc, and, gt, lt, isNotNull } from "drizzle-orm";
import { users, streams, servers, activities, integrations, cloudProviders, bandwidthAllocations, siteConfig, qualityProfiles } from "../shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Stream methods
  getStream(id: number): Promise<Stream | undefined>;
  getStreamByKey(streamKey: string): Promise<Stream | undefined>;
  createStream(stream: InsertStream): Promise<Stream>;
  updateStream(id: number, stream: Partial<Stream>): Promise<Stream | undefined>;
  deleteStream(id: number): Promise<boolean>;
  getAllStreams(): Promise<Stream[]>;
  getActiveStreams(): Promise<Stream[]>;
  getUserStreams(userId: number): Promise<Stream[]>;
  
  // Server methods
  getServer(id: number): Promise<Server | undefined>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: number, server: Partial<Server>): Promise<Server | undefined>;
  deleteServer(id: number): Promise<boolean>;
  getAllServers(): Promise<Server[]>;
  
  // Activity methods
  getActivity(id: number): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getAllActivities(limit?: number): Promise<Activity[]>;
  
  // Integration methods
  getIntegration(id: number): Promise<Integration | undefined>;
  getIntegrationByType(type: string): Promise<Integration | undefined>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, integration: Partial<Integration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<boolean>;
  getAllIntegrations(): Promise<Integration[]>;
  getEnabledIntegrations(): Promise<Integration[]>;
  
  // Cloud Provider methods
  getCloudProvider(id: number): Promise<CloudProvider | undefined>;
  createCloudProvider(provider: InsertCloudProvider): Promise<CloudProvider>;
  updateCloudProvider(id: number, provider: Partial<CloudProvider>): Promise<CloudProvider | undefined>;
  deleteCloudProvider(id: number): Promise<boolean>;
  getAllCloudProviders(): Promise<CloudProvider[]>;
  getUserCloudProviders(userId: number): Promise<CloudProvider[]>;
  getCloudProviderByType(type: string): Promise<CloudProvider | undefined>;
  
  // Bandwidth Allocation methods
  getBandwidthAllocation(id: number): Promise<BandwidthAllocation | undefined>;
  createBandwidthAllocation(allocation: InsertBandwidthAllocation): Promise<BandwidthAllocation>;
  updateBandwidthAllocation(id: number, allocation: Partial<BandwidthAllocation>): Promise<BandwidthAllocation | undefined>;
  deleteBandwidthAllocation(id: number): Promise<boolean>;
  getAllBandwidthAllocations(): Promise<BandwidthAllocation[]>;
  getServerBandwidthAllocations(serverId: number): Promise<BandwidthAllocation[]>;
  getStreamBandwidthAllocation(streamId: number): Promise<BandwidthAllocation | undefined>;

  // Site Configuration methods
  getSiteConfig(): Promise<SiteConfig | undefined>;
  updateSiteConfig(config: Partial<SiteConfig>): Promise<SiteConfig | undefined>;
  
  // Quality Profile methods
  getQualityProfile(id: number): Promise<QualityProfile | undefined>;
  createQualityProfile(profile: InsertQualityProfile): Promise<QualityProfile>;
  updateQualityProfile(id: number, profile: Partial<QualityProfile>): Promise<QualityProfile | undefined>;
  deleteQualityProfile(id: number): Promise<boolean>;
  getAllQualityProfiles(): Promise<QualityProfile[]>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: 'session' 
    });
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Initialize default data like quality profiles or site config
      const existingProfiles = await this.getAllQualityProfiles();
      if (existingProfiles.length === 0) {
        // Create default quality profiles
        await this.createQualityProfile({
          name: "Low Quality (480p)",
          resolution: "854x480",
          bitrate: 1000,
          fps: 30,
          quality: "low"
        });
        
        await this.createQualityProfile({
          name: "Medium Quality (720p)",
          resolution: "1280x720",
          bitrate: 2500,
          fps: 30,
          quality: "medium"
        });
        
        await this.createQualityProfile({
          name: "High Quality (1080p)",
          resolution: "1920x1080",
          bitrate: 5000,
          fps: 60,
          quality: "high"
        });
        
        await this.createQualityProfile({
          name: "Ultra Quality (1440p)",
          resolution: "2560x1440",
          bitrate: 8000,
          fps: 60,
          quality: "ultra"
        });
      }

      // Create default site config if not exists
      const config = await this.getSiteConfig();
      if (!config) {
        await db.insert(siteConfig).values({
          siteName: "Stream Manager",
          primaryColor: "#4F46E5",
          accentColor: "#10B981",
          allowRegistration: true,
          maintenanceMode: false,
          footerText: "© 2023 Stream Manager",
          maxStreamDuration: 1440,
          defaultStreamQuality: "medium",
          adminEmail: "admin@example.com"
        });
      }

      // Create default server if none exists
      const servers = await this.getAllServers();
      if (servers.length === 0) {
        await this.createServer({
          name: "Default RTMP Server",
          host: "localhost",
          port: 8000,
          rtmpPort: 1935,
          httpPort: 80,
          provider: "local",
          region: "local",
          instanceType: "local",
          config: {}
        });
      }
    } catch (error) {
      console.error("Error initializing default data:", error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users)
      .set({...userData, updatedAt: new Date()})
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return result.count > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getStream(id: number): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).where(eq(streams.id, id));
    return stream;
  }

  async getStreamByKey(streamKey: string): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).where(eq(streams.streamKey, streamKey));
    return stream;
  }

  async createStream(insertStream: InsertStream): Promise<Stream> {
    const [stream] = await db.insert(streams).values(insertStream).returning();
    return stream;
  }

  async updateStream(id: number, streamData: Partial<Stream>): Promise<Stream | undefined> {
    const [stream] = await db.update(streams)
      .set({...streamData, updatedAt: new Date()})
      .where(eq(streams.id, id))
      .returning();
    return stream;
  }

  async deleteStream(id: number): Promise<boolean> {
    const result = await db.delete(streams).where(eq(streams.id, id));
    return result.count > 0;
  }

  async getAllStreams(): Promise<Stream[]> {
    return await db.select().from(streams);
  }

  async getActiveStreams(): Promise<Stream[]> {
    return await db.select().from(streams).where(eq(streams.isLive, true));
  }

  async getUserStreams(userId: number): Promise<Stream[]> {
    return await db.select().from(streams).where(eq(streams.userId, userId));
  }

  async getServer(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }

  async createServer(insertServer: InsertServer): Promise<Server> {
    const [server] = await db.insert(servers).values(insertServer).returning();
    return server;
  }

  async updateServer(id: number, serverData: Partial<Server>): Promise<Server | undefined> {
    const [server] = await db.update(servers)
      .set({...serverData, updatedAt: new Date()})
      .where(eq(servers.id, id))
      .returning();
    return server;
  }

  async deleteServer(id: number): Promise<boolean> {
    const result = await db.delete(servers).where(eq(servers.id, id));
    return result.count > 0;
  }

  async getAllServers(): Promise<Server[]> {
    return await db.select().from(servers);
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db.insert(activities).values(insertActivity).returning();
    return activity;
  }

  async getAllActivities(limit?: number): Promise<Activity[]> {
    let query = db.select().from(activities).orderBy(desc(activities.createdAt));
    if (limit) {
      query = query.limit(limit);
    }
    return await query;
  }

  async getIntegration(id: number): Promise<Integration | undefined> {
    const [integration] = await db.select().from(integrations).where(eq(integrations.id, id));
    return integration;
  }

  async getIntegrationByType(type: string): Promise<Integration | undefined> {
    const [integration] = await db.select().from(integrations).where(eq(integrations.type, type));
    return integration;
  }

  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const [integration] = await db.insert(integrations).values(insertIntegration).returning();
    return integration;
  }

  async updateIntegration(id: number, integrationData: Partial<Integration>): Promise<Integration | undefined> {
    const [integration] = await db.update(integrations)
      .set({...integrationData, updatedAt: new Date()})
      .where(eq(integrations.id, id))
      .returning();
    return integration;
  }

  async deleteIntegration(id: number): Promise<boolean> {
    const result = await db.delete(integrations).where(eq(integrations.id, id));
    return result.count > 0;
  }

  async getAllIntegrations(): Promise<Integration[]> {
    return await db.select().from(integrations);
  }

  async getEnabledIntegrations(): Promise<Integration[]> {
    return await db.select().from(integrations).where(eq(integrations.enabled, true));
  }

  async getCloudProvider(id: number): Promise<CloudProvider | undefined> {
    const [provider] = await db.select().from(cloudProviders).where(eq(cloudProviders.id, id));
    return provider;
  }

  async createCloudProvider(provider: InsertCloudProvider): Promise<CloudProvider> {
    const [cloudProvider] = await db.insert(cloudProviders).values(provider).returning();
    return cloudProvider;
  }

  async updateCloudProvider(id: number, provider: Partial<CloudProvider>): Promise<CloudProvider | undefined> {
    const [cloudProvider] = await db.update(cloudProviders)
      .set({...provider, updatedAt: new Date()})
      .where(eq(cloudProviders.id, id))
      .returning();
    return cloudProvider;
  }

  async deleteCloudProvider(id: number): Promise<boolean> {
    const result = await db.delete(cloudProviders).where(eq(cloudProviders.id, id));
    return result.count > 0;
  }

  async getAllCloudProviders(): Promise<CloudProvider[]> {
    return await db.select().from(cloudProviders);
  }

  async getUserCloudProviders(userId: number): Promise<CloudProvider[]> {
    return await db.select().from(cloudProviders).where(eq(cloudProviders.userId, userId));
  }

  async getCloudProviderByType(type: string): Promise<CloudProvider | undefined> {
    const [provider] = await db.select().from(cloudProviders).where(eq(cloudProviders.type, type));
    return provider;
  }

  async getBandwidthAllocation(id: number): Promise<BandwidthAllocation | undefined> {
    const [allocation] = await db.select().from(bandwidthAllocations).where(eq(bandwidthAllocations.id, id));
    return allocation;
  }

  async createBandwidthAllocation(allocation: InsertBandwidthAllocation): Promise<BandwidthAllocation> {
    const [bandwidthAllocation] = await db.insert(bandwidthAllocations).values(allocation).returning();
    return bandwidthAllocation;
  }

  async updateBandwidthAllocation(id: number, allocation: Partial<BandwidthAllocation>): Promise<BandwidthAllocation | undefined> {
    const [bandwidthAllocation] = await db.update(bandwidthAllocations)
      .set({...allocation, updatedAt: new Date()})
      .where(eq(bandwidthAllocations.id, id))
      .returning();
    return bandwidthAllocation;
  }

  async deleteBandwidthAllocation(id: number): Promise<boolean> {
    const result = await db.delete(bandwidthAllocations).where(eq(bandwidthAllocations.id, id));
    return result.count > 0;
  }

  async getAllBandwidthAllocations(): Promise<BandwidthAllocation[]> {
    return await db.select().from(bandwidthAllocations);
  }

  async getServerBandwidthAllocations(serverId: number): Promise<BandwidthAllocation[]> {
    return await db.select().from(bandwidthAllocations).where(eq(bandwidthAllocations.serverId, serverId));
  }

  async getStreamBandwidthAllocation(streamId: number): Promise<BandwidthAllocation | undefined> {
    const [allocation] = await db.select().from(bandwidthAllocations).where(eq(bandwidthAllocations.streamId, streamId));
    return allocation;
  }

  async getSiteConfig(): Promise<SiteConfig | undefined> {
    const configs = await db.select().from(siteConfig);
    return configs[0];
  }

  async updateSiteConfig(configData: Partial<SiteConfig>): Promise<SiteConfig | undefined> {
    const configs = await db.select().from(siteConfig);
    if (configs.length === 0) {
      const [config] = await db.insert(siteConfig).values({
        ...configData,
        siteName: configData.siteName || "Stream Manager",
        primaryColor: configData.primaryColor || "#4F46E5",
        accentColor: configData.accentColor || "#10B981",
        allowRegistration: configData.allowRegistration !== undefined ? configData.allowRegistration : true,
        maintenanceMode: configData.maintenanceMode !== undefined ? configData.maintenanceMode : false,
        footerText: configData.footerText || "© 2023 Stream Manager",
        maxStreamDuration: configData.maxStreamDuration || 1440,
        defaultStreamQuality: configData.defaultStreamQuality || "medium"
      }).returning();
      return config;
    } else {
      const [config] = await db.update(siteConfig)
        .set({...configData, updatedAt: new Date()})
        .where(eq(siteConfig.id, configs[0].id))
        .returning();
      return config;
    }
  }

  async getQualityProfile(id: number): Promise<QualityProfile | undefined> {
    const [profile] = await db.select().from(qualityProfiles).where(eq(qualityProfiles.id, id));
    return profile;
  }

  async createQualityProfile(profile: InsertQualityProfile): Promise<QualityProfile> {
    const [qualityProfile] = await db.insert(qualityProfiles).values(profile).returning();
    return qualityProfile;
  }

  async updateQualityProfile(id: number, profile: Partial<QualityProfile>): Promise<QualityProfile | undefined> {
    const [qualityProfile] = await db.update(qualityProfiles)
      .set({...profile, updatedAt: new Date()})
      .where(eq(qualityProfiles.id, id))
      .returning();
    return qualityProfile;
  }

  async deleteQualityProfile(id: number): Promise<boolean> {
    const result = await db.delete(qualityProfiles).where(eq(qualityProfiles.id, id));
    return result.count > 0;
  }

  async getAllQualityProfiles(): Promise<QualityProfile[]> {
    return await db.select().from(qualityProfiles);
  }
}

export const storage = new DatabaseStorage();
EOF

# Create server/index.ts file
cat > server/index.ts << 'EOF'
import express, { Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite } from "./vite";
import { log } from "./vite";
import dotenv from "dotenv";
import { migrate } from "./migrate";

dotenv.config();

async function main() {
  const app = express();
  app.use(express.json());

  // Middleware to log requests
  app.use((req, res, next) => {
    log(`${req.method} ${req.url}`);
    next();
  });

  // Run database migrations
  try {
    await migrate();
  } catch (err) {
    console.error("Migration error:", err);
  }

  // Register API routes
  const server = await registerRoutes(app);

  // Set up the Vite development server or serve the static files
  await setupVite(app, server);

  // Error handling middleware
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err.stack);
    const statusCode = err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(statusCode).json({ error: message });
  });

  const port = process.env.PORT || 3000;

  server.listen(port, "0.0.0.0", () => {
    log(`Server running on http://0.0.0.0:${port}`);
  });
}

main().catch((error) => {
  console.error("Server error:", error);
  process.exit(1);
});
EOF

# Create routes.ts
cat > server/routes.ts << 'EOF'
import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createActivity } from "./migrate";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Create HTTP server
  const httpServer = createServer(app);

  // Create WebSocket server on the same server but different path
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    console.log('Client connected');
    
    // Send initial data
    ws.send(JSON.stringify({
      type: 'server_metrics',
      data: {
        cpu: Math.random() * 100,
        memory: Math.random() * 100,
        network: {
          in: Math.random() * 1000,
          out: Math.random() * 1000
        },
        storage: Math.random() * 100,
        activeStreams: Math.floor(Math.random() * 10),
        uptime: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 86400)
      }
    }));

    // Send periodic updates
    const intervalId = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'server_metrics',
          data: {
            cpu: Math.random() * 100,
            memory: Math.random() * 100,
            network: {
              in: Math.random() * 1000,
              out: Math.random() * 1000
            },
            storage: Math.random() * 100,
            activeStreams: Math.floor(Math.random() * 10),
            uptime: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 86400)
          }
        }));
      }
    }, 5000);

    ws.on('close', () => {
      clearInterval(intervalId);
      console.log('Client disconnected');
    });

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);

        // Handle specific message types
        if (data.type === 'request_metrics') {
          // Send requested metrics
          ws.send(JSON.stringify({
            type: 'server_metrics',
            data: {
              cpu: Math.random() * 100,
              memory: Math.random() * 100,
              network: {
                in: Math.random() * 1000,
                out: Math.random() * 1000
              },
              storage: Math.random() * 100,
              activeStreams: Math.floor(Math.random() * 10),
              uptime: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 86400)
            }
          }));
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });
  });

  // Simple stream management API
  app.get('/api/streams', (req, res) => {
    // Return a list of streams
    res.json([
      { id: 1, name: 'Main Stream', status: 'live', viewers: 120 },
      { id: 2, name: 'Secondary Stream', status: 'offline', viewers: 0 },
      { id: 3, name: 'Test Stream', status: 'live', viewers: 45 }
    ]);
  });

  app.get('/api/rtmp/status/:id', (req, res) => {
    // Return status of RTMP server
    const id = parseInt(req.params.id);
    res.json({
      id: id,
      name: 'Default RTMP Server',
      host: 'localhost',
      port: 1935,
      status: 'online',
      cpu: Math.random() * 100,
      memory: Math.random() * 100,
      network: {
        in: Math.random() * 1000,
        out: Math.random() * 1000
      },
      streams: Math.floor(Math.random() * 10),
      uptime: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 86400)
    });
  });

  app.get('/api/system/info', (req, res) => {
    res.json({
      version: '1.0.0',
      platform: process.platform,
      nodejs: process.version,
      uptime: process.uptime(),
      memory: process.memoryUsage()
    });
  });

  return httpServer;
}
EOF

# Create migrate.ts
cat > server/migrate.ts << 'EOF'
import { pool } from "./db";
import { storage } from "./storage";

/**
 * This script handles database migrations without interactive prompts
 * It checks for missing columns and adds them if needed
 */
export async function migrate() {
  console.log("Running database migrations...");
  
  try {
    // Check for required tables
    await checkTableExists('users');
    await checkTableExists('streams');
    await checkTableExists('servers');
    await checkTableExists('activities');
    await checkTableExists('integrations');
    await checkTableExists('cloud_providers');
    await checkTableExists('bandwidth_allocations');
    await checkTableExists('quality_profiles');
    await checkTableExists('site_config');

    // Create default quality profiles
    await createDefaultQualityProfiles();
    
    // Create default site config
    await createDefaultSiteConfig();
    
    // Create activity log entry
    await createActivity({
      type: 'system',
      action: 'migration',
      details: {
        message: 'Database migration completed successfully'
      }
    });
    
    console.log("Database migrations completed successfully.");
  } catch (error) {
    console.error("Error during migration:", error);
    throw error;
  }
}

export async function createActivity(activity: any) {
  try {
    await storage.createActivity({
      userId: activity.userId || null,
      type: activity.type,
      action: activity.action,
      details: activity.details || {},
      ipAddress: activity.ipAddress || null,
      userAgent: activity.userAgent || null
    });
  } catch (error) {
    console.error("Error creating activity log:", error);
  }
}

async function checkTableExists(tableName: string): Promise<boolean> {
  try {
    const result = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = $1
      );
    `, [tableName]);
    
    const exists = result.rows[0].exists;
    
    if (!exists) {
      console.log(`Table ${tableName} does not exist. It will be created by Drizzle ORM.`);
    }
    
    return exists;
  } catch (error) {
    console.error(`Error checking if table ${tableName} exists:`, error);
    return false;
  }
}

async function createDefaultQualityProfiles() {
  try {
    const profiles = await storage.getAllQualityProfiles();
    
    if (profiles.length === 0) {
      console.log("Creating default quality profiles...");
      
      await storage.createQualityProfile({
        name: "Low Quality (480p)",
        resolution: "854x480",
        bitrate: 1000,
        fps: 30,
        quality: "low"
      });
      
      await storage.createQualityProfile({
        name: "Medium Quality (720p)",
        resolution: "1280x720",
        bitrate: 2500,
        fps: 30,
        quality: "medium"
      });
      
      await storage.createQualityProfile({
        name: "High Quality (1080p)",
        resolution: "1920x1080",
        bitrate: 5000,
        fps: 60,
        quality: "high"
      });
      
      await storage.createQualityProfile({
        name: "Ultra Quality (1440p)",
        resolution: "2560x1440",
        bitrate: 8000,
        fps: 60,
        quality: "ultra"
      });
      
      console.log("Default quality profiles created successfully.");
    }
  } catch (error) {
    console.error("Error creating default quality profiles:", error);
  }
}

async function createDefaultSiteConfig() {
  try {
    const config = await storage.getSiteConfig();
    
    if (!config) {
      console.log("Creating default site configuration...");
      
      await storage.updateSiteConfig({
        siteName: "Stream Manager",
        primaryColor: "#4F46E5",
        accentColor: "#10B981",
        allowRegistration: true,
        maintenanceMode: false,
        footerText: "© 2023 Stream Manager",
        maxStreamDuration: 1440,
        defaultStreamQuality: "medium",
        adminEmail: "admin@example.com"
      });
      
      console.log("Default site configuration created successfully.");
    }
  } catch (error) {
    console.error("Error creating default site configuration:", error);
  }
}
EOF

# Create vite.ts
cat > server/vite.ts << 'EOF'
import { Express } from "express";
import { Server } from "http";
import path from "path";
import fs from "fs";

export function log(message: string, source = "express") {
  const timestamp = new Date().toLocaleTimeString();
  console.log(`${timestamp} [${source}] ${message}`);
}

export async function setupVite(app: Express, server: Server) {
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    // In development, we would set up the Vite dev server here
    // For this demo, we'll just serve static files
    serveStatic(app);
  }
}

export function serveStatic(app: Express) {
  const clientDistPath = path.resolve(__dirname, "../client/dist");
  
  // Check if the client dist directory exists
  if (fs.existsSync(clientDistPath)) {
    app.use(express.static(clientDistPath));
    
    // Serve index.html for all routes except API routes
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api/")) {
        return next();
      }
      res.sendFile(path.join(clientDistPath, "index.html"));
    });
    
    log(`Serving static files from ${clientDistPath}`);
  } else {
    log(`Client dist directory not found at ${clientDistPath}`, "error");
  }
}
EOF

# Create drizzle.config.ts
cat > drizzle.config.ts << 'EOF'
import type { Config } from "drizzle-kit";
import * as dotenv from "dotenv";
dotenv.config();

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is not set");
}

export default {
  schema: "./shared/schema.ts",
  driver: "pg",
  dbCredentials: {
    connectionString: process.env.DATABASE_URL,
  },
  verbose: true,
} satisfies Config;
EOF

# Create environment file with configuration
cat > .env << 'EOF'
# Database configuration
DATABASE_URL=postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager

# Application settings
PORT=3000
NODE_ENV=production
SESSION_SECRET=stream-manager-secret-key

# Get the public IP from metadata
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
APP_URL=http://$PUBLIC_IP

# AWS credentials (if needed)
# AWS_ACCESS_KEY_ID=
# AWS_SECRET_ACCESS_KEY=
# AWS_REGION=
EOF

# Create the systemd service
cat > /etc/systemd/system/stream-manager.service << 'EOF'
[Unit]
Description=Stream Manager Service
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stream-manager
EnvironmentFile=/opt/stream-manager/.env
ExecStart=/usr/bin/npm run start
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create the credentials file
mkdir -p /etc/stream-manager
echo "admin:admin123" > /etc/stream-manager/credentials.conf
chmod 600 /etc/stream-manager/credentials.conf

# Build the application
cd /opt/stream-manager
npm run build

# Enable and start the service
systemctl daemon-reload
systemctl enable stream-manager
systemctl start stream-manager

# Get public IP
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Print installation summary
echo "=========================================================="
echo "Stream Manager Installation Complete!"
echo "=========================================================="
echo "Admin Dashboard URL: http://$PUBLIC_IP"
echo "Login Credentials:"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo "RTMP Server: rtmp://$PUBLIC_IP:1935/live"
echo "Stream Key: Use the stream key generated in the dashboard"
echo ""
echo "Credentials stored in: /etc/stream-manager/credentials.conf"
echo "=========================================================="
EOF

# Launch the instance
echo "Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances \
  --image-id $AMI_ID \
  --instance-type $INSTANCE_TYPE \
  --key-name $KEY_NAME \
  --security-group-ids $SECURITY_GROUP_ID \
  --user-data file://user-data.sh \
  --region $AWS_REGION \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=StreamManager}]" \
  --query 'Instances[0].InstanceId' \
  --output text)

if [ -z "$INSTANCE_ID" ]; then
    echo "Failed to launch instance"
    exit 1
fi

echo "Instance $INSTANCE_ID launching..."
echo "Waiting for instance to be running..."

aws ec2 wait instance-running --instance-ids $INSTANCE_ID --region $AWS_REGION

echo "Instance is running. Waiting for initialization..."
sleep 30

# Get instance public IP
PUBLIC_IP=$(aws ec2 describe-instances \
  --instance-ids $INSTANCE_ID \
  --region $AWS_REGION \
  --query 'Reservations[0].Instances[0].PublicIpAddress' \
  --output text)

echo "=========================================================="
echo "Stream Manager EC2 Instance Deployed"
echo "=========================================================="
echo "Instance ID: $INSTANCE_ID"
echo "Public IP: $PUBLIC_IP"
echo "Access the dashboard at: http://$PUBLIC_IP"
echo ""
echo "Login Credentials:"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo "RTMP Server: rtmp://$PUBLIC_IP:1935/live"
echo ""
echo "To SSH into the instance:"
echo "  ssh -i ${KEY_NAME}.pem ubuntu@$PUBLIC_IP"
echo ""
echo "The installation process is still running on the server."
echo "It may take 5-10 minutes for the application to be fully operational."
echo "Check the installation log on the server: /var/log/user-data.log"
echo "=========================================================="