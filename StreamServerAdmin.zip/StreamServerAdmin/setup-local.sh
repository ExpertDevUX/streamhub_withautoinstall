#!/bin/bash

# Stream Manager Local Setup Script
# This script helps set up the Stream Manager application in a local environment

echo "Setting up Stream Manager in local environment..."

# Check for Node.js
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Please install Node.js 18 or newer."
    exit 1
fi

# Check for npm
if ! command -v npm &> /dev/null; then
    echo "npm is not installed. Please install npm."
    exit 1
fi

# Check for PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "PostgreSQL is not installed. The application requires PostgreSQL."
    echo "You can continue, but you'll need to install PostgreSQL for database functionality."
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Check if .env file exists
if [ ! -f .env ]; then
    echo "Creating .env file from .env.example..."
    cp .env.example .env
    echo "Please edit the .env file with your database connection settings."
else
    echo ".env file already exists. Skipping creation."
fi

# Check if a database URL is set
if grep -q "DATABASE_URL=\"postgresql://postgres:postgres@localhost:5432/stream_manager\"" .env; then
    echo "Default DATABASE_URL detected. You may need to update it with your actual database credentials."
    echo "Edit the .env file to update the DATABASE_URL."
fi

# Create database if PostgreSQL is installed
if command -v psql &> /dev/null; then
    echo "Would you like to create the 'stream_manager' database? (y/n)"
    read -r create_db
    if [ "$create_db" = "y" ] || [ "$create_db" = "Y" ]; then
        if psql -lqt | cut -d \| -f 1 | grep -qw stream_manager; then
            echo "Database 'stream_manager' already exists. Skipping creation."
        else
            echo "Creating 'stream_manager' database..."
            createdb stream_manager
            echo "Database created successfully."
        fi
    fi
fi

# Initialize database schema
echo "Initializing database schema..."
npx tsx init-db.ts

echo ""
echo "Setup complete! You can now start the application with:"
echo "npm run dev"
echo ""
echo "The application will be available at http://localhost:5000"
echo ""
echo "Default login credentials:"
echo "Username: admin"
echo "Password: admin123"