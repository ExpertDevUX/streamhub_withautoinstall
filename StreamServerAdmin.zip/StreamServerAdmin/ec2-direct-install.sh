#!/bin/bash

# EC2 Direct Installation Script for Stream Manager
# This script directly installs the Stream Manager on an EC2 instance

# Color codes for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Set up error handling
set -e

# Parse command line arguments
SSH_KEY=""
EC2_HOST=""
USERNAME="ubuntu"

while [[ $# -gt 0 ]]; do
    case $1 in
        --key)
            SSH_KEY="$2"
            shift 2
            ;;
        --host)
            EC2_HOST="$2"
            shift 2
            ;;
        --username)
            USERNAME="$2"
            shift 2
            ;;
        *)
            print_message "Unknown parameter: $1" "$RED"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$SSH_KEY" ]; then
    print_message "SSH key file is required. Use --key to specify." "$RED"
    exit 1
fi

if [ -z "$EC2_HOST" ]; then
    print_message "EC2 host (IP or DNS) is required. Use --host to specify." "$RED"
    exit 1
fi

# Check if we can connect to the instance
print_message "Testing SSH connection to $EC2_HOST..." "$BLUE"
if ! ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o ConnectTimeout=10 "$USERNAME@$EC2_HOST" echo "SSH connection successful"; then
    print_message "Failed to connect to $EC2_HOST via SSH. Please check your key file and security group rules." "$RED"
    exit 1
fi

# Create installation script
print_message "Creating installation script..." "$BLUE"
cat > setup-stream-manager.sh << 'EOL'
#!/bin/bash

# Set up logging
exec > >(tee /var/log/setup-stream-manager.log) 2>&1
echo "Starting Stream Manager setup at $(date)"

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install required packages
echo "Installing required packages..."
sudo apt-get install -y curl git postgresql postgresql-contrib nginx build-essential python3-pip unzip

# Install Node.js 20.x
echo "Installing Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Setup nginx with a simple landing page
echo "Setting up Nginx..."
sudo cat > /var/www/html/index.html << 'EOH'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Stream Manager</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(to right, #4F46E5, #10B981);
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      text-align: center;
    }
    .container {
      background: rgba(0, 0, 0, 0.6);
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      max-width: 600px;
    }
    h1 {
      font-size: 3rem;
      margin-bottom: 1rem;
    }
    p {
      font-size: 1.2rem;
      line-height: 1.6;
      margin-bottom: 2rem;
    }
    .status {
      margin-top: 20px;
      padding: 15px;
      background-color: rgba(0, 0, 0, 0.3);
      border-radius: 5px;
      text-align: left;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Stream Manager</h1>
    <p>A powerful video stream server management platform that simplifies complex server operations through intuitive design and intelligent automation.</p>
    <p>The server has been deployed successfully!</p>
    <div class="status">
      <p><strong>Status:</strong> Server is online</p>
      <p><strong>Public IP:</strong> <script>document.write(window.location.hostname)</script></p>
      <p><strong>Server Time:</strong> <script>document.write(new Date().toLocaleString())</script></p>
    </div>
  </div>
</body>
</html>
EOH

# Make sure nginx is running
sudo systemctl restart nginx
sudo systemctl enable nginx

echo "Nginx configured and running."

# Setup PostgreSQL database
echo "Setting up PostgreSQL database..."
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE USER stream_manager WITH PASSWORD 'stream_manager_pwd';"
sudo -u postgres psql -c "CREATE DATABASE stream_manager;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE stream_manager TO stream_manager;"
sudo -u postgres psql -c "ALTER USER stream_manager WITH SUPERUSER;"

echo "PostgreSQL configured with stream_manager database."

# Create application directory
sudo mkdir -p /opt/stream-manager
cd /opt/stream-manager

# Create admin credentials
sudo mkdir -p /etc/stream-manager
sudo bash -c 'echo "admin:admin123" > /etc/stream-manager/credentials.conf'
sudo chmod 600 /etc/stream-manager/credentials.conf

# Get public IP address
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Create environment variables file
cat > .env << EOF
DATABASE_URL=postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager
PUBLIC_IP=$PUBLIC_IP
APP_URL=http://$PUBLIC_IP
EOF

echo "=========================================================="
echo "Stream Manager Setup Complete!"
echo "=========================================================="
echo "Public URL: http://$PUBLIC_IP"
echo "PostgreSQL Database: stream_manager"
echo "PostgreSQL User: stream_manager / stream_manager_pwd"
echo "Admin Credentials: admin / admin123"
echo "=========================================================="
EOL

# Upload the script to EC2
print_message "Uploading setup script to $EC2_HOST..." "$BLUE"
scp -i "$SSH_KEY" setup-stream-manager.sh "$USERNAME@$EC2_HOST:~/"

# Execute the script on EC2
print_message "Executing setup script on $EC2_HOST..." "$BLUE"
ssh -i "$SSH_KEY" "$USERNAME@$EC2_HOST" "chmod +x ~/setup-stream-manager.sh && bash ~/setup-stream-manager.sh"

print_message "EC2 setup completed!" "$GREEN"
print_message "Next Steps:" "$BLUE"
print_message "1. Deploy your application code to the EC2 instance" "$BLUE"
print_message "2. Configure your application with the database URL: postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager" "$BLUE"
print_message "3. Start your application" "$BLUE"

echo "To connect to your instance and complete the deployment, use:"
echo "ssh -i $SSH_KEY $USERNAME@$EC2_HOST"
echo ""
echo "Your web server is running at: http://$EC2_HOST"

# Clean up
rm -f setup-stream-manager.sh

exit 0