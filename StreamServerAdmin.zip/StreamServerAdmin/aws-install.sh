#!/bin/bash

# AWS EC2 Installation Script for Stream Manager
# This script installs and sets up Stream Manager on AWS EC2 instances

# Color codes for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if script is run as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Use sudo or switch to root user." "$RED"
    exit 1
fi

print_message "Stream Manager Installation for AWS EC2" "$BLUE"
print_message "----------------------------------------" "$BLUE"

# Update package lists
print_message "Updating package lists..." "$YELLOW"
apt-get update

# Install required dependencies
print_message "Installing dependencies..." "$YELLOW"
apt-get install -y curl wget jq nginx build-essential libpcre3-dev libssl-dev zlib1g-dev

# Check for AWS CLI
if ! command_exists aws; then
    print_message "Installing AWS CLI..." "$YELLOW"
    apt-get install -y unzip
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
    unzip -q awscliv2.zip
    ./aws/install
    rm -rf aws awscliv2.zip
fi

# Check for nodejs
if ! command_exists node; then
    print_message "Installing Node.js..." "$YELLOW"
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi

# Check Node.js version
NODE_VERSION=$(node -v)
print_message "Node.js version: $NODE_VERSION" "$GREEN"

# Get public IP address (for EC2)
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
INSTANCE_TYPE=$(curl -s http://169.254.169.254/latest/meta-data/instance-type)

print_message "AWS EC2 Instance Information:" "$BLUE"
print_message "Instance ID: $INSTANCE_ID" "$GREEN"
print_message "Instance Type: $INSTANCE_TYPE" "$GREEN"
print_message "Public IP: $PUBLIC_IP" "$GREEN"

# Create application directory
APP_DIR="/opt/stream-manager"
print_message "Creating application directory at $APP_DIR..." "$YELLOW"
mkdir -p $APP_DIR

# Check if PostgreSQL is installed, if not install it
if ! command_exists psql; then
    print_message "Installing PostgreSQL..." "$YELLOW"
    apt-get install -y postgresql postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
fi

# Setup PostgreSQL
print_message "Setting up PostgreSQL database..." "$YELLOW"
# Create user and database if they don't exist
if ! sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw stream_manager; then
    sudo -u postgres psql -c "CREATE USER stream_manager WITH PASSWORD 'stream_manager_pwd';"
    sudo -u postgres psql -c "CREATE DATABASE stream_manager OWNER stream_manager;"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE stream_manager TO stream_manager;"
fi

# Configuration directory
CONF_DIR="/etc/stream-manager"
mkdir -p $CONF_DIR

# Generate random admin password or use default if specified
if [ "$1" == "--default-admin-password" ]; then
    ADMIN_PASSWORD="admin123"
else
    ADMIN_PASSWORD=$(openssl rand -base64 12)
fi

# Store credentials in conf file
echo "admin:$ADMIN_PASSWORD" > $CONF_DIR/credentials.conf
chmod 600 $CONF_DIR/credentials.conf

# Deploy application (assuming it's in the same directory as this script)
print_message "Deploying application..." "$YELLOW"
# Copy application files to APP_DIR
cp -R * $APP_DIR/
cd $APP_DIR

# Install npm dependencies
print_message "Installing npm dependencies..." "$YELLOW"
npm install

# Set environment variables
export DATABASE_URL="postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager"
echo "DATABASE_URL=postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager" > .env

# Set PUBLIC_IP and APP_URL in environment
echo "PUBLIC_IP=$PUBLIC_IP" >> .env
echo "APP_URL=http://$PUBLIC_IP" >> .env

# Run database migrations
print_message "Running database migrations..." "$YELLOW"
npm run db:push

# Create service file for autostart
SYSTEMD_SERVICE="/etc/systemd/system/stream-manager.service"
print_message "Creating systemd service..." "$YELLOW"
cat <<EOF > $SYSTEMD_SERVICE
[Unit]
Description=Stream Manager Service
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/npm run start
Restart=always
Environment=DATABASE_URL=postgresql://stream_manager:stream_manager_pwd@localhost:5432/stream_manager
Environment=NODE_ENV=production
Environment=PUBLIC_IP=$PUBLIC_IP
Environment=APP_URL=http://$PUBLIC_IP

[Install]
WantedBy=multi-user.target
EOF

# Reload and enable service
systemctl daemon-reload
systemctl enable stream-manager.service
systemctl start stream-manager.service

# Display installation complete message
print_message "Stream Manager Installation Complete!" "$GREEN"
print_message "---------------------------------" "$GREEN"
print_message "Your Stream Manager is now running at: http://$PUBLIC_IP" "$GREEN"
print_message "Admin Username: admin" "$GREEN"
print_message "Admin Password: $ADMIN_PASSWORD" "$GREEN"
print_message "Admin credentials are saved in: $CONF_DIR/credentials.conf" "$GREEN"
print_message "---------------------------------" "$GREEN"
print_message "AWS EC2 Instance ID: $INSTANCE_ID" "$GREEN"
print_message "AWS EC2 Instance Type: $INSTANCE_TYPE" "$GREEN"

exit 0