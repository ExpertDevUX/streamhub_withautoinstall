# Stream Manager Deployment Guide for AWS EC2

This guide provides detailed instructions for deploying the Stream Manager application to an AWS EC2 instance.

## Deployment Methods

There are three main ways to deploy Stream Manager to AWS EC2:

1. **Direct Deployment (EC2 Instance Connect)**: Use the provided `deploy-direct-ec2.sh` script to deploy directly to your EC2 instance using AWS CLI and EC2 Instance Connect.
2. **SSH-based Deployment**: Use the provided `deploy-to-ec2.sh` script to deploy via SSH from your local machine.
3. **Manual Deployment**: Download the deployment package from S3 and install it manually on your EC2 instance.

## S3 Bucket Information

All deployment files are available in the following S3 bucket:
```
Bucket Name: stream-manager-deployment-1743048279
Region: ap-southeast-1
```

**Access Requirements**: You need AWS credentials with S3 read access to download files from this bucket. The bucket is not publicly accessible due to security policies.

The following files are available in the bucket:
- `stream-manager-deploy.tar.gz`: The main deployment package
- `aws-install.sh`: AWS-specific installation script
- `deploy-to-ec2.sh`: SSH-based deployment script
- `deploy-direct-ec2.sh`: Direct EC2 Instance Connect deployment script
- `AWS_DEPLOYMENT.md`: This deployment guide

To download files from this bucket, you must:
1. Have AWS CLI installed (`pip install awscli`)
2. Configure your AWS credentials (`aws configure`)
3. Have permissions to access the bucket

### Generating Presigned URLs

For easier distribution of deployment files, administrators can generate temporary access links with presigned URLs using the included script:

```bash
# Make the script executable
chmod +x generate-presigned-urls.sh

# Run the script
./generate-presigned-urls.sh
```

This will generate temporary URLs that can be shared with authorized users, who can then download the files without needing AWS credentials. These URLs will expire after the configured time period (default: 1 hour).

## Prerequisites

- An AWS EC2 instance (recommended: t2.medium or better)
- Ubuntu 20.04 LTS or newer as the operating system
- SSH access to your EC2 instance
- Security group allowing inbound traffic on ports:
  - 22 (SSH)
  - 80 (HTTP)
  - 443 (HTTPS)
  - 1935 (RTMP) 

## Option 1: Direct Deployment (EC2 Instance Connect)

This method uses the `deploy-direct-ec2.sh` script to deploy directly to your EC2 instance using AWS CLI and EC2 Instance Connect, without requiring SSH keys.

1. **Download the deployment script**:
   ```bash
   aws s3 cp s3://stream-manager-deployment-1743048279/deploy-direct-ec2.sh .
   ```

2. **Make the deployment script executable**:
   ```bash
   chmod +x deploy-direct-ec2.sh
   ```

3. **Run the deployment script**:
   ```bash
   ./deploy-direct-ec2.sh --instance-id i-01c8351c620388fc0 --region ap-southeast-1
   ```

   Replace the parameters with your specific values:
   - `--instance-id`: Your EC2 instance ID
   - `--region`: AWS region where your instance is located (default: ap-southeast-1)

   Note: This method requires that your EC2 instance has an IAM role with the following permissions:
   - AmazonSSMFullAccess
   - AmazonS3ReadOnlyAccess

4. **Access the application**:
   After successful deployment, you can access the Stream Manager at:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```

   Use the default admin credentials:
   - Username: admin
   - Password: Check /etc/stream-manager/credentials.conf on your server

## Option 2: SSH-based Deployment

This method uses the `deploy-to-ec2.sh` script to deploy via SSH from your local machine.

1. **Download the deployment script**:
   ```bash
   aws s3 cp s3://stream-manager-deployment-1743048279/deploy-to-ec2.sh .
   ```

2. **Make the deployment script executable**:
   ```bash
   chmod +x deploy-to-ec2.sh
   ```

3. **Run the deployment script**:
   ```bash
   ./deploy-to-ec2.sh --instance-id i-01c8351c620388fc0 --key-file /path/to/your-key.pem --region ap-southeast-1 --username ubuntu
   ```

   Replace the parameters with your specific values:
   - `--instance-id`: Your EC2 instance ID
   - `--key-file`: Path to your private key file (.pem)
   - `--region`: AWS region where your instance is located (default: ap-southeast-1)
   - `--username`: SSH username for your instance (default: ubuntu)

4. **Access the application**:
   After successful deployment, you can access the Stream Manager at:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```

   Use the default admin credentials:
   - Username: admin
   - Password: Check /etc/stream-manager/credentials.conf on your server

## Option 3: Manual Deployment

If you prefer to deploy manually or if the other deployment methods don't work for you:

1. **SSH into your EC2 instance**:
   ```bash
   ssh -i /path/to/your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
   ```

2. **Install AWS CLI if not already installed**:
   ```bash
   if ! command -v aws &> /dev/null; then
     sudo apt-get update
     sudo apt-get install -y unzip
     curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
     unzip -q awscliv2.zip
     sudo ./aws/install
     rm -rf aws awscliv2.zip
   fi
   ```

3. **Download the deployment package directly from S3**:
   ```bash
   mkdir -p ~/stream-manager
   cd ~/stream-manager
   aws s3 cp s3://stream-manager-deployment-1743048279/stream-manager-deploy.tar.gz .
   aws s3 cp s3://stream-manager-deployment-1743048279/aws-install.sh .
   ```

4. **Extract the deployment package**:
   ```bash
   tar -xzf stream-manager-deploy.tar.gz
   ```

5. **Run the AWS installation script**:
   ```bash
   chmod +x aws-install.sh
   sudo ./aws-install.sh
   ```

   Alternatively, to use the default admin password instead of a random one:
   ```bash
   sudo ./aws-install.sh --default-admin-password
   ```

6. **Access the application**:
   After successful installation, you can access the Stream Manager at:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```

## Post-Deployment Configuration

After deploying the Stream Manager, you should:

1. **Change the default admin password**:
   - Log in with the default admin credentials
   - Go to Settings > User Management
   - Change the admin password to a secure one

2. **Configure HTTPS** (recommended for production):
   - Go to Settings > SSL Configuration
   - Follow the instructions to set up SSL with Let's Encrypt

3. **Configure your RTMP server**:
   - Go to Settings > RTMP Server Configuration
   - Configure your stream settings according to your needs

## Troubleshooting

If you encounter any issues during deployment or while using the Stream Manager:

1. **Check the application logs**:
   ```bash
   sudo journalctl -u stream-manager.service -f
   ```

2. **Check the NGINX logs** (if RTMP streaming issues occur):
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

3. **Restart the service**:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

4. **Verify database connection**:
   ```bash
   grep DATABASE_URL /opt/stream-manager/.env
   sudo -u postgres psql -c "SELECT datname FROM pg_database;"
   ```

5. **Check if RTMP module is installed**:
   ```bash
   sudo nginx -V 2>&1 | grep rtmp
   ```

## Support

If you need further assistance, please contact support at:
- Email: info@hwosecurity.org
- Reference your EC2 instance ID in your support request

---

## Advanced Configuration

### Customizing the Database Connection

To use a different PostgreSQL database:

1. Edit the environment file:
   ```bash
   sudo nano /opt/stream-manager/.env
   ```

2. Update the DATABASE_URL value:
   ```
   DATABASE_URL=postgresql://username:password@hostname:5432/dbname
   ```

3. Restart the service:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

### Setting Up a Domain Name

1. Configure your domain's DNS to point to your EC2 instance's public IP address

2. Update the application URL:
   ```bash
   sudo nano /opt/stream-manager/.env
   ```

3. Add or update the APP_URL:
   ```
   APP_URL=http://your-domain.com
   ```

4. Restart the service:
   ```bash
   sudo systemctl restart stream-manager.service
   ```

5. Set up SSL for your domain via the Stream Manager's SSL Configuration page