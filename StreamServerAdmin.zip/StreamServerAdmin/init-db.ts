import { Pool, neonConfig } from '@neondatabase/serverless';
import * as schema from './shared/schema';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { sql } from 'drizzle-orm';
import ws from 'ws';

// Set WebSocket implementation
neonConfig.webSocketConstructor = ws;

async function initDb() {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL environment variable not set');
    process.exit(1);
  }

  try {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle(pool, { schema });

    console.log('Creating database schema...');

    // Create quality profiles table
    console.log('Creating quality_profiles table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS quality_profiles (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        video_bitrate INTEGER NOT NULL,
        audio_bitrate INTEGER NOT NULL,
        resolution TEXT NOT NULL,
        framerate INTEGER DEFAULT 30,
        keyframe_interval INTEGER DEFAULT 2,
        preset TEXT DEFAULT 'veryfast',
        profile TEXT DEFAULT 'main',
        is_default BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Create users table
    console.log('Creating users table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        is_admin BOOLEAN DEFAULT false NOT NULL,
        email TEXT,
        full_name TEXT,
        logo_url TEXT,
        custom_css TEXT,
        theme TEXT DEFAULT 'default'
      )
    `);

    // Create streams table
    console.log('Creating streams table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS streams (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        stream_key TEXT NOT NULL UNIQUE,
        user_id INTEGER NOT NULL,
        is_active BOOLEAN DEFAULT false,
        viewers INTEGER DEFAULT 0,
        started_at TIMESTAMP,
        duration INTEGER DEFAULT 0,
        quality TEXT,
        bandwidth INTEGER DEFAULT 0,
        wp_stream_id INTEGER,
        is_recording BOOLEAN DEFAULT false,
        recording_path TEXT,
        has_recordings BOOLEAN DEFAULT false,
        enable_webrtc BOOLEAN DEFAULT false,
        enable_hls BOOLEAN DEFAULT true,
        enable_low_latency BOOLEAN DEFAULT false,
        thumbnail_url TEXT,
        last_recording_date TIMESTAMP,
        description TEXT,
        is_public BOOLEAN DEFAULT true,
        category TEXT,
        tags TEXT[],
        server_id INTEGER
      )
    `);

    // Create servers table
    console.log('Creating servers table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS servers (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        host TEXT NOT NULL,
        port INTEGER NOT NULL,
        is_installed BOOLEAN DEFAULT false,
        status TEXT DEFAULT 'offline',
        cpu_usage INTEGER DEFAULT 0,
        memory_usage INTEGER DEFAULT 0,
        disk_usage INTEGER DEFAULT 0,
        network_usage INTEGER DEFAULT 0,
        uptime INTEGER DEFAULT 0,
        config JSONB
      )
    `);

    // Create activities table
    console.log('Creating activities table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS activities (
        id SERIAL PRIMARY KEY,
        type TEXT NOT NULL,
        message TEXT NOT NULL,
        user_id INTEGER,
        timestamp TIMESTAMP DEFAULT NOW(),
        related_id INTEGER,
        related_type TEXT
      )
    `);

    // Create integrations table
    console.log('Creating integrations table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS integrations (
        id SERIAL PRIMARY KEY,
        type TEXT NOT NULL,
        name TEXT NOT NULL,
        enabled BOOLEAN DEFAULT false,
        config JSONB NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Create cloud_providers table
    console.log('Creating cloud_providers table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS cloud_providers (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        api_key TEXT NOT NULL,
        api_secret TEXT,
        region TEXT,
        user_id INTEGER NOT NULL,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        config JSONB
      )
    `);

    // Create bandwidth_allocations table
    console.log('Creating bandwidth_allocations table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS bandwidth_allocations (
        id SERIAL PRIMARY KEY,
        server_id INTEGER NOT NULL,
        stream_id INTEGER,
        allocated INTEGER NOT NULL DEFAULT 0,
        used INTEGER DEFAULT 0,
        throttled BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Create site_config table
    console.log('Creating site_config table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS site_config (
        id SERIAL PRIMARY KEY,
        site_name TEXT NOT NULL DEFAULT 'Stream Manager',
        domain TEXT,
        hostname TEXT,
        primary_color TEXT DEFAULT '#3b82f6',
        site_description TEXT DEFAULT 'Video Stream Server Management Platform',
        favicon_url TEXT,
        contact_email TEXT,
        db_name TEXT,
        db_user TEXT,
        db_host TEXT,
        is_configured BOOLEAN DEFAULT false,
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Create session table for Connect PG Simple
    console.log('Creating session table...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS "session" (
        "sid" varchar NOT NULL COLLATE "default",
        "sess" json NOT NULL,
        "expire" timestamp(6) NOT NULL,
        CONSTRAINT "session_pkey" PRIMARY KEY ("sid")
      )
    `);
    
    // Create index for session expire
    await pool.query(`
      CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire")
    `);

    console.log('Database schema created successfully');

    // Create default admin user if not exists
    console.log('Checking for admin user...');
    const adminExists = await pool.query(`
      SELECT * FROM users WHERE username = 'admin' LIMIT 1
    `);

    if (adminExists.rowCount === 0) {
      console.log('Creating default admin user...');
      await pool.query(`
        INSERT INTO users (username, password, is_admin, email, full_name)
        VALUES ('admin', 'admin123', true, 'admin@example.com', 'Administrator')
      `);
      console.log('Default admin user created successfully');
    } else {
      console.log('Admin user already exists');
    }

    // Create default server if not exists
    console.log('Checking for default server...');
    const serverExists = await pool.query(`
      SELECT * FROM servers LIMIT 1
    `);

    if (serverExists.rowCount === 0) {
      console.log('Creating default server...');
      await pool.query(`
        INSERT INTO servers (name, host, port, config)
        VALUES (
          'Default RTMP Server', 
          'localhost', 
          1935, 
          '{"rtmp":{"port":1935,"chunk_size":60000,"gop_cache":true,"ping":30,"ping_timeout":60},"http":{"port":8000,"allow_origin":"*"}}'
        )
      `);
      console.log('Default server created successfully');
    } else {
      console.log('Default server already exists');
    }

    // Create default site config if not exists
    console.log('Checking for site configuration...');
    const configExists = await pool.query(`
      SELECT * FROM site_config LIMIT 1
    `);

    if (configExists.rowCount === 0) {
      console.log('Creating default site configuration...');
      await pool.query(`
        INSERT INTO site_config (site_name, hostname, primary_color, site_description)
        VALUES ('Stream Manager', 'localhost', '#3b82f6', 'Video Stream Server Management Platform')
      `);
      console.log('Default site configuration created successfully');
    } else {
      console.log('Site configuration already exists');
    }

    console.log('Database initialization complete');
    await pool.end();
    
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

initDb().catch(console.error);