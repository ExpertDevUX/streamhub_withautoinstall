<?php
/**
 * Application Configuration
 */

// Application
define('APP_NAME', $_ENV['APP_NAME']);
define('APP_URL', $_ENV['APP_URL']);
define('DEBUG', $_ENV['DEBUG'] === 'true');

// Storage paths
define('STORAGE_PATH', $_ENV['STORAGE_PATH']);
define('UPLOADS_PATH', STORAGE_PATH . '/uploads');
define('LOGS_PATH', STORAGE_PATH . '/logs');
define('CACHE_PATH', STORAGE_PATH . '/cache');

// Create storage directories if they don't exist
if (!is_dir(UPLOADS_PATH)) {
    mkdir(UPLOADS_PATH, 0755, true);
}
if (!is_dir(LOGS_PATH)) {
    mkdir(LOGS_PATH, 0755, true);
}
if (!is_dir(CACHE_PATH)) {
    mkdir(CACHE_PATH, 0755, true);
}

// RTMP Server
define('RTMP_HOST', $_ENV['RTMP_HOST']);
define('RTMP_PORT', $_ENV['RTMP_PORT']);

// Session configuration
ini_set('session.gc_maxlifetime', $_ENV['SESSION_LIFETIME']);
ini_set('session.cookie_lifetime', $_ENV['SESSION_LIFETIME']);
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);