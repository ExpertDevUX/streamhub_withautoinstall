<?php
namespace App\Core;

use App\Models\Config;

/**
 * ConfigManager Class
 * 
 * Centralized configuration manager to load, store, and apply configuration settings
 */
class ConfigManager
{
    /**
     * @var array Loaded configuration settings
     */
    private static $config = [];
    
    /**
     * @var Config Config model instance
     */
    private static $configModel;
    
    /**
     * @var bool Whether the configuration has been loaded
     */
    private static $loaded = false;
    
    /**
     * Initialize the configuration manager
     */
    public static function init()
    {
        if (!self::$configModel) {
            self::$configModel = new Config();
        }
        
        self::loadAllConfigurations();
    }
    
    /**
     * Load all configurations from the database
     */
    public static function loadAllConfigurations()
    {
        if (!self::$configModel) {
            self::$configModel = new Config();
        }
        
        // Get all configurations
        $configs = self::$configModel->getAllConfigurations();
        
        // Reset config array
        self::$config = [];
        
        // Parse configurations
        foreach ($configs as $config) {
            self::$config[$config['name']] = json_decode($config['value'], true);
        }
        
        // Set loaded flag
        self::$loaded = true;
        
        // Apply configurations to the application
        self::applyConfigurations();
    }
    
    /**
     * Get configuration settings
     * 
     * @param string $name Configuration name (e.g., 'interface', 'system', 'rtmp')
     * @param string|null $key Specific configuration key (optional)
     * @param mixed $default Default value if not found
     * @return mixed Configuration value
     */
    public static function get($name, $key = null, $default = null)
    {
        // Load configurations if not already loaded
        if (!self::$loaded) {
            self::loadAllConfigurations();
        }
        
        // Check if configuration exists
        if (!isset(self::$config[$name])) {
            return $default;
        }
        
        // Return specific key or entire configuration
        if ($key !== null) {
            return self::$config[$name][$key] ?? $default;
        }
        
        return self::$config[$name];
    }
    
    /**
     * Set configuration setting
     * 
     * @param string $name Configuration name
     * @param string|array $key Configuration key or entire configuration array
     * @param mixed $value Configuration value (if key is string)
     * @return bool True if saved, false otherwise
     */
    public static function set($name, $key, $value = null)
    {
        // Load configurations if not already loaded
        if (!self::$loaded) {
            self::loadAllConfigurations();
        }
        
        // Initialize configuration if it doesn't exist
        if (!isset(self::$config[$name])) {
            self::$config[$name] = [];
        }
        
        // Set entire configuration or specific key
        if (is_array($key)) {
            self::$config[$name] = $key;
        } else {
            self::$config[$name][$key] = $value;
        }
        
        // Save to database
        $result = self::$configModel->saveConfiguration($name, self::$config[$name]);
        
        // Apply the new configuration
        self::applyConfigurations();
        
        return $result;
    }
    
    /**
     * Apply configurations to the application
     */
    private static function applyConfigurations()
    {
        // Apply interface configuration
        self::applyInterfaceConfig();
        
        // Apply system configuration
        self::applySystemConfig();
        
        // Apply RTMP configuration
        self::applyRtmpConfig();
    }
    
    /**
     * Apply interface configuration
     */
    private static function applyInterfaceConfig()
    {
        $config = self::get('interface');
        
        if (!$config) {
            return;
        }
        
        // Set site name in global scope for views
        $GLOBALS['SITE_NAME'] = $config['site_name'] ?? 'Stream Manager';
        
        // Create custom CSS file
        $customCssPath = ROOT_PATH . '/public/css/custom.css';
        $customCss = '';
        
        // Add custom theme
        if (isset($config['theme']) && $config['theme'] !== 'custom') {
            $customCss .= "/* Theme styles */\n";
            
            if ($config['theme'] === 'dark') {
                $customCss .= "body {\n";
                $customCss .= "    background-color: #212529;\n";
                $customCss .= "    color: #f8f9fa;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".card, .list-group-item, .form-control, .form-select {\n";
                $customCss .= "    background-color: #2c3034;\n";
                $customCss .= "    color: #f8f9fa;\n";
                $customCss .= "    border-color: #495057;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".form-control:focus, .form-select:focus {\n";
                $customCss .= "    background-color: #2c3034;\n";
                $customCss .= "    color: #f8f9fa;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".table {\n";
                $customCss .= "    color: #f8f9fa;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".bg-light {\n";
                $customCss .= "    background-color: #343a40 !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".text-muted {\n";
                $customCss .= "    color: #adb5bd !important;\n";
                $customCss .= "}\n\n";
            }
        }
        
        // Add custom colors
        if (isset($config['primary_color']) || isset($config['secondary_color'])) {
            $customCss .= "/* Custom colors */\n";
            
            if (isset($config['primary_color'])) {
                $customCss .= ".btn-primary, .bg-primary {\n";
                $customCss .= "    background-color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "    border-color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".btn-outline-primary {\n";
                $customCss .= "    color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "    border-color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".btn-outline-primary:hover {\n";
                $customCss .= "    background-color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "    color: white !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".text-primary {\n";
                $customCss .= "    color: " . $config['primary_color'] . " !important;\n";
                $customCss .= "}\n\n";
            }
            
            if (isset($config['secondary_color'])) {
                $customCss .= ".btn-secondary, .bg-secondary {\n";
                $customCss .= "    background-color: " . $config['secondary_color'] . " !important;\n";
                $customCss .= "    border-color: " . $config['secondary_color'] . " !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".btn-outline-secondary {\n";
                $customCss .= "    color: " . $config['secondary_color'] . " !important;\n";
                $customCss .= "    border-color: " . $config['secondary_color'] . " !important;\n";
                $customCss .= "}\n\n";
                
                $customCss .= ".btn-outline-secondary:hover {\n";
                $customCss .= "    background-color: " . $config['secondary_color'] . " !important;\n";
                $customCss .= "    color: white !important;\n";
                $customCss .= "}\n\n";
            }
        }
        
        // Add animations
        if (isset($config['enable_animations']) && $config['enable_animations']) {
            $customCss .= "/* Animations */\n";
            $customCss .= ".card, .btn {\n";
            $customCss .= "    transition: all 0.3s ease;\n";
            $customCss .= "}\n\n";
            
            $customCss .= ".card:hover {\n";
            $customCss .= "    transform: translateY(-5px);\n";
            $customCss .= "    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);\n";
            $customCss .= "}\n\n";
            
            $customCss .= ".btn:hover {\n";
            $customCss .= "    transform: translateY(-2px);\n";
            $customCss .= "}\n\n";
        } else {
            // Disable animations
            $customCss .= "/* Animations disabled */\n";
            $customCss .= ".card, .btn {\n";
            $customCss .= "    transition: none !important;\n";
            $customCss .= "}\n\n";
            
            $customCss .= ".card:hover {\n";
            $customCss .= "    transform: none !important;\n";
            $customCss .= "}\n\n";
            
            $customCss .= ".btn:hover {\n";
            $customCss .= "    transform: none !important;\n";
            $customCss .= "}\n\n";
        }
        
        // Add dashboard layout styles
        if (isset($config['dashboard_layout'])) {
            $customCss .= "/* Dashboard layout */\n";
            
            switch ($config['dashboard_layout']) {
                case 'list':
                    $customCss .= ".dashboard-card {\n";
                    $customCss .= "    margin-bottom: 1rem;\n";
                    $customCss .= "}\n\n";
                    break;
                    
                case 'compact':
                    $customCss .= ".dashboard-card {\n";
                    $customCss .= "    margin-bottom: 0.5rem;\n";
                    $customCss .= "    padding: 0.5rem;\n";
                    $customCss .= "}\n\n";
                    
                    $customCss .= ".dashboard-card h5 {\n";
                    $customCss .= "    font-size: 1rem;\n";
                    $customCss .= "}\n\n";
                    break;
                    
                case 'grid':
                    $customCss .= ".dashboard-cards {\n";
                    $customCss .= "    display: grid;\n";
                    $customCss .= "    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));\n";
                    $customCss .= "    gap: 1rem;\n";
                    $customCss .= "}\n\n";
                    break;
            }
        }
        
        // Add stream preview size
        if (isset($config['stream_preview_size'])) {
            $customCss .= "/* Stream preview size */\n";
            
            switch ($config['stream_preview_size']) {
                case 'small':
                    $customCss .= ".stream-preview {\n";
                    $customCss .= "    max-width: 320px;\n";
                    $customCss .= "    margin: 0 auto;\n";
                    $customCss .= "}\n\n";
                    break;
                    
                case 'medium':
                    $customCss .= ".stream-preview {\n";
                    $customCss .= "    max-width: 480px;\n";
                    $customCss .= "    margin: 0 auto;\n";
                    $customCss .= "}\n\n";
                    break;
                    
                case 'large':
                    $customCss .= ".stream-preview {\n";
                    $customCss .= "    max-width: 720px;\n";
                    $customCss .= "    margin: 0 auto;\n";
                    $customCss .= "}\n\n";
                    break;
                    
                case 'full':
                    $customCss .= ".stream-preview {\n";
                    $customCss .= "    width: 100%;\n";
                    $customCss .= "}\n\n";
                    break;
            }
        }
        
        // Add custom CSS
        if (isset($config['custom_css']) && !empty($config['custom_css'])) {
            $customCss .= "/* Custom CSS */\n";
            $customCss .= $config['custom_css'] . "\n";
        }
        
        // Write CSS file
        file_put_contents($customCssPath, $customCss);
    }
    
    /**
     * Apply system configuration
     */
    private static function applySystemConfig()
    {
        $config = self::get('system');
        
        if (!$config) {
            return;
        }
        
        // Set debug mode
        if (isset($config['debug_mode'])) {
            if ($config['debug_mode']) {
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                $GLOBALS['DEBUG_MODE'] = true;
            } else {
                error_reporting(E_ERROR | E_PARSE);
                ini_set('display_errors', 0);
                $GLOBALS['DEBUG_MODE'] = false;
            }
        }
        
        // Set timezone
        if (isset($config['timezone'])) {
            date_default_timezone_set($config['timezone']);
        }
        
        // Set session lifetime
        if (isset($config['session_lifetime'])) {
            ini_set('session.gc_maxlifetime', $config['session_lifetime']);
            session_set_cookie_params($config['session_lifetime']);
        }
        
        // Set upload limits
        if (isset($config['max_upload_size'])) {
            $maxSize = $config['max_upload_size'] . 'M';
            ini_set('upload_max_filesize', $maxSize);
            ini_set('post_max_size', $maxSize);
        }
        
        // Set maintenance mode
        if (isset($config['maintenance_mode']) && $config['maintenance_mode']) {
            $GLOBALS['MAINTENANCE_MODE'] = true;
            $GLOBALS['MAINTENANCE_MESSAGE'] = $config['maintenance_message'] ?? 'The site is currently under maintenance. Please check back later.';
            
            // Check if current request should see maintenance page
            $currentPath = $_SERVER['REQUEST_URI'] ?? '/';
            
            // Exclude certain paths from maintenance mode
            $excludedPaths = ['/login', '/admin', '/config'];
            $excluded = false;
            
            foreach ($excludedPaths as $path) {
                if (strpos($currentPath, $path) === 0) {
                    $excluded = true;
                    break;
                }
            }
            
            // Show maintenance page if not excluded and not admin
            if (!$excluded && (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin')) {
                include ROOT_PATH . '/views/errors/maintenance.php';
                exit;
            }
        } else {
            $GLOBALS['MAINTENANCE_MODE'] = false;
        }
    }
    
    /**
     * Apply RTMP configuration
     */
    private static function applyRtmpConfig()
    {
        $config = self::get('rtmp');
        
        if (!$config) {
            return;
        }
        
        // Set global RTMP settings
        $GLOBALS['RTMP_CONFIG'] = $config;
    }
    
    /**
     * Clear cache
     * 
     * @return bool True if cache cleared, false otherwise
     */
    public static function clearCache()
    {
        // Clear configuration cache
        self::$loaded = false;
        self::$config = [];
        
        // Clear application cache
        $cacheDir = ROOT_PATH . '/storage/cache';
        
        if (is_dir($cacheDir)) {
            $files = glob($cacheDir . '/*');
            
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
        
        return true;
    }
    
    /**
     * Export configurations
     * 
     * @return array Configurations
     */
    public static function exportConfigurations()
    {
        // Load configurations if not already loaded
        if (!self::$loaded) {
            self::loadAllConfigurations();
        }
        
        return self::$config;
    }
    
    /**
     * Import configurations
     * 
     * @param array $config Configurations
     * @return bool True if imported, false otherwise
     */
    public static function importConfigurations($config)
    {
        if (!self::$configModel) {
            self::$configModel = new Config();
        }
        
        $result = self::$configModel->importConfigurations($config);
        
        if ($result) {
            self::loadAllConfigurations();
        }
        
        return $result;
    }
    
    /**
     * Reset configuration to default
     * 
     * @param string $name Configuration name
     * @return bool True if reset, false otherwise
     */
    public static function resetConfiguration($name)
    {
        if (!self::$configModel) {
            self::$configModel = new Config();
        }
        
        $result = self::$configModel->resetConfiguration($name);
        
        if ($result) {
            self::loadAllConfigurations();
        }
        
        return $result;
    }
}