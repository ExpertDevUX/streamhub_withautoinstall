<?php
namespace App\Core;

/**
 * Database class
 * 
 * Handles database connection and operations
 * Supports SQLite and MySQL
 */
class Database
{
    private $pdo;
    private $config;
    
    /**
     * Constructor
     */
    public function __construct($config)
    {
        $this->config = $config;
        $this->connect();
    }
    
    /**
     * Connect to database
     */
    private function connect()
    {
        try {
            switch ($this->config['type']) {
                case 'sqlite':
                    $dsn = "sqlite:" . $this->config['path'];
                    $this->pdo = new \PDO($dsn);
                    break;
                    
                case 'mysql':
                    $dsn = "mysql:host={$this->config['host']};dbname={$this->config['dbname']};charset=utf8mb4";
                    $this->pdo = new \PDO($dsn, $this->config['username'], $this->config['password']);
                    break;
                    
                case 'pgsql':
                    $dsn = "pgsql:host={$this->config['host']};port={$this->config['port']};dbname={$this->config['dbname']}";
                    $this->pdo = new \PDO($dsn, $this->config['username'], $this->config['password']);
                    break;
                    
                default:
                    throw new \Exception("Unsupported database type: {$this->config['type']}");
            }
            
            // Set error mode
            $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            
            // Use associative arrays for results
            $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
            
        } catch (\PDOException $e) {
            throw new \Exception("Database connection failed: " . $e->getMessage());
        }
    }
    
    /**
     * Execute a query
     */
    public function query($sql, $params = [])
    {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (\PDOException $e) {
            throw new \Exception("Query failed: " . $e->getMessage());
        }
    }
    
    /**
     * Find a single record
     */
    public function find($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * Find all records
     */
    public function findAll($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Insert a record
     */
    public function insert($table, $data)
    {
        // Build column and placeholder strings
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        // Build SQL
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        
        // Execute query
        $stmt = $this->query($sql, array_values($data));
        
        // Return ID of inserted record
        return $this->pdo->lastInsertId();
    }
    
    /**
     * Update a record
     */
    public function update($table, $data, $where, $whereParams = [])
    {
        // Build SET clause
        $set = [];
        foreach (array_keys($data) as $column) {
            $set[] = "{$column} = ?";
        }
        $setClause = implode(', ', $set);
        
        // Build SQL
        $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        
        // Combine parameters
        $params = array_merge(array_values($data), $whereParams);
        
        // Execute query
        $stmt = $this->query($sql, $params);
        
        // Return number of affected rows
        return $stmt->rowCount();
    }
    
    /**
     * Delete a record
     */
    public function delete($table, $where, $params = [])
    {
        // Build SQL
        $sql = "DELETE FROM {$table} WHERE {$where}";
        
        // Execute query
        $stmt = $this->query($sql, $params);
        
        // Return number of affected rows
        return $stmt->rowCount();
    }
    
    /**
     * Begin a transaction
     */
    public function beginTransaction()
    {
        return $this->pdo->beginTransaction();
    }
    
    /**
     * Commit a transaction
     */
    public function commit()
    {
        return $this->pdo->commit();
    }
    
    /**
     * Rollback a transaction
     */
    public function rollback()
    {
        return $this->pdo->rollBack();
    }
    
    /**
     * Get PDO instance
     */
    public function getPdo()
    {
        return $this->pdo;
    }
}