<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Stream;
use App\Models\Server;
use App\Models\Activity;

/**
 * Dashboard Controller
 * Handles dashboard functionality
 */
class DashboardController extends Controller
{
    private $streamModel;
    private $serverModel;
    private $activityModel;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->streamModel = new Stream();
        $this->serverModel = new Server();
        $this->activityModel = new Activity();
    }
    
    /**
     * Show dashboard
     */
    public function index(Request $request, Response $response)
    {
        // Require login
        $this->requireLogin();
        
        // Get user streams
        $streams = $this->streamModel->getByUserId($this->getUserId());
        
        // Get server status
        $servers = $this->serverModel->all();
        
        // Get recent activities
        $activities = $this->activityModel->getByUserId($this->getUserId(), 10);
        
        // Count active streams
        $activeStreams = array_filter($streams, function($stream) {
            return $stream['status'] === 'live';
        });
        
        // Calculate total viewers
        $totalViewers = array_reduce($activeStreams, function($carry, $stream) {
            return $carry + $stream['viewer_count'];
        }, 0);
        
        // Count active servers
        $activeServers = array_filter($servers, function($server) {
            return $server['status'] === 'online';
        });
        
        return $response->render('dashboard/index', [
            'title' => 'Dashboard - ' . APP_NAME,
            'streams' => $streams,
            'servers' => $servers,
            'activities' => $activities,
            'stats' => [
                'total_streams' => count($streams),
                'active_streams' => count($activeStreams),
                'total_viewers' => $totalViewers,
                'active_servers' => count($activeServers),
                'total_servers' => count($servers)
            ]
        ]);
    }
    
    /**
     * Show system metrics
     */
    public function metrics(Request $request, Response $response)
    {
        // Require login
        $this->requireLogin();
        
        // Get all servers with their status and load
        $servers = $this->serverModel->all();
        
        // Get active streams
        $activeStreams = $this->streamModel->getActiveStreams();
        
        // Get viewer statistics
        $viewerStats = $this->calculateViewerStatistics();
        
        return $response->render('dashboard/metrics', [
            'title' => 'System Metrics - ' . APP_NAME,
            'servers' => $servers,
            'activeStreams' => $activeStreams,
            'viewerStats' => $viewerStats
        ]);
    }
    
    /**
     * Calculate viewer statistics
     */
    private function calculateViewerStatistics()
    {
        // Get viewer counts for all active streams
        $sql = "SELECT SUM(viewer_count) as total_viewers, 
                       MAX(viewer_count) as max_stream_viewers,
                       COUNT(*) as active_streams
                FROM streams 
                WHERE status = 'live'";
        
        $stats = $this->streamModel->db->find($sql);
        
        // Get viewer counts by hour (last 24 hours)
        $sql = "SELECT 
                    EXTRACT(HOUR FROM created_at) as hour,
                    SUM(viewer_count) as viewers
                FROM activities
                WHERE action = 'viewer_count_updated'
                    AND created_at > NOW() - INTERVAL '24 hours'
                GROUP BY hour
                ORDER BY hour";
        
        $hourlyStats = $this->streamModel->db->findAll($sql);
        
        return [
            'total_viewers' => $stats['total_viewers'] ?? 0,
            'max_stream_viewers' => $stats['max_stream_viewers'] ?? 0,
            'active_streams' => $stats['active_streams'] ?? 0,
            'hourly_stats' => $hourlyStats
        ];
    }
}