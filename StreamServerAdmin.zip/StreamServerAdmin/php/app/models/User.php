<?php
namespace App\Models;

use App\Core\Model;

/**
 * User Model
 */
class User extends Model
{
    protected $table = 'users';
    protected $fillable = [
        'username', 'password', 'email', 'full_name', 'role', 'is_admin'
    ];
    
    /**
     * Find a user by username
     */
    public function findByUsername($username)
    {
        return $this->firstWhere('username', $username);
    }
    
    /**
     * Find a user by email
     */
    public function findByEmail($email)
    {
        return $this->firstWhere('email', $email);
    }
    
    /**
     * Create a new user
     */
    public function register($data)
    {
        // Hash the password
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        
        // Default role and admin status
        $data['role'] = $data['role'] ?? 'user';
        $data['is_admin'] = $data['is_admin'] ?? false;
        
        return $this->create($data);
    }
    
    /**
     * Verify a user's password
     */
    public function verifyPassword($user, $password)
    {
        return password_verify($password, $user['password']);
    }
    
    /**
     * Log in a user
     */
    public function login($username, $password)
    {
        $user = $this->findByUsername($username);
        
        if (!$user) {
            return false;
        }
        
        if (!$this->verifyPassword($user, $password)) {
            return false;
        }
        
        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_admin'] = (bool)$user['is_admin'];
        
        return $user;
    }
    
    /**
     * Log out a user
     */
    public function logout()
    {
        unset($_SESSION['user_id']);
        unset($_SESSION['username']);
        unset($_SESSION['is_admin']);
        
        // Destroy the session
        session_destroy();
        
        // Start a new session
        session_start();
    }
    
    /**
     * Get all users with filtering options
     */
    public function getAll($limit = null, $offset = null, $orderBy = 'id', $order = 'ASC')
    {
        $sql = "SELECT * FROM {$this->table}";
        
        // Add ORDER BY clause
        $sql .= " ORDER BY {$orderBy} {$order}";
        
        // Add LIMIT and OFFSET clauses if provided
        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";
            
            if ($offset !== null) {
                $sql .= " OFFSET {$offset}";
            }
        }
        
        return $this->db->findAll($sql);
    }
}