<?php
namespace App\Models;

use App\Core\Model;

/**
 * Stream Model
 */
class Stream extends Model
{
    protected $table = 'streams';
    protected $fillable = [
        'title', 'description', 'stream_key', 'user_id', 'status',
        'started_at', 'ended_at', 'thumbnail_url', 'viewer_count',
        'max_viewers', 'is_recording', 'recording_path'
    ];
    
    /**
     * Find a stream by key
     */
    public function findByKey($streamKey)
    {
        return $this->firstWhere('stream_key', $streamKey);
    }
    
    /**
     * Get streams by user ID
     */
    public function getByUserId($userId, $limit = null, $offset = null, $orderBy = 'id', $order = 'DESC')
    {
        $sql = "SELECT * FROM {$this->table} WHERE user_id = :user_id";
        
        // Add ORDER BY clause
        $sql .= " ORDER BY {$orderBy} {$order}";
        
        // Add LIMIT and OFFSET clauses if provided
        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";
            
            if ($offset !== null) {
                $sql .= " OFFSET {$offset}";
            }
        }
        
        return $this->db->findAll($sql, ['user_id' => $userId]);
    }
    
    /**
     * Get active (live) streams
     */
    public function getActiveStreams($limit = null, $offset = null)
    {
        $sql = "SELECT s.*, u.username as username 
                FROM {$this->table} s
                JOIN users u ON s.user_id = u.id
                WHERE s.status = 'live'";
        
        // Add ORDER BY clause
        $sql .= " ORDER BY s.started_at DESC";
        
        // Add LIMIT and OFFSET clauses if provided
        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";
            
            if ($offset !== null) {
                $sql .= " OFFSET {$offset}";
            }
        }
        
        return $this->db->findAll($sql);
    }
    
    /**
     * Start a stream (mark as live)
     */
    public function startStream($streamId)
    {
        $now = date('Y-m-d H:i:s');
        
        $sql = "UPDATE {$this->table} 
                SET status = 'live', started_at = :started_at, viewer_count = 0, updated_at = :updated_at
                WHERE id = :id
                RETURNING *";
        
        return $this->db->find($sql, [
            'id' => $streamId,
            'started_at' => $now,
            'updated_at' => $now
        ]);
    }
    
    /**
     * End a stream (mark as offline)
     */
    public function endStream($streamId)
    {
        $now = date('Y-m-d H:i:s');
        
        $sql = "UPDATE {$this->table} 
                SET status = 'offline', ended_at = :ended_at, updated_at = :updated_at
                WHERE id = :id
                RETURNING *";
        
        return $this->db->find($sql, [
            'id' => $streamId,
            'ended_at' => $now,
            'updated_at' => $now
        ]);
    }
    
    /**
     * Update viewer count
     */
    public function updateViewerCount($streamId, $viewerCount)
    {
        $sql = "UPDATE {$this->table} 
                SET viewer_count = :viewer_count, 
                    max_viewers = GREATEST(max_viewers, :viewer_count),
                    updated_at = :updated_at
                WHERE id = :id
                RETURNING *";
        
        return $this->db->find($sql, [
            'id' => $streamId,
            'viewer_count' => $viewerCount,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Generate a unique stream key
     */
    public function generateStreamKey()
    {
        return md5(uniqid(rand(), true));
    }
    
    /**
     * Create a new stream
     */
    public function createStream($data)
    {
        // Generate a stream key if not provided
        if (!isset($data['stream_key']) || empty($data['stream_key'])) {
            $data['stream_key'] = $this->generateStreamKey();
        }
        
        // Set default values
        $data['status'] = $data['status'] ?? 'offline';
        $data['viewer_count'] = $data['viewer_count'] ?? 0;
        $data['max_viewers'] = $data['max_viewers'] ?? 0;
        $data['is_recording'] = $data['is_recording'] ?? false;
        
        return $this->create($data);
    }
}