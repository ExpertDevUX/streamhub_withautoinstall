<?php
namespace App\Models;

use App\Core\Model;

/**
 * Activity Model
 */
class Activity extends Model
{
    protected $table = 'activities';
    protected $fillable = [
        'user_id', 'type', 'entity_type', 'entity_id', 'message', 'details'
    ];
    
    /**
     * Log an activity
     */
    public function log($userId, $type, $entityType = null, $entityId = null, $message = null, $details = null)
    {
        // Generate a default message if none provided
        if (empty($message)) {
            $message = $this->generateDefaultMessage($type, $entityType, $entityId);
        }
        
        // Create activity record
        return $this->create([
            'user_id' => $userId,
            'type' => $type,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'message' => $message,
            'details' => is_array($details) ? json_encode($details) : $details
        ]);
    }
    
    /**
     * Get activities by user ID
     */
    public function getByUserId($userId, $limit = null, $offset = null)
    {
        $sql = "SELECT * FROM {$this->table} WHERE user_id = :user_id ORDER BY created_at DESC";
        
        // Add LIMIT and OFFSET if provided
        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";
            
            if ($offset !== null) {
                $sql .= " OFFSET {$offset}";
            }
        }
        
        return $this->db->findAll($sql, ['user_id' => $userId]);
    }
    
    /**
     * Get activities by entity
     */
    public function getByEntityId($entityType, $entityId, $limit = null)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE entity_type = :entity_type AND entity_id = :entity_id 
                ORDER BY created_at DESC";
        
        // Add LIMIT if provided
        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";
        }
        
        return $this->db->findAll($sql, [
            'entity_type' => $entityType,
            'entity_id' => $entityId
        ]);
    }
    
    /**
     * Get recent activities
     */
    public function getRecent($limit = 10)
    {
        $sql = "SELECT a.*, u.username 
                FROM {$this->table} a
                LEFT JOIN users u ON a.user_id = u.id
                ORDER BY a.created_at DESC
                LIMIT {$limit}";
        
        return $this->db->findAll($sql);
    }
    
    /**
     * Generate a default message based on activity type
     */
    private function generateDefaultMessage($type, $entityType, $entityId)
    {
        $message = "Activity recorded: {$type}";
        
        // Get entity name if possible
        if ($entityType && $entityId) {
            $entityName = $this->getEntityName($entityType, $entityId);
            if ($entityName) {
                $message = $this->formatMessageWithEntity($type, $entityType, $entityName);
            }
        }
        
        return $message;
    }
    
    /**
     * Get entity name
     */
    private function getEntityName($entityType, $entityId)
    {
        switch ($entityType) {
            case 'stream':
                $streamModel = new Stream();
                $stream = $streamModel->find($entityId);
                return $stream ? $stream['title'] : null;
                
            case 'user':
                $userModel = new User();
                $user = $userModel->find($entityId);
                return $user ? $user['username'] : null;
                
            case 'server':
                $serverModel = new Server();
                $server = $serverModel->find($entityId);
                return $server ? $server['name'] : null;
                
            default:
                return null;
        }
    }
    
    /**
     * Format message with entity name
     */
    private function formatMessageWithEntity($type, $entityType, $entityName)
    {
        switch ($type) {
            case 'stream_created':
                return "Stream \"{$entityName}\" was created";
                
            case 'stream_updated':
                return "Stream \"{$entityName}\" was updated";
                
            case 'stream_deleted':
                return "Stream \"{$entityName}\" was deleted";
                
            case 'stream_started':
                return "Stream \"{$entityName}\" went live";
                
            case 'stream_ended':
                return "Stream \"{$entityName}\" ended";
                
            case 'server_status_changed':
                return "Server \"{$entityName}\" status changed";
                
            case 'viewer_count_updated':
                return "Viewer count updated for \"{$entityName}\"";
                
            case 'user_created':
                return "User \"{$entityName}\" was created";
                
            case 'user_updated':
                return "User \"{$entityName}\" was updated";
                
            default:
                return "Activity recorded for {$entityType} \"{$entityName}\"";
        }
    }
}