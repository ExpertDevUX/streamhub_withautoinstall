<?php
namespace App\Models;

use App\Core\Model;

/**
 * Config Model
 * 
 * Handles application configuration storage and retrieval
 */
class Config extends Model
{
    /**
     * Table name
     */
    protected $table = 'configs';
    
    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->createConfigTable();
    }
    
    /**
     * Create config table if it doesn't exist
     */
    private function createConfigTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            value TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        $this->db->query($sql);
    }
    
    /**
     * Get configuration by name
     * 
     * @param string $name Configuration name
     * @return array|null Configuration data or null if not found
     */
    public function getConfiguration($name)
    {
        $sql = "SELECT * FROM {$this->table} WHERE name = :name";
        return $this->db->query($sql, ['name' => $name])->fetch();
    }
    
    /**
     * Save configuration
     * 
     * @param string $name Configuration name
     * @param array $data Configuration data
     * @return bool True if saved, false otherwise
     */
    public function saveConfiguration($name, $data)
    {
        // Convert data to JSON
        $value = json_encode($data);
        
        // Check if configuration already exists
        $existing = $this->getConfiguration($name);
        
        if ($existing) {
            // Update existing configuration
            $sql = "UPDATE {$this->table} SET value = :value, updated_at = CURRENT_TIMESTAMP WHERE name = :name";
            return $this->db->query($sql, ['name' => $name, 'value' => $value])->rowCount() > 0;
        } else {
            // Insert new configuration
            $sql = "INSERT INTO {$this->table} (name, value) VALUES (:name, :value)";
            return $this->db->query($sql, ['name' => $name, 'value' => $value])->rowCount() > 0;
        }
    }
    
    /**
     * Delete configuration
     * 
     * @param string $name Configuration name
     * @return bool True if deleted, false otherwise
     */
    public function deleteConfiguration($name)
    {
        $sql = "DELETE FROM {$this->table} WHERE name = :name";
        return $this->db->query($sql, ['name' => $name])->rowCount() > 0;
    }
    
    /**
     * Get all configurations
     * 
     * @return array All configurations
     */
    public function getAllConfigurations()
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY name";
        return $this->db->query($sql)->fetchAll();
    }
    
    /**
     * Export all configurations
     * 
     * @return array Configurations in key-value format
     */
    public function exportConfigurations()
    {
        $configs = $this->getAllConfigurations();
        $result = [];
        
        foreach ($configs as $config) {
            $result[$config['name']] = json_decode($config['value'], true);
        }
        
        return $result;
    }
    
    /**
     * Import configurations
     * 
     * @param array $configs Configurations in key-value format
     * @return bool True if imported, false otherwise
     */
    public function importConfigurations($configs)
    {
        try {
            $this->db->beginTransaction();
            
            foreach ($configs as $name => $value) {
                $this->saveConfiguration($name, $value);
            }
            
            $this->db->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
    
    /**
     * Reset configuration to default
     * 
     * @param string $name Configuration name
     * @return bool True if reset, false otherwise
     */
    public function resetConfiguration($name)
    {
        $defaults = [
            'interface' => [
                'site_name' => 'Stream Manager',
                'theme' => 'light',
                'logo_url' => '',
                'primary_color' => '#0d6efd',
                'secondary_color' => '#6c757d',
                'show_footer' => true,
                'dashboard_layout' => 'cards',
                'stream_preview_size' => 'medium',
                'enable_animations' => true,
                'custom_css' => ''
            ],
            'system' => [
                'debug_mode' => false,
                'log_level' => 'error',
                'maintenance_mode' => false,
                'maintenance_message' => 'The site is currently under maintenance. Please check back later.',
                'cache_enabled' => true,
                'cache_lifetime' => 3600,
                'session_lifetime' => 86400,
                'max_upload_size' => 100,
                'allowed_file_types' => 'jpg,jpeg,png,gif,mp4,webm',
                'timezone' => 'UTC'
            ],
            'rtmp' => [
                'default_rtmp_port' => 1935,
                'hls_enabled' => true,
                'hls_fragment_duration' => 2,
                'hls_playlist_length' => 30,
                'recording_enabled' => false,
                'recording_path' => '/var/www/html/recordings',
                'recording_format' => 'flv',
                'low_latency_mode' => false,
                'authentication_required' => true,
                'authentication_token_lifetime' => 3600
            ]
        ];
        
        if (isset($defaults[$name])) {
            return $this->saveConfiguration($name, $defaults[$name]);
        }
        
        return false;
    }
}