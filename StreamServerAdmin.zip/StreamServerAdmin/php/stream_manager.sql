-- Stream Manager Database Schema
-- Created: $(date)

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  full_name VARCHAR(255),
  role VARCHAR(50) DEFAULT 'user',
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Streams Table
CREATE TABLE IF NOT EXISTS streams (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  stream_key VARCHAR(255) NOT NULL UNIQUE,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(50) DEFAULT 'offline',
  started_at TIMESTAMP WITH TIME ZONE,
  ended_at TIMESTAMP WITH TIME ZONE,
  thumbnail_url VARCHAR(255),
  viewer_count INTEGER DEFAULT 0,
  max_viewers INTEGER DEFAULT 0,
  is_recording BOOLEAN DEFAULT FALSE,
  recording_path VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Servers Table
CREATE TABLE IF NOT EXISTS servers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  host VARCHAR(255) NOT NULL,
  port INTEGER DEFAULT 1935,
  status VARCHAR(50) DEFAULT 'offline',
  server_type VARCHAR(50) DEFAULT 'rtmp',
  region VARCHAR(100),
  provider VARCHAR(100),
  is_default BOOLEAN DEFAULT FALSE,
  config JSONB,
  capacity INTEGER DEFAULT 100,
  current_load INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Activities Table
CREATE TABLE IF NOT EXISTS activities (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  action VARCHAR(255) NOT NULL,
  entity_type VARCHAR(50),
  entity_id INTEGER,
  details JSONB,
  ip_address VARCHAR(45),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Integrations Table
CREATE TABLE IF NOT EXISTS integrations (
  id SERIAL PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  config JSONB NOT NULL,
  is_enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Cloud Providers Table
CREATE TABLE IF NOT EXISTS cloud_providers (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  provider_type VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  credentials JSONB NOT NULL,
  region VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Bandwidth Allocations Table
CREATE TABLE IF NOT EXISTS bandwidth_allocations (
  id SERIAL PRIMARY KEY,
  server_id INTEGER REFERENCES servers(id) ON DELETE CASCADE,
  stream_id INTEGER REFERENCES streams(id) ON DELETE SET NULL,
  allocated_bandwidth INTEGER NOT NULL,
  used_bandwidth INTEGER DEFAULT 0,
  start_time TIMESTAMP WITH TIME ZONE,
  end_time TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Quality Profiles Table
CREATE TABLE IF NOT EXISTS quality_profiles (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  resolution VARCHAR(50) NOT NULL,
  bitrate INTEGER NOT NULL,
  fps INTEGER DEFAULT 30,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Site Configuration Table
CREATE TABLE IF NOT EXISTS site_config (
  id SERIAL PRIMARY KEY,
  site_name VARCHAR(255) DEFAULT 'Stream Manager',
  logo_url VARCHAR(255),
  primary_color VARCHAR(50) DEFAULT '#4F46E5',
  allow_registration BOOLEAN DEFAULT TRUE,
  require_email_verification BOOLEAN DEFAULT FALSE,
  smtp_config JSONB,
  maintenance_mode BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, email, full_name, role, is_admin)
VALUES ('admin', '$2y$10$KLEn6dUwf4ipIc3aIIkOD.PWbCgjvhfIZ2vUTLTJ3v9x3ZRDPuAGe', 'admin@example.com', 'Administrator', 'admin', TRUE)
ON CONFLICT (username) DO NOTHING;

-- Insert default quality profiles
INSERT INTO quality_profiles (name, resolution, bitrate, fps, is_default)
VALUES
('Low', '480p', 1000000, 30, FALSE),
('Medium', '720p', 2500000, 30, TRUE),
('High', '1080p', 5000000, 30, FALSE),
('Ultra', '1080p', 8000000, 60, FALSE)
ON CONFLICT DO NOTHING;

-- Insert default site configuration
INSERT INTO site_config (site_name, primary_color, allow_registration)
VALUES ('Stream Manager', '#4F46E5', TRUE)
ON CONFLICT DO NOTHING;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_streams_user_id ON streams(user_id);
CREATE INDEX IF NOT EXISTS idx_activities_user_id ON activities(user_id);
CREATE INDEX IF NOT EXISTS idx_cloud_providers_user_id ON cloud_providers(user_id);
CREATE INDEX IF NOT EXISTS idx_streams_status ON streams(status);