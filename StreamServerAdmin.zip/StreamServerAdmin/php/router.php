<?php
/**
 * Development server router
 * This script handles routing for the PHP development server
 */

// Get the requested URI
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Check if the file exists in the public directory
if ($uri !== '/' && file_exists(__DIR__ . '/public' . $uri)) {
    // If the file exists, return it directly
    return false;
}

// Otherwise, route everything to index.php
require_once __DIR__ . '/public/index.php';
?>