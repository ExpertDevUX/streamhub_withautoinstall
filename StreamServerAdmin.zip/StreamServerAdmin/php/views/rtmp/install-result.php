<?php
$title = 'RTMP Server Installation';
include ROOT_PATH . '/views/layouts/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>RTMP Server Installation</h1>
        <a href="/rtmp" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Servers
        </a>
    </div>
    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <?php if ($result['success']): ?>
                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                <?php else: ?>
                    <i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>
                <?php endif; ?>
                <?= $result['message'] ?>
            </h5>
        </div>
        <div class="card-body">
            <p><?= $result['details'] ?></p>
            
            <?php if ($result['success'] && isset($result['script'])): ?>
                <!-- Remote installation instructions -->
                <div class="alert alert-info">
                    <h6><i class="bi bi-info-circle-fill me-2"></i> Remote Installation Instructions</h6>
                    <p>Follow these steps to install the RTMP server on <strong><?= htmlspecialchars($result['server']['host']) ?></strong>:</p>
                    
                    <ol>
                        <li>Connect to your server via SSH</li>
                        <li>Create an installation script file:</li>
                    </ol>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <code>nano rtmp-install.sh</code>
                            <button class="btn btn-sm btn-outline-secondary copy-btn" data-target="installation-script">
                                <i class="bi bi-clipboard"></i> Copy
                            </button>
                        </div>
                        <pre class="bg-dark text-light p-3 rounded" id="installation-script" style="max-height: 300px; overflow-y: auto;"><?= htmlspecialchars($result['script']) ?></pre>
                    </div>
                    
                    <ol start="3">
                        <li>Make the script executable:</li>
                    </ol>
                    
                    <div class="mb-3">
                        <code>chmod +x rtmp-install.sh</code>
                    </div>
                    
                    <ol start="4">
                        <li>Run the installation command:</li>
                    </ol>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <code><?= htmlspecialchars($result['command']) ?></code>
                            <button class="btn btn-sm btn-outline-secondary copy-btn" data-target="installation-command">
                                <i class="bi bi-clipboard"></i> Copy
                            </button>
                        </div>
                        <pre class="bg-dark text-light p-3 rounded" id="installation-command"><?= htmlspecialchars($result['command']) ?></pre>
                    </div>
                    
                    <ol start="5">
                        <li>Once installation is complete, check if the server is running:</li>
                    </ol>
                    
                    <div class="mb-3">
                        <code>systemctl status nginx-rtmp</code>
                    </div>
                    
                    <div class="alert alert-warning">
                        <h6><i class="bi bi-shield-fill-exclamation me-2"></i> Firewall Configuration</h6>
                        <p>Make sure to open the following ports in your firewall:</p>
                        <ul>
                            <li>HTTP: Port 80 (for HLS streaming)</li>
                            <li>RTMP: Port <?= htmlspecialchars($result['server']['port']) ?></li>
                        </ul>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h6>After Installation</h6>
                    <p>Once the RTMP server is installed and running, you can:</p>
                    <ul>
                        <li>Stream to: <code>rtmp://<?= htmlspecialchars($result['server']['host']) ?>:<?= htmlspecialchars($result['server']['port']) ?>/live/STREAM_KEY</code></li>
                        <li>Watch via HLS: <code>http://<?= htmlspecialchars($result['server']['host']) ?>/hls/STREAM_KEY.m3u8</code></li>
                    </ul>
                    <p>Replace <code>STREAM_KEY</code> with the stream key from your streams.</p>
                </div>
            <?php elseif (!$result['success']): ?>
                <!-- Installation error -->
                <div class="alert alert-danger">
                    <h6><i class="bi bi-exclamation-octagon-fill me-2"></i> Installation Error</h6>
                    <p><?= $result['details'] ?></p>
                </div>
                
                <div class="mt-4">
                    <h6>Troubleshooting Steps</h6>
                    <ul>
                        <li>Check if you have sufficient permissions to install software</li>
                        <li>Make sure the ports are not already in use</li>
                        <li>Check server logs for more detailed error information</li>
                        <li>Ensure the server has internet connectivity to download packages</li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="mt-4 text-center">
        <a href="/rtmp" class="btn btn-primary">Return to RTMP Server Management</a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Copy button functionality
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);
            const text = targetElement.textContent;
            
            navigator.clipboard.writeText(text).then(() => {
                // Change button text temporarily
                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i> Copied!';
                
                setTimeout(() => {
                    this.innerHTML = originalHtml;
                }, 2000);
            });
        });
    });
});
</script>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>