<!-- Hero Section -->
<section class="bg-primary text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">Stream Manager</h1>
                <p class="lead mb-4">A powerful video stream server management platform that simplifies complex server operations through intuitive design and intelligent automation.</p>
                <div class="d-flex gap-3">
                    <a href="/register" class="btn btn-light btn-lg">Get Started</a>
                    <a href="#features" class="btn btn-outline-light btn-lg">Learn More</a>
                </div>
            </div>
            <div class="col-lg-6 d-none d-lg-block">
                <img src="/images/streaming-illustration.svg" alt="Streaming Illustration" class="img-fluid">
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5" id="features">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Powerful Features</h2>
            <p class="lead text-muted">Everything you need to manage your streaming infrastructure</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-camera-video text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">RTMP Server Management</h4>
                        <p class="card-text">Automatic installation and configuration of RTMP servers with intelligent health monitoring.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-graph-up text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">Real-time Metrics</h4>
                        <p class="card-text">Monitor server performance, bandwidth usage, and viewer statistics in real-time.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-shield-check text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">SSL Management</h4>
                        <p class="card-text">Automatic SSL certificate installation and renewal for secure streaming.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-code-square text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">Embedding Options</h4>
                        <p class="card-text">Easily embed streams on websites with iframe, widget, or shortcode options.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-wordpress text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">WordPress Integration</h4>
                        <p class="card-text">Seamless integration with WordPress through the WpStream plugin.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-cloud-arrow-up text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <h4 class="card-title">Cloud Integration</h4>
                        <p class="card-text">Deploy and manage streaming servers on AWS and other cloud providers.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="fw-bold mb-3">Ready to Streamline Your Streaming?</h2>
                <p class="lead mb-4">Start managing your streaming infrastructure with ease today.</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="/register" class="btn btn-primary btn-lg">Sign Up Now</a>
                    <a href="/login" class="btn btn-outline-primary btn-lg">Login</a>
                </div>
            </div>
        </div>
    </div>
</section>