<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode - <?= $GLOBALS['SITE_NAME'] ?? 'Stream Manager' ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        
        .maintenance-container {
            max-width: 600px;
            padding: 2rem;
            text-align: center;
        }
        
        .maintenance-icon {
            font-size: 5rem;
            color: #6c757d;
            margin-bottom: 1rem;
        }
        
        .maintenance-title {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .maintenance-message {
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="maintenance-icon">
            <i class="bi bi-tools"></i>
        </div>
        
        <h1 class="maintenance-title">Under Maintenance</h1>
        
        <p class="maintenance-message">
            <?= htmlspecialchars($GLOBALS['MAINTENANCE_MESSAGE'] ?? 'The site is currently under maintenance. Please check back later.') ?>
        </p>
        
        <div class="d-flex justify-content-center gap-3">
            <a href="/login" class="btn btn-outline-secondary">
                <i class="bi bi-box-arrow-in-right me-2"></i> Admin Login
            </a>
            <a href="javascript:window.location.reload(true)" class="btn btn-primary">
                <i class="bi bi-arrow-clockwise me-2"></i> Refresh Page
            </a>
        </div>
    </div>
</body>
</html>