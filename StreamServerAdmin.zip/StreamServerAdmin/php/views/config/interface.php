<?php
$title = 'Interface Configuration';
include ROOT_PATH . '/views/layouts/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Interface Configuration</h1>
        <div>
            <button id="reset-config" class="btn btn-outline-warning me-2">
                <i class="bi bi-arrow-counterclockwise"></i> Reset to Default
            </button>
            <a href="/dashboard" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] === 'error' ? 'danger' : $_SESSION['flash']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="list-group">
                <a href="/config/interface" class="list-group-item list-group-item-action active">
                    <i class="bi bi-brush me-2"></i> Interface
                </a>
                <a href="/config/system" class="list-group-item list-group-item-action">
                    <i class="bi bi-gear me-2"></i> System
                </a>
                <a href="/config/rtmp" class="list-group-item list-group-item-action">
                    <i class="bi bi-camera-video me-2"></i> RTMP
                </a>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Preview</h5>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <div id="preview-container" class="p-3 rounded mb-3" style="background-color: <?= $config['theme'] === 'dark' ? '#212529' : '#f8f9fa' ?>; color: <?= $config['theme'] === 'dark' ? '#fff' : '#212529' ?>;">
                            <?php if (!empty($config['logo_url'])): ?>
                                <img src="<?= htmlspecialchars($config['logo_url']) ?>" alt="Logo" class="img-fluid mb-2" style="max-height: 40px;">
                            <?php endif; ?>
                            <h5 id="preview-site-name"><?= htmlspecialchars($config['site_name']) ?></h5>
                            <div class="d-flex justify-content-center gap-2">
                                <button class="btn btn-sm" style="background-color: <?= htmlspecialchars($config['primary_color']) ?>; color: white;">Primary</button>
                                <button class="btn btn-sm" style="background-color: <?= htmlspecialchars($config['secondary_color']) ?>; color: white;">Secondary</button>
                            </div>
                        </div>
                        <small class="text-muted">Live preview of your settings</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-body">
                    <form action="/config/save-interface" method="post">
                        <h4 class="mb-3">General Settings</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="site_name" class="form-label">Site Name</label>
                                    <input type="text" class="form-control" id="site_name" name="site_name" value="<?= htmlspecialchars($config['site_name']) ?>" required>
                                    <div class="form-text">The name of your streaming platform</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="logo_url" class="form-label">Logo URL</label>
                                    <input type="url" class="form-control" id="logo_url" name="logo_url" value="<?= htmlspecialchars($config['logo_url']) ?>">
                                    <div class="form-text">URL to your logo image (optional)</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="theme" class="form-label">Theme</label>
                                    <select class="form-select" id="theme" name="theme">
                                        <?php foreach ($themes as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['theme'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">The visual theme for your application</div>
                                </div>
                                
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="show_footer" name="show_footer" <?= $config['show_footer'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="show_footer">Show Footer</label>
                                </div>
                                
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="enable_animations" name="enable_animations" <?= $config['enable_animations'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="enable_animations">Enable UI Animations</label>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">Colors</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="primary_color" class="form-label">Primary Color</label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color" id="primary_color_picker" value="<?= htmlspecialchars($config['primary_color']) ?>">
                                        <input type="text" class="form-control" id="primary_color" name="primary_color" value="<?= htmlspecialchars($config['primary_color']) ?>" pattern="#[a-fA-F0-9]{6}">
                                    </div>
                                    <div class="form-text">Main color for buttons and highlights</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="secondary_color" class="form-label">Secondary Color</label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color" id="secondary_color_picker" value="<?= htmlspecialchars($config['secondary_color']) ?>">
                                        <input type="text" class="form-control" id="secondary_color" name="secondary_color" value="<?= htmlspecialchars($config['secondary_color']) ?>" pattern="#[a-fA-F0-9]{6}">
                                    </div>
                                    <div class="form-text">Color for secondary elements</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">Layout Options</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="dashboard_layout" class="form-label">Dashboard Layout</label>
                                    <select class="form-select" id="dashboard_layout" name="dashboard_layout">
                                        <?php foreach ($dashboardLayouts as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['dashboard_layout'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">How dashboard items are arranged</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="stream_preview_size" class="form-label">Stream Preview Size</label>
                                    <select class="form-select" id="stream_preview_size" name="stream_preview_size">
                                        <?php foreach ($previewSizes as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['stream_preview_size'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">Default size for stream previews</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">Advanced</h4>
                        
                        <div class="mb-4">
                            <label for="custom_css" class="form-label">Custom CSS</label>
                            <textarea class="form-control font-monospace" id="custom_css" name="custom_css" rows="5"><?= htmlspecialchars($config['custom_css']) ?></textarea>
                            <div class="form-text">Add custom CSS to customize your site's appearance</div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <button type="reset" class="btn btn-outline-secondary me-2">Reset Form</button>
                            <button type="submit" class="btn btn-primary">Save Configuration</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Color picker sync
    const primaryColorPicker = document.getElementById('primary_color_picker');
    const primaryColorInput = document.getElementById('primary_color');
    const secondaryColorPicker = document.getElementById('secondary_color_picker');
    const secondaryColorInput = document.getElementById('secondary_color');
    
    // Sync primary color
    primaryColorPicker.addEventListener('input', function() {
        primaryColorInput.value = this.value;
        updatePreview();
    });
    
    primaryColorInput.addEventListener('input', function() {
        if (/^#[0-9A-F]{6}$/i.test(this.value)) {
            primaryColorPicker.value = this.value;
            updatePreview();
        }
    });
    
    // Sync secondary color
    secondaryColorPicker.addEventListener('input', function() {
        secondaryColorInput.value = this.value;
        updatePreview();
    });
    
    secondaryColorInput.addEventListener('input', function() {
        if (/^#[0-9A-F]{6}$/i.test(this.value)) {
            secondaryColorPicker.value = this.value;
            updatePreview();
        }
    });
    
    // Live preview updates
    const siteNameInput = document.getElementById('site_name');
    const themeSelect = document.getElementById('theme');
    const logoUrlInput = document.getElementById('logo_url');
    
    siteNameInput.addEventListener('input', updatePreview);
    themeSelect.addEventListener('change', updatePreview);
    logoUrlInput.addEventListener('input', updatePreview);
    
    function updatePreview() {
        const previewContainer = document.getElementById('preview-container');
        const previewSiteName = document.getElementById('preview-site-name');
        
        // Update site name
        previewSiteName.textContent = siteNameInput.value;
        
        // Update colors
        const primaryButtons = previewContainer.querySelectorAll('.btn:first-child');
        const secondaryButtons = previewContainer.querySelectorAll('.btn:last-child');
        
        primaryButtons.forEach(button => {
            button.style.backgroundColor = primaryColorInput.value;
        });
        
        secondaryButtons.forEach(button => {
            button.style.backgroundColor = secondaryColorInput.value;
        });
        
        // Update theme
        if (themeSelect.value === 'light') {
            previewContainer.style.backgroundColor = '#f8f9fa';
            previewContainer.style.color = '#212529';
        } else if (themeSelect.value === 'dark') {
            previewContainer.style.backgroundColor = '#212529';
            previewContainer.style.color = '#f8f9fa';
        }
    }
    
    // Reset configuration button
    document.getElementById('reset-config').addEventListener('click', function() {
        if (confirm('Are you sure you want to reset to default settings? This cannot be undone.')) {
            window.location.href = '/config/reset/interface';
        }
    });
});
</script>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>