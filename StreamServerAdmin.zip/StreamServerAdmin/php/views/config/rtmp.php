<?php
$title = 'RTMP Configuration';
include ROOT_PATH . '/views/layouts/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>RTMP Configuration</h1>
        <div>
            <button id="reset-config" class="btn btn-outline-warning me-2">
                <i class="bi bi-arrow-counterclockwise"></i> Reset to Default
            </button>
            <a href="/dashboard" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] === 'error' ? 'danger' : $_SESSION['flash']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="list-group">
                <a href="/config/interface" class="list-group-item list-group-item-action">
                    <i class="bi bi-brush me-2"></i> Interface
                </a>
                <a href="/config/system" class="list-group-item list-group-item-action">
                    <i class="bi bi-gear me-2"></i> System
                </a>
                <a href="/config/rtmp" class="list-group-item list-group-item-action active">
                    <i class="bi bi-camera-video me-2"></i> RTMP
                </a>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">RTMP Information</h5>
                </div>
                <div class="card-body">
                    <p class="small">
                        RTMP (Real-Time Messaging Protocol) is used for streaming media content over the internet.
                        These settings affect how new RTMP servers are configured by default.
                    </p>
                    
                    <div class="alert alert-info small">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Changes to these settings will apply to new server installations only. Existing servers must be reconfigured manually.
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-body">
                    <form action="/config/save-rtmp" method="post">
                        <h4 class="mb-3">Server Configuration</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="default_rtmp_port" class="form-label">Default RTMP Port</label>
                                    <input type="number" class="form-control" id="default_rtmp_port" name="default_rtmp_port" value="<?= intval($config['default_rtmp_port']) ?>" min="1" max="65535" required>
                                    <div class="form-text">Standard RTMP port is 1935</div>
                                </div>
                                
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="low_latency_mode" name="low_latency_mode" <?= $config['low_latency_mode'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="low_latency_mode">Low Latency Mode</label>
                                    <div class="form-text">Optimize for lower latency (may reduce quality)</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="authentication_required" name="authentication_required" <?= $config['authentication_required'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="authentication_required">Require Authentication</label>
                                    <div class="form-text">Require valid stream keys for publishing</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="authentication_token_lifetime" class="form-label">Token Lifetime (seconds)</label>
                                    <input type="number" class="form-control" id="authentication_token_lifetime" name="authentication_token_lifetime" value="<?= intval($config['authentication_token_lifetime']) ?>" min="60" max="86400">
                                    <div class="form-text">How long stream keys remain valid</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">HLS Configuration</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="hls_enabled" name="hls_enabled" <?= $config['hls_enabled'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="hls_enabled">Enable HLS</label>
                                    <div class="form-text">Convert RTMP streams to HLS for browser playback</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="hls_fragment_duration" class="form-label">HLS Fragment Duration (seconds)</label>
                                    <input type="number" class="form-control" id="hls_fragment_duration" name="hls_fragment_duration" value="<?= intval($config['hls_fragment_duration']) ?>" min="1" max="10" step="1">
                                    <div class="form-text">Length of each HLS segment</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="hls_playlist_length" class="form-label">HLS Playlist Length (seconds)</label>
                                    <input type="number" class="form-control" id="hls_playlist_length" name="hls_playlist_length" value="<?= intval($config['hls_playlist_length']) ?>" min="10" max="300" step="5">
                                    <div class="form-text">Total length of the HLS playlist</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">Recording Configuration</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="recording_enabled" name="recording_enabled" <?= $config['recording_enabled'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="recording_enabled">Enable Recording</label>
                                    <div class="form-text">Save streams to disk automatically</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="recording_format" class="form-label">Recording Format</label>
                                    <select class="form-select" id="recording_format" name="recording_format">
                                        <?php foreach ($recordingFormats as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['recording_format'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">File format for recorded streams</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="recording_path" class="form-label">Recording Path</label>
                                    <input type="text" class="form-control" id="recording_path" name="recording_path" value="<?= htmlspecialchars($config['recording_path']) ?>">
                                    <div class="form-text">Directory where recordings are stored</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <button type="reset" class="btn btn-outline-secondary me-2">Reset Form</button>
                            <button type="submit" class="btn btn-primary">Save Configuration</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Current RTMP Servers</h5>
                    <a href="/rtmp" class="btn btn-sm btn-outline-primary">Manage Servers</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Host</th>
                                    <th>Port</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody id="rtmp-servers-list">
                                <tr>
                                    <td colspan="4" class="text-center">Loading servers...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Reset configuration button
    document.getElementById('reset-config').addEventListener('click', function() {
        if (confirm('Are you sure you want to reset to default settings? This cannot be undone.')) {
            window.location.href = '/config/reset/rtmp';
        }
    });
    
    // Load RTMP servers
    fetch('/rtmp/list-json')
        .then(response => response.json())
        .then(data => {
            const serversList = document.getElementById('rtmp-servers-list');
            
            if (data.success && data.servers && data.servers.length > 0) {
                let html = '';
                
                data.servers.forEach(server => {
                    const statusClass = {
                        'online': 'success',
                        'offline': 'danger',
                        'unknown': 'secondary'
                    }[server.status] || 'secondary';
                    
                    html += `
                        <tr>
                            <td>${server.name}</td>
                            <td>${server.host}</td>
                            <td>${server.port}</td>
                            <td><span class="badge bg-${statusClass}">${server.status}</span></td>
                        </tr>
                    `;
                });
                
                serversList.innerHTML = html;
            } else {
                serversList.innerHTML = '<tr><td colspan="4" class="text-center">No RTMP servers found</td></tr>';
            }
        })
        .catch(error => {
            console.error('Error loading RTMP servers:', error);
            const serversList = document.getElementById('rtmp-servers-list');
            serversList.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Error loading servers</td></tr>';
        });
});
</script>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>