    <?php 
    // Get interface configuration
    $interfaceConfig = \App\Core\ConfigManager::get('interface');
    $showFooter = $interfaceConfig['show_footer'] ?? true;
    
    if ($showFooter):
    ?>
    <!-- Footer -->
    <footer class="footer mt-auto py-3 <?= ($interfaceConfig['theme'] ?? '') === 'dark' ? 'bg-dark text-light' : 'bg-light' ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0 <?= ($interfaceConfig['theme'] ?? '') === 'dark' ? 'text-light' : 'text-muted' ?>">&copy; <?= date('Y') ?> <?= $GLOBALS['SITE_NAME'] ?? 'Stream Manager' ?>. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0 <?= ($interfaceConfig['theme'] ?? '') === 'dark' ? 'text-light' : 'text-muted' ?>">Version 1.0.0</p>
                </div>
            </div>
        </div>
    </footer>
    <?php endif; ?>
    
    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="/js/script.js"></script>
    
    <?php if ($GLOBALS['RTMP_CONFIG']['low_latency_mode'] ?? false): ?>
    <!-- Low latency mode settings for video -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Find all video players and apply low latency settings
        const videoElements = document.querySelectorAll('video');
        videoElements.forEach(video => {
            video.setAttribute('playsinline', '');
            video.setAttribute('muted', '');
            video.setAttribute('autoplay', '');
            
            if (video.hasAttribute('data-hls-url')) {
                // Configure HLS.js with low latency settings
                if (typeof Hls !== 'undefined') {
                    const hls = new Hls({
                        enableWorker: true,
                        lowLatencyMode: true,
                        backBufferLength: 30,
                        liveSyncDuration: 0.5,
                        liveMaxLatencyDuration: 5,
                        liveDurationInfinity: true
                    });
                    hls.loadSource(video.getAttribute('data-hls-url'));
                    hls.attachMedia(video);
                }
            }
        });
    });
    </script>
    <?php endif; ?>
</body>
</html>