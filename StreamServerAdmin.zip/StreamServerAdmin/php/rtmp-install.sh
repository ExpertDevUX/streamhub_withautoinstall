#!/bin/bash

# RTMP Server Installation Script for Stream Manager
# This script installs and configures an RTMP server with Nginx and the RTMP module

# Default configuration
RTMP_PORT=1935
HTTP_PORT=80
HLS_ENABLED=true
HLS_FRAGMENT=2
HLS_PLAYLIST=10
RECORDING_ENABLED=false
RECORDING_PATH="/var/www/html/recordings"
LOW_LATENCY=false
INSTALL_DIR="/usr/local/nginx-rtmp"
AUTO_START=true
SERVER_NAME="localhost"
VPS_SIZE="standard"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --rtmp-port)
      RTMP_PORT="$2"
      shift 2
      ;;
    --http-port)
      HTTP_PORT="$2"
      shift 2
      ;;
    --no-hls)
      HLS_ENABLED=false
      shift
      ;;
    --hls-fragment)
      HLS_FRAGMENT="$2"
      shift 2
      ;;
    --hls-playlist)
      HLS_PLAYLIST="$2"
      shift 2
      ;;
    --enable-recording)
      RECORDING_ENABLED=true
      shift
      ;;
    --recording-path)
      RECORDING_PATH="$2"
      shift 2
      ;;
    --low-latency)
      LOW_LATENCY=true
      shift
      ;;
    --install-dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --no-autostart)
      AUTO_START=false
      shift
      ;;
    --server-name)
      SERVER_NAME="$2"
      shift 2
      ;;
    --vps-size)
      VPS_SIZE="$2"
      shift 2
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# Print configuration
echo "========================================="
echo "RTMP Server Installation Configuration:"
echo "========================================="
echo "RTMP Port: $RTMP_PORT"
echo "HTTP Port: $HTTP_PORT"
echo "HLS Enabled: $HLS_ENABLED"
echo "HLS Fragment Duration: $HLS_FRAGMENT seconds"
echo "HLS Playlist Length: $HLS_PLAYLIST segments"
echo "Recording Enabled: $RECORDING_ENABLED"
echo "Recording Path: $RECORDING_PATH"
echo "Low Latency Mode: $LOW_LATENCY"
echo "Installation Directory: $INSTALL_DIR"
echo "Auto Start: $AUTO_START"
echo "Server Name: $SERVER_NAME"
echo "VPS Size: $VPS_SIZE"
echo "========================================="
echo ""

# Check if running as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# Function to detect OS
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
    elif [ -f /etc/redhat-release ]; then
        OS=$(cat /etc/redhat-release | awk '{print tolower($1)}')
        VERSION=$(cat /etc/redhat-release | grep -o '[0-9]\+\.[0-9]\+' | head -n1)
    else
        OS=$(uname -s)
        VERSION=$(uname -r)
    fi
    
    echo "Detected OS: $OS $VERSION"
}

# Function to install dependencies
install_dependencies() {
    echo "Installing dependencies..."
    
    case $OS in
        debian|ubuntu)
            apt-get update
            apt-get install -y build-essential libpcre3-dev libssl-dev zlib1g-dev wget ffmpeg
            
            if [ "$HLS_ENABLED" = true ]; then
                apt-get install -y ffmpeg
            fi
            ;;
        centos|fedora|rhel)
            yum -y install epel-release
            yum -y install gcc gcc-c++ make pcre-devel openssl-devel zlib-devel wget
            
            if [ "$HLS_ENABLED" = true ]; then
                yum -y install ffmpeg
            fi
            ;;
        *)
            echo "Unsupported OS: $OS"
            exit 1
            ;;
    esac
    
    echo "Dependencies installed successfully"
}

# Function to download and install Nginx with RTMP module
install_nginx_rtmp() {
    echo "Installing Nginx with RTMP module..."
    
    # Create installation directory
    mkdir -p $INSTALL_DIR
    cd $INSTALL_DIR
    
    # Download Nginx
    NGINX_VERSION="1.22.1"
    wget https://nginx.org/download/nginx-$NGINX_VERSION.tar.gz
    tar -xf nginx-$NGINX_VERSION.tar.gz
    
    # Download RTMP module
    RTMP_VERSION="1.2.2"
    wget https://github.com/arut/nginx-rtmp-module/archive/v$RTMP_VERSION.tar.gz
    tar -xf v$RTMP_VERSION.tar.gz
    
    # Configure and compile Nginx with RTMP module
    cd nginx-$NGINX_VERSION
    
    # Adjust worker processes based on VPS size
    WORKER_PROCESSES=1
    case $VPS_SIZE in
        small)
            WORKER_PROCESSES=1
            ;;
        standard)
            WORKER_PROCESSES=2
            ;;
        large)
            WORKER_PROCESSES=4
            ;;
        *)
            WORKER_PROCESSES=auto
            ;;
    esac
    
    # Configure options
    CONFIGURE_OPTIONS="--prefix=$INSTALL_DIR \
                      --with-http_ssl_module \
                      --with-http_v2_module \
                      --with-http_flv_module \
                      --with-http_mp4_module \
                      --with-http_stub_status_module \
                      --with-threads \
                      --with-file-aio \
                      --with-cc-opt='-O2' \
                      --with-add-module=../nginx-rtmp-module-$RTMP_VERSION"
    
    # Add low latency options if enabled
    if [ "$LOW_LATENCY" = true ]; then
        CONFIGURE_OPTIONS="$CONFIGURE_OPTIONS --with-cc-opt='-O3'"
    fi
    
    # Configure and make
    ./configure $CONFIGURE_OPTIONS
    make -j$(nproc)
    make install
    
    echo "Nginx with RTMP module installed successfully"
}

# Function to configure Nginx
configure_nginx() {
    echo "Configuring Nginx..."
    
    # Create necessary directories
    mkdir -p $INSTALL_DIR/logs
    mkdir -p $INSTALL_DIR/conf/sites-enabled
    
    if [ "$RECORDING_ENABLED" = true ]; then
        mkdir -p $RECORDING_PATH
        chmod -R 755 $RECORDING_PATH
    fi
    
    if [ "$HLS_ENABLED" = true ]; then
        mkdir -p $INSTALL_DIR/html/hls
        chmod -R 755 $INSTALL_DIR/html/hls
    fi
    
    # Create main configuration file
    cat > $INSTALL_DIR/conf/nginx.conf << EOF
worker_processes $WORKER_PROCESSES;
worker_rlimit_nofile 8192;

events {
    worker_connections 4096;
    multi_accept on;
    use epoll;
}

http {
    include mime.types;
    default_type application/octet-stream;
    
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    
    access_log logs/access.log;
    error_log logs/error.log;
    
    server {
        listen $HTTP_PORT;
        server_name $SERVER_NAME;
        
        location / {
            root html;
            index index.html;
        }
        
        # Status JSON API
        location /status {
            stub_status on;
            access_log off;
            allow 127.0.0.1;
            deny all;
        }
EOF
    
    # Add HLS configuration if enabled
    if [ "$HLS_ENABLED" = true ]; then
        cat >> $INSTALL_DIR/conf/nginx.conf << EOF
        
        # HLS streaming
        location /hls {
            root html;
            add_header Cache-Control no-cache;
            add_header 'Access-Control-Allow-Origin' '*' always;
            add_header 'Access-Control-Expose-Headers' 'Content-Length';
            
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
        }
EOF
    fi
    
    # Finish HTTP section
    cat >> $INSTALL_DIR/conf/nginx.conf << EOF
    }
    
    include sites-enabled/*.conf;
}

EOF
    
    # Add RTMP configuration
    cat >> $INSTALL_DIR/conf/nginx.conf << EOF
rtmp {
    server {
        listen $RTMP_PORT;
        
        chunk_size 4096;
        
        # Uncomment for multi-worker live streaming
        # rtmp_auto_push on;
        
        application live {
            live on;
            record off;
EOF
    
    # Add HLS configuration if enabled
    if [ "$HLS_ENABLED" = true ]; then
        cat >> $INSTALL_DIR/conf/nginx.conf << EOF
            
            # HLS
            hls on;
            hls_path $INSTALL_DIR/html/hls;
            hls_fragment $HLS_FRAGMENT;
            hls_playlist_length $HLS_PLAYLIST;
            
            # Low latency HLS
EOF
        
        if [ "$LOW_LATENCY" = true ]; then
            cat >> $INSTALL_DIR/conf/nginx.conf << EOF
            hls_sync 100ms;
            hls_fragment_slicing aligned;
EOF
        fi
    fi
    
    # Add recording configuration if enabled
    if [ "$RECORDING_ENABLED" = true ]; then
        cat >> $INSTALL_DIR/conf/nginx.conf << EOF
            
            # Recording
            record all;
            record_path $RECORDING_PATH;
            record_suffix -%Y%m%d-%H%M%S.flv;
            record_unique on;
EOF
    fi
    
    # Finish RTMP configuration
    cat >> $INSTALL_DIR/conf/nginx.conf << EOF
        }
    }
}
EOF
    
    # Create a simple status page
    cat > $INSTALL_DIR/html/index.html << EOF
<!DOCTYPE html>
<html>
<head>
    <title>RTMP Server Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        h1 {
            color: #0066cc;
        }
        .status {
            padding: 10px;
            background-color: #e6f7ff;
            border-left: 4px solid #0066cc;
            margin-bottom: 20px;
        }
        .online {
            color: #2ecc71;
            font-weight: bold;
        }
        pre {
            background-color: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>RTMP Server Status</h1>
        <div class="status">
            Server Status: <span class="online">Online</span>
        </div>
        <h2>Server Information</h2>
        <ul>
            <li><strong>RTMP Port:</strong> $RTMP_PORT</li>
            <li><strong>HLS Enabled:</strong> $HLS_ENABLED</li>
            <li><strong>Low Latency Mode:</strong> $LOW_LATENCY</li>
        </ul>
        <h2>Usage Information</h2>
        <p>To publish a stream:</p>
        <pre>rtmp://$SERVER_NAME:$RTMP_PORT/live/STREAM_KEY</pre>
        
        <p>To play the stream:</p>
        <pre>rtmp://$SERVER_NAME:$RTMP_PORT/live/STREAM_KEY</pre>
        
EOF
    
    if [ "$HLS_ENABLED" = true ]; then
        cat >> $INSTALL_DIR/html/index.html << EOF
        <p>To play the stream via HLS:</p>
        <pre>http://$SERVER_NAME:$HTTP_PORT/hls/STREAM_KEY.m3u8</pre>
EOF
    fi
    
    cat >> $INSTALL_DIR/html/index.html << EOF
        
        <p>Replace STREAM_KEY with your actual stream key.</p>
    </div>
</body>
</html>
EOF
    
    echo "Nginx configured successfully"
}

# Function to create systemd service
create_systemd_service() {
    echo "Creating systemd service..."
    
    cat > /etc/systemd/system/nginx-rtmp.service << EOF
[Unit]
Description=Nginx RTMP Server
After=network.target

[Service]
Type=forking
ExecStart=$INSTALL_DIR/sbin/nginx -c $INSTALL_DIR/conf/nginx.conf
ExecReload=$INSTALL_DIR/sbin/nginx -s reload
ExecStop=$INSTALL_DIR/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    
    if [ "$AUTO_START" = true ]; then
        systemctl enable nginx-rtmp.service
        systemctl start nginx-rtmp.service
        echo "Nginx RTMP service started and enabled on boot"
    else
        echo "Nginx RTMP service created but not started"
    fi
}

# Function to configure firewall
configure_firewall() {
    echo "Configuring firewall..."
    
    # Check if firewalld is installed
    if command -v firewall-cmd &> /dev/null; then
        firewall-cmd --permanent --add-port=$RTMP_PORT/tcp
        firewall-cmd --permanent --add-port=$HTTP_PORT/tcp
        firewall-cmd --reload
        echo "Firewalld configured"
    # Check if ufw is installed
    elif command -v ufw &> /dev/null; then
        ufw allow $RTMP_PORT/tcp
        ufw allow $HTTP_PORT/tcp
        echo "UFW configured"
    else
        echo "No supported firewall detected. Please manually open ports $RTMP_PORT and $HTTP_PORT."
    fi
}

# Function to provide installation summary
installation_summary() {
    echo ""
    echo "========================================="
    echo "RTMP Server Installation Complete!"
    echo "========================================="
    echo "RTMP URL: rtmp://$SERVER_NAME:$RTMP_PORT/live"
    
    if [ "$HLS_ENABLED" = true ]; then
        echo "HLS URL: http://$SERVER_NAME:$HTTP_PORT/hls/STREAM_KEY.m3u8"
    fi
    
    echo ""
    echo "Configuration file: $INSTALL_DIR/conf/nginx.conf"
    echo "Logs directory: $INSTALL_DIR/logs"
    
    if [ "$RECORDING_ENABLED" = true ]; then
        echo "Recordings directory: $RECORDING_PATH"
    fi
    
    # Check service status
    local status=$(systemctl is-active nginx-rtmp.service)
    echo ""
    echo "Service status: $status"
    
    if [ "$status" != "active" ]; then
        echo "To start the service manually, run: systemctl start nginx-rtmp.service"
    fi
    
    echo ""
    echo "To view logs: tail -f $INSTALL_DIR/logs/error.log"
    echo "========================================="
}

# Main execution
detect_os
install_dependencies
install_nginx_rtmp
configure_nginx
create_systemd_service
configure_firewall
installation_summary

exit 0