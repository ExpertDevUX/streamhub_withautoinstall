<?php
/**
 * Stream Manager - Entry Point
 * 
 * This is the main entry point for the Stream Manager PHP application
 */

// Load bootstrap
require_once __DIR__ . '/../app/bootstrap.php';

// Get the request URI
$requestUri = $_SERVER['REQUEST_URI'];

// Remove query string from URI if present
if (($pos = strpos($requestUri, '?')) !== false) {
    $requestUri = substr($requestUri, 0, $pos);
}

// Remove trailing slash except for the root URL
if ($requestUri !== '/' && substr($requestUri, -1) === '/') {
    $requestUri = rtrim($requestUri, '/');
    header('Location: ' . $requestUri);
    exit;
}

// Start buffering to prevent output before headers are sent
ob_start();

// Handle the request using the application router
$app->handleRequest($requestUri);

// Flush the buffer
ob_end_flush();
?>