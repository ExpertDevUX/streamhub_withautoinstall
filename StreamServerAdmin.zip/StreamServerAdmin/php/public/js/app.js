/**
 * Stream Manager Frontend JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });
    
    // Initialize popovers
    const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
    popovers.forEach(popover => {
        new bootstrap.Popover(popover);
    });
    
    // Stream key copy functionality
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const text = this.getAttribute('data-clipboard-text');
            
            navigator.clipboard.writeText(text)
                .then(() => {
                    // Show success feedback
                    const originalHTML = this.innerHTML;
                    this.innerHTML = '<i class="bi bi-check"></i>';
                    setTimeout(() => {
                        this.innerHTML = originalHTML;
                    }, 2000);
                })
                .catch(err => {
                    console.error('Could not copy text: ', err);
                });
        });
    });
    
    // Initialize charts if Chart.js is available and elements exist
    if (typeof Chart !== 'undefined') {
        initializeCharts();
    }
    
    // Stream status live updates
    setupStreamStatusUpdates();
});

/**
 * Initialize charts for dashboard metrics
 */
function initializeCharts() {
    // Viewers chart
    const viewersChartElement = document.getElementById('viewersChart');
    if (viewersChartElement) {
        const viewersData = JSON.parse(viewersChartElement.getAttribute('data-chart'));
        
        new Chart(viewersChartElement.getContext('2d'), {
            type: 'line',
            data: {
                labels: viewersData.labels,
                datasets: [{
                    label: 'Viewers',
                    data: viewersData.data,
                    borderColor: '#4a6cf7',
                    backgroundColor: 'rgba(74, 108, 247, 0.1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Server load chart
    const serverLoadElement = document.getElementById('serverLoadChart');
    if (serverLoadElement) {
        const serverData = JSON.parse(serverLoadElement.getAttribute('data-chart'));
        
        new Chart(serverLoadElement.getContext('2d'), {
            type: 'bar',
            data: {
                labels: serverData.labels,
                datasets: [{
                    label: 'Server Load (%)',
                    data: serverData.data,
                    backgroundColor: serverData.data.map(value => {
                        if (value < 60) return 'rgba(45, 184, 103, 0.7)';
                        if (value < 80) return 'rgba(255, 193, 7, 0.7)';
                        return 'rgba(220, 53, 69, 0.7)';
                    })
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
}

/**
 * Setup WebSocket connection for real-time stream status updates
 */
function setupStreamStatusUpdates() {
    // Check if we're on a page that needs live updates
    const streamList = document.getElementById('streamsList');
    const streamDashboard = document.getElementById('streamDashboard');
    
    if (!streamList && !streamDashboard) {
        return;
    }
    
    // Create WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = function() {
        console.log('WebSocket connection established');
    };
    
    socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            
            // Handle different message types
            switch (data.type) {
                case 'stream_status':
                    updateStreamStatus(data.stream);
                    break;
                case 'viewer_count':
                    updateViewerCount(data.streamId, data.count);
                    break;
                case 'server_status':
                    updateServerStatus(data.server);
                    break;
            }
        } catch (error) {
            console.error('Error processing WebSocket message:', error);
        }
    };
    
    socket.onclose = function() {
        console.log('WebSocket connection closed');
        // Reconnect after a delay
        setTimeout(() => setupStreamStatusUpdates(), 5000);
    };
    
    socket.onerror = function(error) {
        console.error('WebSocket error:', error);
    };
}

/**
 * Update stream status in the UI
 */
function updateStreamStatus(stream) {
    const statusElement = document.querySelector(`.stream-status-${stream.id}`);
    
    if (statusElement) {
        if (stream.status === 'live') {
            statusElement.innerHTML = '<span class="badge bg-success">Live</span>';
        } else {
            statusElement.innerHTML = '<span class="badge bg-secondary">Offline</span>';
        }
    }
}

/**
 * Update viewer count in the UI
 */
function updateViewerCount(streamId, count) {
    const countElement = document.querySelector(`.stream-viewers-${streamId}`);
    
    if (countElement) {
        countElement.textContent = count;
    }
}

/**
 * Update server status in the UI
 */
function updateServerStatus(server) {
    const statusElement = document.querySelector(`.server-status-${server.id}`);
    
    if (statusElement) {
        if (server.status === 'online') {
            statusElement.innerHTML = '<span class="badge bg-success">Online</span>';
        } else {
            statusElement.innerHTML = '<span class="badge bg-danger">Offline</span>';
        }
    }
    
    // Update load bar if exists
    const loadElement = document.querySelector(`.server-load-${server.id}`);
    
    if (loadElement) {
        const loadPercent = (server.current_load / server.capacity) * 100;
        const loadClass = loadPercent < 60 ? 'bg-success' : (loadPercent < 80 ? 'bg-warning' : 'bg-danger');
        
        loadElement.style.width = `${loadPercent}%`;
        loadElement.className = `progress-bar ${loadClass}`;
        loadElement.textContent = `${Math.round(loadPercent)}%`;
    }
}