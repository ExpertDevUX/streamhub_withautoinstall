/**
 * Stream Manager - Main JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    /**
     * Initialize tooltips
     */
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    /**
     * Flash message auto-dismiss
     */
    const flashMessages = document.querySelectorAll('.alert-dismissible');
    flashMessages.forEach(function(alert) {
        setTimeout(function() {
            if (alert && typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    });
    
    /**
     * Stream preview player initialization
     */
    const videoPlayers = document.querySelectorAll('.stream-preview video');
    
    videoPlayers.forEach(function(player) {
        // Check if player has HLS URL data attribute
        if (player.hasAttribute('data-hls-url')) {
            const hlsUrl = player.getAttribute('data-hls-url');
            
            if (hlsUrl) {
                // Load HLS player if available
                if (typeof Hls !== 'undefined') {
                    if (Hls.isSupported()) {
                        const hls = new Hls({
                            maxBufferLength: 30,
                            maxMaxBufferLength: 60
                        });
                        
                        // Check if low latency mode is enabled
                        if (window.LOW_LATENCY_MODE) {
                            hls.config.lowLatencyMode = true;
                            hls.config.liveSyncDuration = 0.5;
                            hls.config.liveMaxLatencyDuration = 5;
                            hls.config.liveDurationInfinity = true;
                        }
                        
                        hls.loadSource(hlsUrl);
                        hls.attachMedia(player);
                        
                        hls.on(Hls.Events.MANIFEST_PARSED, function() {
                            player.muted = true;
                            player.play().catch(function(e) {
                                console.log('Auto-play prevented:', e);
                            });
                        });
                        
                        hls.on(Hls.Events.ERROR, function(event, data) {
                            if (data.fatal) {
                                switch(data.type) {
                                    case Hls.ErrorTypes.NETWORK_ERROR:
                                        console.log('Network error, trying to recover...');
                                        hls.startLoad();
                                        break;
                                    case Hls.ErrorTypes.MEDIA_ERROR:
                                        console.log('Media error, trying to recover...');
                                        hls.recoverMediaError();
                                        break;
                                    default:
                                        // Cannot recover
                                        console.error('Unrecoverable HLS error:', data);
                                        showOfflineMessage(player);
                                        break;
                                }
                            }
                        });
                    } else if (player.canPlayType('application/vnd.apple.mpegurl')) {
                        // Native HLS support (Safari)
                        player.src = hlsUrl;
                        player.addEventListener('loadedmetadata', function() {
                            player.muted = true;
                            player.play().catch(function(e) {
                                console.log('Auto-play prevented:', e);
                            });
                        });
                    }
                }
            }
        }
    });
    
    /**
     * Show offline message for stream
     */
    function showOfflineMessage(player) {
        // Find parent container
        const container = player.closest('.stream-preview');
        
        if (container) {
            // Create offline message if it doesn't exist
            if (!container.querySelector('.offline-message')) {
                const offlineMessage = document.createElement('div');
                offlineMessage.className = 'offline-message';
                offlineMessage.innerHTML = '<i class="bi bi-exclamation-triangle-fill mb-2" style="font-size: 3rem;"></i><h5>Stream Offline</h5><p>This stream is currently offline.</p>';
                container.appendChild(offlineMessage);
            }
            
            // Hide video
            player.style.display = 'none';
        }
    }
    
    /**
     * RTMP server status refresh
     */
    const serverStatusElements = document.querySelectorAll('[data-server-status-refresh]');
    
    serverStatusElements.forEach(function(element) {
        const serverId = element.getAttribute('data-server-id');
        const refreshInterval = parseInt(element.getAttribute('data-refresh-interval') || 30) * 1000;
        
        if (serverId) {
            // Initial check
            checkServerStatus(serverId, element);
            
            // Set up periodic refresh
            setInterval(function() {
                checkServerStatus(serverId, element);
            }, refreshInterval);
        }
    });
    
    /**
     * Check RTMP server status
     */
    function checkServerStatus(serverId, element) {
        fetch('/rtmp/status/' + serverId)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const status = data.status.online ? 'online' : 'offline';
                    const statusClass = status === 'online' ? 'success' : 'danger';
                    
                    // Update status indicator
                    element.className = 'badge bg-' + statusClass;
                    element.textContent = status.charAt(0).toUpperCase() + status.slice(1);
                    
                    // Update parent card if it exists
                    const card = element.closest('.rtmp-card');
                    if (card) {
                        card.className = card.className.replace(/online|offline/g, '') + ' ' + status;
                    }
                    
                    // Update metrics if they exist
                    if (data.status.cpu !== undefined) {
                        const cpuElement = document.querySelector('[data-server-id="' + serverId + '"][data-metric="cpu"]');
                        if (cpuElement) {
                            cpuElement.textContent = data.status.cpu.toFixed(1) + '%';
                        }
                    }
                    
                    if (data.status.memory !== undefined) {
                        const memoryElement = document.querySelector('[data-server-id="' + serverId + '"][data-metric="memory"]');
                        if (memoryElement) {
                            memoryElement.textContent = data.status.memory.toFixed(1) + '%';
                        }
                    }
                    
                    if (data.status.uptime !== undefined) {
                        const uptimeElement = document.querySelector('[data-server-id="' + serverId + '"][data-metric="uptime"]');
                        if (uptimeElement) {
                            uptimeElement.textContent = formatUptime(data.status.uptime);
                        }
                    }
                }
            })
            .catch(error => {
                console.error('Error checking server status:', error);
                
                // Show error state
                element.className = 'badge bg-secondary';
                element.textContent = 'Unknown';
            });
    }
    
    /**
     * Format uptime in seconds to human readable format
     */
    function formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        seconds %= 86400;
        const hours = Math.floor(seconds / 3600);
        seconds %= 3600;
        const minutes = Math.floor(seconds / 60);
        seconds %= 60;
        
        let result = '';
        
        if (days > 0) {
            result += days + 'd ';
        }
        
        if (hours > 0 || days > 0) {
            result += hours + 'h ';
        }
        
        result += minutes + 'm';
        
        return result;
    }
    
    /**
     * Apply interface configuration
     */
    function applyInterfaceConfig() {
        // Dynamic interface elements - handled by CSS classes in layout
        
        // Custom CSS animations for dashboard cards
        const dashboardCards = document.querySelectorAll('.dashboard-card');
        if (dashboardCards.length > 0) {
            // Apply staggered animation delay
            dashboardCards.forEach((card, index) => {
                card.style.animationDelay = (index * 0.1) + 's';
            });
        }
    }
    
    // Apply interface configuration
    applyInterfaceConfig();
});