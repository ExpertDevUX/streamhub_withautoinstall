<?php
/**
 * Stream Manager - PHP Version
 * Main application entry point
 */

// Define root path
define('ROOT_PATH', __DIR__);

// Include bootstrap file
require_once ROOT_PATH . '/app/bootstrap.php';

// Create application instance
$app = new App\Core\Application();

// Start the application
$app->run();