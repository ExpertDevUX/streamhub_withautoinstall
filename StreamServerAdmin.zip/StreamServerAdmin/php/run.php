<?php
/**
 * Development server launcher
 * This script starts a PHP development server for local testing
 */

// Check if running from command line
if (php_sapi_name() !== 'cli') {
    echo "This script must be run from the command line.";
    exit(1);
}

// Function to check if a port is available
function is_port_available($port) {
    // Try to create a socket on the port
    $socket = @fsockopen('localhost', $port, $errno, $errstr, 1);
    
    // If connection was successful, port is in use
    if ($socket) {
        fclose($socket);
        return false;
    }
    
    return true;
}

// Find an available port starting from 8000
$port = 8000;
while (!is_port_available($port) && $port < 9000) {
    $port++;
}

if ($port >= 9000) {
    echo "Error: Could not find an available port between 8000 and 9000.\n";
    exit(1);
}

// Define the document root
$docRoot = __DIR__ . '/public';

// Start the PHP development server
echo "Starting PHP development server on http://0.0.0.0:{$port}\n";
echo "Document root: {$docRoot}\n";
echo "Press Ctrl+C to stop the server\n";

// Try to use shell_exec if available
if (function_exists('shell_exec') && !in_array('shell_exec', array_map('trim', explode(',', ini_get('disable_functions'))))) {
    // Start server in background
    shell_exec("php -S 0.0.0.0:{$port} -t {$docRoot} " . __DIR__ . "/router.php > /dev/null 2>&1 &");
    echo "Server started. Access at http://localhost:{$port}\n";
} else {
    // Alternative method if shell_exec is not available
    echo "The shell_exec() function is not available. Please start the server manually with the following command:\n\n";
    echo "php -S 0.0.0.0:{$port} -t {$docRoot} " . __DIR__ . "/router.php\n\n";
    echo "Or use your hosting control panel to configure the web server.\n";
}

// If in shared hosting, provide instructions for .htaccess configuration
echo "\n";
echo "If you're running on shared hosting, make sure you have a .htaccess file in your public directory with:\n";
echo "\n";
echo "RewriteEngine On\n";
echo "RewriteBase /\n";
echo "RewriteCond %{REQUEST_FILENAME} !-f\n";
echo "RewriteCond %{REQUEST_FILENAME} !-d\n";
echo "RewriteRule ^(.*)$ index.php [QSA,L]\n";
?>