import { DashboardLayout } from "@/components/dashboard/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Server, Save, AlertCircle, UploadCloud } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Define server configuration schema
const serverConfigSchema = z.object({
  name: z.string().min(1, "Server name is required"),
  host: z.string().min(1, "Host is required"),
  port: z.coerce.number().int().min(1, "Port must be a positive number"),
  rtmpPort: z.coerce.number().int().min(1, "RTMP port must be a positive number"),
  httpPort: z.coerce.number().int().min(1, "HTTP port must be a positive number"),
  chunkSize: z.coerce.number().int().min(1000, "Chunk size must be at least 1000"),
  gopCache: z.boolean(),
  pingInterval: z.coerce.number().int().min(1, "Ping interval must be a positive number"),
  pingTimeout: z.coerce.number().int().min(1, "Ping timeout must be a positive number"),
  allowOrigin: z.string().default("*"),
  sslKey: z.string().optional(),
  sslCert: z.string().optional(),
  customConfig: z.string().optional()
});

type ServerConfigFormValues = z.infer<typeof serverConfigSchema>;

export default function ServerConfigPage() {
  const { toast } = useToast();
  const [sslEnabled, setSslEnabled] = useState(false);
  const [advancedMode, setAdvancedMode] = useState(false);

  // Fetch server configuration
  const { data: serverConfig, isLoading } = useQuery({
    queryKey: ["/api/servers/1"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/servers/1");
        const data = await res.json();
        return {
          name: data.name || "Default RTMP Server",
          host: data.host || "localhost",
          port: data.port || 1935,
          rtmpPort: data.config?.rtmp?.port || 1935,
          httpPort: data.config?.http?.port || 8000,
          chunkSize: data.config?.rtmp?.chunk_size || 60000,
          gopCache: data.config?.rtmp?.gop_cache || true,
          pingInterval: data.config?.rtmp?.ping || 30,
          pingTimeout: data.config?.rtmp?.ping_timeout || 60,
          allowOrigin: data.config?.http?.allow_origin || "*",
          sslKey: data.config?.http?.ssl?.key || "",
          sslCert: data.config?.http?.ssl?.cert || "",
          customConfig: JSON.stringify(data.config, null, 2)
        };
      } catch (error) {
        console.error("Error fetching server config:", error);
        return {
          name: "Default RTMP Server",
          host: "localhost",
          port: 1935,
          rtmpPort: 1935,
          httpPort: 8000,
          chunkSize: 60000,
          gopCache: true,
          pingInterval: 30,
          pingTimeout: 60,
          allowOrigin: "*",
          sslKey: "",
          sslCert: "",
          customConfig: ""
        };
      }
    }
  });

  // Setup form with default values
  const form = useForm<ServerConfigFormValues>({
    resolver: zodResolver(serverConfigSchema),
    defaultValues: {
      name: "",
      host: "",
      port: 1935,
      rtmpPort: 1935,
      httpPort: 8000,
      chunkSize: 60000,
      gopCache: true,
      pingInterval: 30,
      pingTimeout: 60,
      allowOrigin: "*",
      sslKey: "",
      sslCert: "",
      customConfig: ""
    },
    values: serverConfig
  });

  // Update server configuration
  const updateServerMutation = useMutation({
    mutationFn: async (data: ServerConfigFormValues) => {
      // Convert form data to server config format
      const config = advancedMode 
        ? JSON.parse(data.customConfig || "{}") 
        : {
            rtmp: {
              port: data.rtmpPort,
              chunk_size: data.chunkSize,
              gop_cache: data.gopCache,
              ping: data.pingInterval,
              ping_timeout: data.pingTimeout
            },
            http: {
              port: data.httpPort,
              allow_origin: data.allowOrigin,
              ...(sslEnabled && data.sslKey && data.sslCert ? {
                ssl: {
                  key: data.sslKey,
                  cert: data.sslCert
                }
              } : {})
            }
          };

      // Send request to update server
      const res = await apiRequest("PATCH", `/api/servers/1`, {
        name: data.name,
        host: data.host,
        port: data.port,
        config
      });
      
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Server Configuration Updated",
        description: "The server settings have been saved successfully"
      });
      
      // Refresh server data
      queryClient.invalidateQueries({ queryKey: ["/api/servers/1"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to save server configuration: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Handle form submission
  const onSubmit = (data: ServerConfigFormValues) => {
    updateServerMutation.mutate(data);
  };

  // Toggle SSL configuration visibility
  const toggleSsl = () => {
    setSslEnabled(!sslEnabled);
  };

  // Toggle advanced configuration mode
  const toggleAdvancedMode = () => {
    if (!advancedMode && serverConfig) {
      // When switching to advanced mode, update the custom config with current settings
      form.setValue("customConfig", JSON.stringify(serverConfig, null, 2));
    }
    setAdvancedMode(!advancedMode);
  };

  return (
    <DashboardLayout title="Server Configuration">
      <div className="container mx-auto py-6">
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl flex items-center">
                <Server className="mr-2 h-5 w-5 text-primary" />
                RTMP Server Configuration
              </CardTitle>
              <CardDescription>
                Configure your RTMP server settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-6">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <Tabs defaultValue="basic" className="w-full">
                      <TabsList className="mb-4">
                        <TabsTrigger value="basic">Basic Settings</TabsTrigger>
                        <TabsTrigger value="rtmp">RTMP Settings</TabsTrigger>
                        <TabsTrigger value="http">HTTP Settings</TabsTrigger>
                        <TabsTrigger value="advanced">Advanced</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="basic" className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Server Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter server name" {...field} />
                                </FormControl>
                                <FormDescription>A descriptive name for this RTMP server</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="host"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Host</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter hostname or IP" {...field} />
                                </FormControl>
                                <FormDescription>Hostname or IP address for the server</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="port"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Default Port</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="1935" {...field} />
                                </FormControl>
                                <FormDescription>Default port for the server</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="rtmp" className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="rtmpPort"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>RTMP Port</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="1935" {...field} />
                                </FormControl>
                                <FormDescription>Port for RTMP connections</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="chunkSize"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Chunk Size</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="60000" {...field} />
                                </FormControl>
                                <FormDescription>Size of data chunks in bytes</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="gopCache"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={field.onChange}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>
                                    Enable GOP Cache
                                  </FormLabel>
                                  <FormDescription>
                                    Cache video frames for smoother playback
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="pingInterval"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Ping Interval</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="30" {...field} />
                                </FormControl>
                                <FormDescription>Ping interval in seconds</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="pingTimeout"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Ping Timeout</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="60" {...field} />
                                </FormControl>
                                <FormDescription>Ping timeout in seconds</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="http" className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="httpPort"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>HTTP Port</FormLabel>
                                <FormControl>
                                  <Input type="number" placeholder="8000" {...field} />
                                </FormControl>
                                <FormDescription>Port for HTTP server</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="allowOrigin"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Allow Origin</FormLabel>
                                <FormControl>
                                  <Input placeholder="*" {...field} />
                                </FormControl>
                                <FormDescription>CORS Allow-Origin header value</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="mt-4">
                          <Button type="button" variant="outline" onClick={toggleSsl}>
                            {sslEnabled ? "Disable SSL" : "Enable SSL"}
                          </Button>
                        </div>
                        
                        {sslEnabled && (
                          <div className="space-y-4 mt-4 border p-4 rounded-md">
                            <Alert>
                              <AlertCircle className="h-4 w-4" />
                              <AlertTitle>SSL Configuration</AlertTitle>
                              <AlertDescription>
                                Enter the paths to your SSL key and certificate files
                              </AlertDescription>
                            </Alert>
                            
                            <FormField
                              control={form.control}
                              name="sslKey"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>SSL Key Path</FormLabel>
                                  <FormControl>
                                    <Input placeholder="/path/to/key.pem" {...field} />
                                  </FormControl>
                                  <FormDescription>Path to SSL private key file</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="sslCert"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>SSL Certificate Path</FormLabel>
                                  <FormControl>
                                    <Input placeholder="/path/to/cert.pem" {...field} />
                                  </FormControl>
                                  <FormDescription>Path to SSL certificate file</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        )}
                      </TabsContent>
                      
                      <TabsContent value="advanced" className="space-y-4">
                        <Alert>
                          <AlertCircle className="h-4 w-4" />
                          <AlertTitle>Advanced Configuration</AlertTitle>
                          <AlertDescription>
                            Edit the JSON configuration directly. Be careful as invalid JSON will cause errors.
                          </AlertDescription>
                        </Alert>
                        
                        <FormField
                          control={form.control}
                          name="customConfig"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Custom Configuration (JSON)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  className="font-mono h-80" 
                                  placeholder="{}" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>Custom JSON configuration for advanced users</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TabsContent>
                    </Tabs>
                    
                    <div className="flex justify-end space-x-4">
                      <Button type="button" variant="outline" onClick={toggleAdvancedMode}>
                        {advancedMode ? "Use Standard Mode" : "Use Advanced Mode"}
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={updateServerMutation.isPending}
                        className="flex items-center"
                      >
                        {updateServerMutation.isPending ? (
                          <>
                            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Configuration
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}