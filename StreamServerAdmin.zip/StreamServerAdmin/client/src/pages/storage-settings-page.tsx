import { DashboardLayout } from "@/components/dashboard/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  HardDrive, 
  Save, 
  Database, 
  Info, 
  Trash2, 
  FileLock2, 
  Upload, 
  Clock,
  RefreshCw,
  Server,
  FileDown,
  CalendarDays,
  ListFilter,
  Download
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Define storage settings schema
const storageSettingsSchema = z.object({
  storagePath: z.string().min(1, "Storage path is required"),
  maxStorageSize: z.coerce.number().positive("Max storage size must be positive"),
  backupPath: z.string().optional(),
  autoBackupEnabled: z.boolean().default(false),
  autoBackupInterval: z.coerce.number().min(1, "Backup interval must be at least 1 hour"),
  encryptionEnabled: z.boolean().default(false),
  encryptionKey: z.string().optional(),
});

type StorageSettingsFormValues = z.infer<typeof storageSettingsSchema>;

// Define the backup file type
type BackupFile = {
  filename: string;
  timestamp: Date;
  size: number; // MB
  downloadUrl: string;
};

export default function StorageSettingsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [usedStorage, setUsedStorage] = useState(0);
  const [totalStorage, setTotalStorage] = useState(1000);
  const [storagePercent, setStoragePercent] = useState(0);
  const [lastBackupDate, setLastBackupDate] = useState<Date | null>(null);
  const [isBackupInProgress, setIsBackupInProgress] = useState(false);
  const [openConfirmDialog, setOpenConfirmDialog] = useState(false);
  const [openBackupsDialog, setOpenBackupsDialog] = useState(false);
  const [encryptionEnabled, setEncryptionEnabled] = useState(false);

  // Fetch storage metrics
  const { data: storageMetrics, isLoading: isLoadingMetrics, refetch: refreshStorageMetrics } = useQuery({
    queryKey: ["/api/storage/metrics"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/storage/metrics");
        return await res.json();
      } catch (error) {
        console.error("Error fetching storage metrics:", error);
        return {
          used: 0,
          total: 1000,
          lastBackup: null
        };
      }
    }
  });

  // Fetch storage settings
  const { data: storageSettings, isLoading: isLoadingSettings } = useQuery({
    queryKey: ["/api/storage/settings"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/storage/settings");
        return await res.json();
      } catch (error) {
        console.error("Error fetching storage settings:", error);
        return {
          storagePath: "/data/storage",
          maxStorageSize: 1000,
          backupPath: "/data/backups",
          autoBackupEnabled: false,
          autoBackupInterval: 24,
          encryptionEnabled: false,
          encryptionKey: ""
        };
      }
    }
  });

  // Fetch available backups
  const { data: backups = [], isLoading: isLoadingBackups } = useQuery({
    queryKey: ["/api/storage/backups"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/storage/backups");
        const data = await res.json();
        // Convert timestamps to Date objects
        return data.map((backup: any) => ({
          ...backup,
          timestamp: new Date(backup.timestamp)
        }));
      } catch (error) {
        console.error("Error fetching backups:", error);
        return [];
      }
    }
  });

  // Update storage data when fetched
  useEffect(() => {
    if (storageMetrics) {
      setUsedStorage(storageMetrics.used || 0);
      setTotalStorage(storageMetrics.total || 1000);
      setStoragePercent(Math.round((storageMetrics.used / storageMetrics.total) * 100) || 0);
      setLastBackupDate(storageMetrics.lastBackup ? new Date(storageMetrics.lastBackup) : null);
    }
  }, [storageMetrics]);

  // Update encryption state when settings are fetched
  useEffect(() => {
    if (storageSettings) {
      setEncryptionEnabled(storageSettings.encryptionEnabled || false);
    }
  }, [storageSettings]);

  // Setup form with default values
  const form = useForm<StorageSettingsFormValues>({
    resolver: zodResolver(storageSettingsSchema),
    defaultValues: {
      storagePath: "/data/storage",
      maxStorageSize: 1000,
      backupPath: "/data/backups",
      autoBackupEnabled: false,
      autoBackupInterval: 24,
      encryptionEnabled: false,
      encryptionKey: ""
    },
    values: storageSettings
  });

  // Update storage settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: StorageSettingsFormValues) => {
      const res = await apiRequest("PATCH", "/api/storage/settings", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Storage Settings Updated",
        description: "Your storage settings have been saved successfully"
      });
      
      // Refresh storage data
      queryClient.invalidateQueries({ queryKey: ["/api/storage/settings"] });
      refreshStorageMetrics();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update storage settings: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Create backup mutation
  const createBackupMutation = useMutation({
    mutationFn: async () => {
      setIsBackupInProgress(true);
      const res = await apiRequest("POST", "/api/storage/backup");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Backup Created",
        description: "Storage backup has been created successfully"
      });
      
      // Refresh storage data and backups list
      refreshStorageMetrics();
      queryClient.invalidateQueries({ queryKey: ["/api/storage/backups"] });
      setIsBackupInProgress(false);
      
      // Download the backup if available
      if (data.downloadUrl && data.filename) {
        // Trigger download in browser
        const downloadLink = document.createElement('a');
        downloadLink.href = data.downloadUrl;
        downloadLink.download = data.filename;
        downloadLink.target = '_blank';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        toast({
          title: "Download Started",
          description: `Downloading backup file: ${data.filename}`
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create backup: ${error.message}`,
        variant: "destructive"
      });
      setIsBackupInProgress(false);
    }
  });

  // Clean storage mutation
  const cleanStorageMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/storage/clean");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Storage Cleaned",
        description: `${data.bytesFreed || 0} MB of storage has been freed up`
      });
      
      // Refresh storage data
      refreshStorageMetrics();
      setOpenConfirmDialog(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to clean storage: ${error.message}`,
        variant: "destructive"
      });
      setOpenConfirmDialog(false);
    }
  });

  // Handle form submission
  const onSubmit = (data: StorageSettingsFormValues) => {
    updateSettingsMutation.mutate(data);
  };

  // Handle manual backup
  const handleCreateBackup = () => {
    createBackupMutation.mutate();
  };

  // Handle storage cleanup
  const handleCleanStorage = () => {
    setOpenConfirmDialog(true);
  };

  // Confirm storage cleanup
  const confirmCleanStorage = () => {
    cleanStorageMutation.mutate();
  };

  // Format storage size
  const formatSize = (sizeInMB: number): string => {
    if (sizeInMB < 1000) {
      return `${sizeInMB} MB`;
    } else {
      return `${(sizeInMB / 1000).toFixed(2)} GB`;
    }
  };

  // Format date
  const formatDate = (date: Date): string => {
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <DashboardLayout title="Storage Management">
      <div className="container mx-auto py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Storage Overview */}
          <div className="lg:col-span-4">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <HardDrive className="mr-2 h-5 w-5 text-primary" />
                  Storage Overview
                </CardTitle>
                <CardDescription>
                  Monitor your storage usage and backups
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingMetrics ? (
                  <div className="flex justify-center py-6">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Storage Usage</span>
                        <span className="text-sm font-medium">{storagePercent}%</span>
                      </div>
                      <Progress value={storagePercent} className="h-2.5" />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Used: {formatSize(usedStorage)}</span>
                        <span>Total: {formatSize(totalStorage)}</span>
                      </div>
                    </div>

                    <div className="space-y-4 mt-6">
                      <div className="flex items-center justify-between border-b pb-2">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm font-medium">Last Backup</span>
                        </div>
                        <div>
                          {lastBackupDate ? (
                            <span className="text-sm">{formatDate(lastBackupDate)}</span>
                          ) : (
                            <Badge variant="outline">Never</Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-b pb-2 cursor-pointer" onClick={() => setOpenBackupsDialog(true)}>
                        <div className="flex items-center">
                          <Database className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm font-medium">Backups Available</span>
                        </div>
                        <div className="flex items-center">
                          <Badge variant="outline">{backups.length}</Badge>
                          <FileDown className="h-4 w-4 ml-2 text-gray-500" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <FileLock2 className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm font-medium">Encryption Status</span>
                        </div>
                        <div>
                          {encryptionEnabled ? (
                            <Badge className="bg-green-500">Enabled</Badge>
                          ) : (
                            <Badge variant="outline">Disabled</Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 mt-4">
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center justify-center"
                        onClick={handleCreateBackup}
                        disabled={isBackupInProgress}
                      >
                        {isBackupInProgress ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Creating Backup...
                          </>
                        ) : (
                          <>
                            <Upload className="mr-2 h-4 w-4" />
                            Create Backup Now
                          </>
                        )}
                      </Button>
                      
                      <Button 
                        variant="outline"
                        className="w-full flex items-center justify-center" 
                        onClick={handleCleanStorage}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Clean Old Files
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Storage Settings */}
          <div className="lg:col-span-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <Server className="mr-2 h-5 w-5 text-primary" />
                  Storage Settings
                </CardTitle>
                <CardDescription>
                  Configure storage options, backups, and security
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingSettings ? (
                  <div className="flex justify-center py-6">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                  </div>
                ) : (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <Tabs defaultValue="general" className="w-full">
                        <TabsList className="mb-4">
                          <TabsTrigger value="general">General</TabsTrigger>
                          <TabsTrigger value="backup">Backup</TabsTrigger>
                          <TabsTrigger value="security">Security</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="general" className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="storagePath"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Storage Path</FormLabel>
                                  <FormControl>
                                    <Input placeholder="/data/storage" {...field} />
                                  </FormControl>
                                  <FormDescription>Directory where files are stored</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="maxStorageSize"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Max Storage Size (MB)</FormLabel>
                                  <FormControl>
                                    <Input type="number" placeholder="1000" {...field} />
                                  </FormControl>
                                  <FormDescription>Maximum storage capacity in MB</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <Alert>
                            <Info className="h-4 w-4" />
                            <AlertTitle>Storage Management</AlertTitle>
                            <AlertDescription>
                              <p>For any storage issues or support, please contact us at:</p>
                              <p className="font-medium mt-1">info@hwosecurity.org</p>
                              <p className="text-xs mt-2">System by HWO_Administrator</p>
                            </AlertDescription>
                          </Alert>
                        </TabsContent>
                        
                        <TabsContent value="backup" className="space-y-4">
                          <FormField
                            control={form.control}
                            name="backupPath"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Backup Path</FormLabel>
                                <FormControl>
                                  <Input placeholder="/data/backups" {...field} />
                                </FormControl>
                                <FormDescription>Directory where backups are stored</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="autoBackupEnabled"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                  <FormControl>
                                    <input
                                      type="checkbox"
                                      checked={field.value}
                                      onChange={field.onChange}
                                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <div className="space-y-1 leading-none">
                                    <FormLabel>
                                      Enable Automatic Backups
                                    </FormLabel>
                                    <FormDescription>
                                      Regularly create backup copies of your data
                                    </FormDescription>
                                  </div>
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="autoBackupInterval"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Backup Interval (hours)</FormLabel>
                                  <FormControl>
                                    <Input type="number" placeholder="24" {...field} />
                                  </FormControl>
                                  <FormDescription>How often to create backups</FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="flex items-center gap-4 mt-4 p-4 rounded-md border bg-muted/10">
                            <div className="flex-1">
                              <h4 className="text-sm font-medium mb-1">Manage Backups</h4>
                              <p className="text-xs text-muted-foreground">
                                View, download, or create new backups of your data
                              </p>
                            </div>
                            <Button 
                              variant="outline"
                              size="sm"
                              onClick={() => setOpenBackupsDialog(true)}
                              className="flex items-center"
                            >
                              <Database className="mr-2 h-4 w-4" />
                              View {backups.length} Backups
                            </Button>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="security" className="space-y-4">
                          <FormField
                            control={form.control}
                            name="encryptionEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={(e) => {
                                      field.onChange(e);
                                      setEncryptionEnabled(e.target.checked);
                                    }}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>
                                    Enable Data Encryption
                                  </FormLabel>
                                  <FormDescription>
                                    Encrypt stored data for enhanced security
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                          
                          {encryptionEnabled && (
                            <FormField
                              control={form.control}
                              name="encryptionKey"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Encryption Key</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Enter encryption key" 
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormDescription>
                                    Strong encryption key for securing your data. Store this safely!
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          <Alert>
                            <FileLock2 className="h-4 w-4" />
                            <AlertTitle>Security Information</AlertTitle>
                            <AlertDescription>
                              <p className="mb-1">
                                Data encryption uses AES-256-GCM algorithm for strong protection.
                              </p>
                              <p className="mb-1">
                                Keep your encryption key safe. If lost, encrypted data cannot be recovered.
                              </p>
                              <p className="text-xs font-medium mt-2">
                                Code encryption implemented by HWO Security Team
                              </p>
                            </AlertDescription>
                          </Alert>
                        </TabsContent>
                      </Tabs>
                      
                      <div className="flex justify-end space-x-4 mt-6">
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => refreshStorageMetrics()}
                        >
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Refresh
                        </Button>
                        <Button 
                          type="submit" 
                          disabled={updateSettingsMutation.isPending}
                          className="flex items-center"
                        >
                          {updateSettingsMutation.isPending ? (
                            <>
                              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Save Settings
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Backups Dialog */}
      <Dialog open={openBackupsDialog} onOpenChange={setOpenBackupsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Database className="mr-2 h-5 w-5" />
              Available Backups
            </DialogTitle>
            <DialogDescription>
              Download or manage your storage backup files
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {isLoadingBackups ? (
              <div className="flex justify-center py-6">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : backups.length === 0 ? (
              <div className="text-center py-10 border rounded-md bg-muted/20">
                <Database className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                <p className="text-muted-foreground">No backups available</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={handleCreateBackup}
                  disabled={isBackupInProgress}
                >
                  {isBackupInProgress ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Creating Backup...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Create First Backup
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <div className="border rounded-md overflow-hidden">
                <div className="bg-muted/20 p-3 border-b flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <ListFilter className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{backups.length} Backup Files</span>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="h-8"
                    onClick={() => {
                      queryClient.invalidateQueries({ queryKey: ["/api/storage/backups"] });
                    }}
                  >
                    <RefreshCw className="h-3.5 w-3.5 mr-1" />
                    Refresh
                  </Button>
                </div>
                
                <div className="divide-y">
                  {backups.map((backup: BackupFile, index: number) => (
                    <div key={index} className="p-3 flex justify-between items-center hover:bg-muted/10">
                      <div className="flex items-start space-x-3">
                        <FileDown className="h-5 w-5 mt-0.5 text-primary/70" />
                        <div>
                          <p className="font-medium">{backup.filename}</p>
                          <div className="flex items-center mt-1 text-xs text-muted-foreground">
                            <CalendarDays className="h-3 w-3 mr-1" />
                            <span>{formatDate(backup.timestamp)}</span>
                            <span className="mx-2">•</span>
                            <span>{formatSize(backup.size)}</span>
                          </div>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="h-8"
                        onClick={() => {
                          // Download the backup
                          const downloadLink = document.createElement('a');
                          downloadLink.href = backup.downloadUrl;
                          downloadLink.download = backup.filename;
                          downloadLink.target = '_blank';
                          document.body.appendChild(downloadLink);
                          downloadLink.click();
                          document.body.removeChild(downloadLink);
                          
                          toast({
                            title: "Download Started",
                            description: `Downloading backup file: ${backup.filename}`
                          });
                        }}
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter className="flex items-center justify-between">
            <div>
              <span className="text-xs text-muted-foreground">
                Backups are stored in <code>{storageSettings?.backupPath || "/data/backups"}</code>
              </span>
            </div>
            <Button 
              variant="default" 
              onClick={() => setOpenBackupsDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Confirmation Dialog */}
      <Dialog open={openConfirmDialog} onOpenChange={setOpenConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Storage Cleanup</DialogTitle>
            <DialogDescription>
              This will permanently delete temporary and unused files to free up storage space.
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription>
                Only unused temporary files and expired cache will be removed. Your actual data and settings will not be affected.
              </AlertDescription>
            </Alert>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenConfirmDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmCleanStorage}
              disabled={cleanStorageMutation.isPending}
            >
              {cleanStorageMutation.isPending ? "Cleaning..." : "Confirm Cleanup"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}