import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Server } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { 
  Key, 
  UserPlus, 
  RefreshCcw, 
  Settings,
  Loader2 
} from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

export function QuickActions() {
  const { toast } = useToast();
  const [isKeyDialogOpen, setIsKeyDialogOpen] = useState(false);
  const [streamKey, setStreamKey] = useState("");
  
  const { data: servers } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });

  const defaultServer = servers?.[0];
  
  const streamKeyMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/streams/generate-key");
      return await res.json();
    },
    onSuccess: (data) => {
      setStreamKey(data.streamKey);
      setIsKeyDialogOpen(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate stream key",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const restartServerMutation = useMutation({
    mutationFn: async () => {
      if (!defaultServer) throw new Error("No server configured");
      await apiRequest("POST", "/api/admin/rtmp/stop", { serverId: defaultServer.id });
      await new Promise(resolve => setTimeout(resolve, 1000));
      await apiRequest("POST", "/api/admin/rtmp/start", { serverId: defaultServer.id });
    },
    onSuccess: () => {
      toast({
        title: "Server restarted",
        description: "RTMP server has been restarted successfully",
      });
      // Invalidate server status query
      if (defaultServer) {
        queryClient.invalidateQueries({ queryKey: [`/api/rtmp/status/${defaultServer.id}`] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to restart server",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleGenerateKey = () => {
    streamKeyMutation.mutate();
  };
  
  const handleRestartServer = () => {
    restartServerMutation.mutate();
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center p-4 h-auto border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleGenerateKey}
              disabled={streamKeyMutation.isPending}
            >
              {streamKeyMutation.isPending ? (
                <Loader2 className="h-6 w-6 text-primary mb-2 animate-spin" />
              ) : (
                <Key className="h-6 w-6 text-primary mb-2" />
              )}
              <span className="text-sm font-medium">Generate Stream Key</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center p-4 h-auto border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={() => {
                toast({
                  title: "Feature not implemented",
                  description: "User management feature will be available soon",
                });
              }}
            >
              <UserPlus className="h-6 w-6 text-primary mb-2" />
              <span className="text-sm font-medium">Add User</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center p-4 h-auto border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleRestartServer}
              disabled={restartServerMutation.isPending || !defaultServer}
            >
              {restartServerMutation.isPending ? (
                <Loader2 className="h-6 w-6 text-primary mb-2 animate-spin" />
              ) : (
                <RefreshCcw className="h-6 w-6 text-primary mb-2" />
              )}
              <span className="text-sm font-medium">Restart Server</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center p-4 h-auto border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={() => {
                toast({
                  title: "Feature not implemented",
                  description: "Server configuration feature will be available soon",
                });
              }}
            >
              <Settings className="h-6 w-6 text-primary mb-2" />
              <span className="text-sm font-medium">Server Config</span>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={isKeyDialogOpen} onOpenChange={setIsKeyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Stream Key Generated</DialogTitle>
            <DialogDescription>
              Use this key in your streaming software. Keep it secret!
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center space-x-2">
            <Input
              value={streamKey}
              readOnly
              type="text"
              className="font-mono"
            />
            <Button 
              onClick={() => {
                navigator.clipboard.writeText(streamKey);
                toast({
                  title: "Copied to clipboard",
                  description: "Stream key copied to clipboard",
                });
              }}
              variant="secondary"
            >
              Copy
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
