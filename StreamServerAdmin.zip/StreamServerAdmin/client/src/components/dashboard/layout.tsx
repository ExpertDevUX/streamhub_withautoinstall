import { ReactNode, useState, useEffect } from "react";
import { Sidebar } from "./sidebar";
import { TopBar } from "./topbar";
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";

interface DashboardLayoutProps {
  children: ReactNode;
  title: string;
}

export function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const isMobile = useIsMobile();
  const [sidebarVisible, setSidebarVisible] = useState(!isMobile);
  const [location] = useLocation();
  
  // Reset scroll position when location changes
  useEffect(() => {
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
      mainContent.scrollTo({ top: 0, behavior: 'auto' });
    }
  }, [location]);
  
  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <Sidebar className={sidebarVisible ? "" : "w-0"} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar title={title} onMenuToggle={toggleSidebar} />
        
        <main className="flex-1 p-6 overflow-y-auto" id="main-content">
          {children}
        </main>
      </div>
    </div>
  );
}
