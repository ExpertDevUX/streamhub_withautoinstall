#!/bin/bash

# Video Stream Server Manager - Setup Script
# This script helps with the initial setup of the project

# Colors for output formatting
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print messages
print_message() {
  echo -e "${GREEN}[+] $1${NC}"
}

print_warning() {
  echo -e "${YELLOW}[!] $1${NC}"
}

print_error() {
  echo -e "${RED}[-] $1${NC}"
}

print_message "Starting setup for Video Stream Server Manager"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    print_error "npm is not installed. Please install Node.js and npm first."
    exit 1
fi

# Check if node is installed
if ! command -v node &> /dev/null; then
    print_error "Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Install dependencies
print_message "Installing dependencies"
npm install

# Setup environment file if it doesn't exist
if [ ! -f .env ]; then
    print_message "Creating .env file"
    cat > .env << EOF
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/database-name

# Server Configuration
PORT=5000
NODE_ENV=development
SESSION_SECRET=$(openssl rand -hex 32)

# Set this to your domain if you have one
DOMAIN=localhost
EOF

    print_warning "Please edit the .env file with your actual database credentials"
fi

# Make installation scripts executable
chmod +x install.sh
chmod +x aws-install.sh
chmod +x github-prep.sh

print_message "Setup completed!"
print_message "Next steps:"
print_message "1. Edit the .env file with your database credentials"
print_message "2. Run the server with: npm run dev"
print_message "3. Access the application at: http://localhost:5000"
print_message "Default admin credentials:"
print_message "  Username: admin"
print_message "  Password: admin123"
print_warning "Change the default credentials after your first login!"