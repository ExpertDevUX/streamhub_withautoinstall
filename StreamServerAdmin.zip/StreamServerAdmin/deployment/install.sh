#!/bin/bash

# Video Stream Server Manager - Installation Script
# This script automates the installation of RTMP server and its dependencies

echo "====================================================="
echo "  Video Stream Server Manager - Installation Script  "
echo "====================================================="

# Check if script is running with root privileges
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo ./install.sh)"
  exit 1
fi

# Detect OS
if [ -f /etc/os-release ]; then
    # freedesktop.org and systemd
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
elif type lsb_release >/dev/null 2>&1; then
    # linuxbase.org
    OS=$(lsb_release -si)
    VER=$(lsb_release -sr)
else
    # Fall back to uname
    OS=$(uname -s)
    VER=$(uname -r)
fi

# Ensure we're running on a supported OS
if [[ "$OS" != *"Ubuntu"* ]] && [[ "$OS" != *"Debian"* ]]; then
    echo "This script is designed for Ubuntu/Debian systems only"
    echo "Detected OS: $OS $VER"
    exit 1
fi

echo "Detected OS: $OS $VER"

# Determine system resources for installation type recommendation
CORES=$(grep -c ^processor /proc/cpuinfo)
MEMORY=$(grep MemTotal /proc/meminfo | awk '{print $2}')
MEMORY_GB=$(echo "scale=1; $MEMORY/1024/1024" | bc)
DISK_SPACE=$(df -h / | awk 'NR==2 {print $4}' | sed 's/G//')

echo "System Resources:"
echo "- CPU cores: $CORES"
echo "- RAM: ${MEMORY_GB}GB"
echo "- Free disk space: ${DISK_SPACE}GB"

# Function to install dependencies based on OS
install_dependencies() {
    echo "Installing dependencies..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        apt-get update
        apt-get install -y nginx ffmpeg nodejs npm build-essential certbot python3-certbot-nginx
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]] || [[ "$OS" == *"Fedora"* ]]; then
        yum install -y epel-release
        yum update -y
        yum install -y nginx ffmpeg nodejs npm gcc-c++ make certbot python3-certbot-nginx
    else
        echo "Unsupported OS: $OS"
        echo "Please install the following packages manually: nginx, ffmpeg, nodejs, npm, certbot"
        exit 1
    fi
    
    echo "Dependencies installed successfully."
}

# Function to configure standard RTMP server with nginx (full features)
configure_standard_rtmp_server() {
    echo "Configuring standard RTMP server with full features..."
    
    # Make sure the RTMP module is installed first
    if ! dpkg -l | grep -q libnginx-mod-rtmp; then
        echo "Installing NGINX RTMP module..."
        apt-get update
        apt-get install -y libnginx-mod-rtmp
    fi
    
    # Create nginx RTMP configuration (compatible with all NGINX versions)
    cat > /etc/nginx/nginx.conf << 'EOF'
worker_processes auto;

# Load modules
load_module modules/ngx_rtmp_module.so;

events {
    worker_connections 1024;
}

rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        # Increase buffers for better streaming quality
        buflen 5s;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # DASH settings
            dash on;
            dash_path /var/www/html/dash;
            dash_fragment 3;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://localhost:5000/api/auth/stream;
            on_publish_done http://localhost:5000/api/stream/end;
            
            # Advanced transcoding for different qualities
            exec ffmpeg -i rtmp://localhost:1935/$app/$name
                -c:v libx264 -c:a aac -b:a 192k -b:v 6000k -vf "scale=3840:2160" -tune zerolatency -preset veryfast -crf 22 -f flv rtmp://localhost:1935/live/$name_4k
                -c:v libx264 -c:a aac -b:a 128k -b:v 3000k -vf "scale=1920:1080" -tune zerolatency -preset veryfast -crf 22 -f flv rtmp://localhost:1935/live/$name_1080p
                -c:v libx264 -c:a aac -b:a 128k -b:v 1500k -vf "scale=1280:720" -tune zerolatency -preset veryfast -crf 22 -f flv rtmp://localhost:1935/live/$name_720p
                -c:v libx264 -c:a aac -b:a 96k -b:v 800k -vf "scale=854:480" -tune zerolatency -preset veryfast -crf 23 -f flv rtmp://localhost:1935/live/$name_480p
                -c:v libx264 -c:a aac -b:a 64k -b:v 400k -vf "scale=640:360" -tune zerolatency -preset veryfast -crf 23 -f flv rtmp://localhost:1935/live/$name_360p;
        }
        
        application live_low_latency {
            live on;
            record off;
            
            # Low latency HLS
            hls on;
            hls_path /var/www/html/low_latency_hls;
            hls_fragment 1;
            hls_playlist_length 15;
            
            # Authentication
            on_publish http://localhost:5000/api/auth/stream;
            on_publish_done http://localhost:5000/api/stream/end;
        }
        
        application recording {
            live on;
            
            # Record streams to mp4 files
            record all;
            record_path /var/www/html/recordings;
            record_unique on;
            
            # HLS
            hls on;
            hls_path /var/www/html/rec_hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # Authentication
            on_publish http://localhost:5000/api/auth/stream;
            on_publish_done http://localhost:5000/api/stream/end;
            on_record_done http://localhost:5000/api/recording/done;
        }
    }
}

http {
    include mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    
    # Optimize for streaming
    gzip on;
    gzip_min_length 1000;
    gzip_types text/plain text/css application/javascript application/json;
    
    # Increase client body size for large uploads
    client_max_body_size 100m;
    
    server {
        listen 80;
        
        # HLS streaming
        location /hls {
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
            
            # Enable CORS
            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
        }
        
        # Low latency HLS
        location /low_latency_hls {
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # DASH streaming
        location /dash {
            types {
                application/dash+xml mpd;
                video/mp4 mp4;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # Recordings access
        location /recordings {
            root /var/www/html;
            autoindex on;
            autoindex_exact_size off;
            add_header Access-Control-Allow-Origin *;
        }
    }
}
EOF
    
    # Create directories for HLS and recordings
    mkdir -p /var/www/html/hls /var/www/html/dash /var/www/html/recordings /var/www/html/low_latency_hls /var/www/html/rec_hls
    chown -R www-data:www-data /var/www/html
    
    # Restart nginx
    systemctl restart nginx
    
    echo "Standard RTMP server configured successfully."
}

# Function to configure low-resource RTMP server with nginx
configure_low_resource_rtmp_server() {
    echo "Configuring low-resource RTMP server (optimized for VPS)..."
    
    # Make sure the RTMP module is installed first
    if ! dpkg -l | grep -q libnginx-mod-rtmp; then
        echo "Installing NGINX RTMP module..."
        apt-get update
        apt-get install -y libnginx-mod-rtmp
    fi
    
    # Create nginx RTMP configuration optimized for low resources (compatible with all NGINX versions)
    cat > /etc/nginx/nginx.conf << 'EOF'
# Limited to 2 worker processes for low resource environments
worker_processes 2;
# Reduce memory usage
worker_rlimit_nofile 1024;

# Load modules
load_module modules/ngx_rtmp_module.so;

events {
    # Reduce connection limit
    worker_connections 512;
    multi_accept off;
}

rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        # Reduce buffer size for low memory usage
        buflen 3s;
        
        application live {
            live on;
            record off;
            
            # HLS with reduced segments
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 30;
            
            # Authentication
            on_publish http://localhost:5000/api/auth/stream;
            on_publish_done http://localhost:5000/api/stream/end;
            
            # Simplified transcoding with fewer variants (720p and 480p only)
            exec ffmpeg -i rtmp://localhost:1935/$app/$name
                -c:v libx264 -c:a aac -b:a 128k -b:v 1500k -vf "scale=1280:720" -tune zerolatency -preset ultrafast -crf 24 -f flv rtmp://localhost:1935/live/$name_720p
                -c:v libx264 -c:a aac -b:a 96k -b:v 800k -vf "scale=854:480" -tune zerolatency -preset ultrafast -crf 26 -f flv rtmp://localhost:1935/live/$name_480p
                -c:v libx264 -c:a aac -b:a 64k -b:v 400k -vf "scale=640:360" -tune zerolatency -preset ultrafast -crf 28 -f flv rtmp://localhost:1935/live/$name_360p;
        }
        
        # No low latency HLS to save resources
        
        # Simple recording application
        application recording {
            live on;
            
            # Record streams with minimal settings
            record all;
            record_path /var/www/html/recordings;
            record_unique on;
            
            # Authentication
            on_publish http://localhost:5000/api/auth/stream;
            on_publish_done http://localhost:5000/api/stream/end;
        }
    }
}

http {
    include mime.types;
    default_type application/octet-stream;
    sendfile on;
    keepalive_timeout 30; # Reduced from 65
    
    # Disable gzip to save CPU
    gzip off;
    
    # Reduce buffer sizes
    client_body_buffer_size 128k;
    client_header_buffer_size 1k;
    client_max_body_size 10m; # Reduced from 100m
    
    # Set low-resource caching policy
    open_file_cache max=1000 inactive=20s;
    open_file_cache_valid 30s;
    open_file_cache_min_uses 2;
    open_file_cache_errors on;
    
    server {
        listen 80;
        
        # HLS streaming
        location /hls {
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # Recordings access
        location /recordings {
            root /var/www/html;
            autoindex on;
            autoindex_exact_size off;
            add_header Access-Control-Allow-Origin *;
        }
    }
}
EOF
    
    # Create only necessary directories to save space
    mkdir -p /var/www/html/hls /var/www/html/recordings
    chown -R www-data:www-data /var/www/html
    
    # Set up RAM usage limits
    cat > /etc/security/limits.d/nginx.conf << EOF
www-data soft nofile 1024
www-data hard nofile 2048
EOF
    
    # Optimize system for network performance
    cat > /etc/sysctl.d/60-streaming-optimizations.conf << EOF
# Increase system limits for many simultaneous connections
fs.file-max = 65535

# Optimize network settings
net.core.somaxconn = 65535
net.ipv4.tcp_max_tw_buckets = 1440000
net.ipv4.ip_local_port_range = 1024 65000
net.ipv4.tcp_fin_timeout = 15
net.core.netdev_max_backlog = 4096

# Optimize TCP for streaming
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.tcp_window_scaling = 1
EOF
    
    # Apply sysctl settings
    sysctl -p /etc/sysctl.d/60-streaming-optimizations.conf
    
    # Restart nginx
    systemctl restart nginx
    
    echo "Low-resource RTMP server configured successfully."
}

# Generic function to configure RTMP server based on installation type
configure_rtmp_server() {
    local installation_type=$1
    
    if [[ "$installation_type" == "standard" ]]; then
        configure_standard_rtmp_server
    else
        configure_low_resource_rtmp_server
    fi
}

# Function to setup Let's Encrypt SSL certificates
setup_ssl() {
    echo "Would you like to setup HTTPS with Let's Encrypt? (y/n)"
    read -r setup_ssl
    
    if [[ "$setup_ssl" == "y" ]]; then
        echo "Enter your domain name:"
        read -r domain_name
        
        certbot --nginx -d "$domain_name" --non-interactive --agree-tos --email admin@"$domain_name"
        
        echo "SSL certificates installed successfully for $domain_name"
    else
        echo "Skipping SSL setup."
    fi
}

# Function to configure firewall
configure_firewall() {
    echo "Configuring firewall..."
    
    if command -v ufw &>/dev/null; then
        # Ubuntu/Debian
        ufw allow 1935/tcp  # RTMP
        ufw allow 80/tcp    # HTTP
        ufw allow 443/tcp   # HTTPS
        ufw allow 5000/tcp  # API Server
        
        if ! ufw status | grep -q "active"; then
            echo "Enabling UFW firewall..."
            ufw --force enable
        fi
        
        echo "Firewall configured successfully."
    elif command -v firewall-cmd &>/dev/null; then
        # CentOS/RHEL/Fedora
        firewall-cmd --permanent --add-port=1935/tcp  # RTMP
        firewall-cmd --permanent --add-port=80/tcp    # HTTP
        firewall-cmd --permanent --add-port=443/tcp   # HTTPS
        firewall-cmd --permanent --add-port=5000/tcp  # API Server
        firewall-cmd --reload
        
        echo "Firewall configured successfully."
    else
        echo "No supported firewall detected. Please configure your firewall manually to allow ports 1935 (RTMP), 80 (HTTP), 443 (HTTPS), and 5000 (API)."
    fi
}

# Function to create a systemd service for the application
create_systemd_service() {
    echo "Creating systemd service for the application..."
    
    # Create systemd service file
    cat > /etc/systemd/system/stream-manager.service << EOF
[Unit]
Description=Video Stream Server Manager
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/stream-manager
ExecStart=/usr/bin/npm run dev
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable stream-manager.service
    
    echo "Systemd service created successfully."
}

# Function to determine recommended installation type
recommend_installation_type() {
    local recommended_type="standard"
    
    # If fewer than 2 cores or less than 2GB RAM, recommend low-resource
    if [[ "$CORES" -lt 2 ]] || (( $(echo "$MEMORY_GB < 2.0" | bc -l) )); then
        recommended_type="low-resource"
    fi
    
    # If less than 10GB disk space, recommend low-resource
    if (( $(echo "$DISK_SPACE < 10" | bc -l) )); then
        recommended_type="low-resource"
    fi
    
    echo "$recommended_type"
}

# Function to run network performance test
test_network_performance() {
    echo "Testing network performance..."
    
    # Install iperf3 if not already installed
    if ! command -v iperf3 &> /dev/null; then
        if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
            apt-get install -y iperf3
        else
            echo "iperf3 not found and cannot be installed automatically. Skipping network test."
            return
        fi
    fi
    
    # Run iperf test to our test server (replace with your own server if available)
    echo "Running bandwidth test..."
    BANDWIDTH=$(iperf3 -c iperf.he.net -t 3 -J | grep "bits_per_second" | head -n 1 | awk '{print $2}' | sed 's/,//')
    BANDWIDTH_MBPS=$(echo "scale=2; $BANDWIDTH / 1000000" | bc)
    
    echo "Network bandwidth: ${BANDWIDTH_MBPS} Mbps"
    
    # Provide streaming capability recommendation
    if (( $(echo "$BANDWIDTH_MBPS < 5" | bc -l) )); then
        echo "WARNING: Your network bandwidth is below 5 Mbps, which may only support lower quality streams (480p or below)"
        NETWORK_RECOMMENDATION="low-quality"
    elif (( $(echo "$BANDWIDTH_MBPS < 10" | bc -l) )); then
        echo "Your network can handle medium quality streams up to 720p"
        NETWORK_RECOMMENDATION="medium-quality"
    else
        echo "Your network can handle high quality streams including 1080p or higher"
        NETWORK_RECOMMENDATION="high-quality"
    fi
}

# Main installation process
main() {
    install_dependencies
    
    # Determine recommended installation type
    RECOMMENDED_TYPE=$(recommend_installation_type)
    
    # Check if script is running interactively
    if [ -t 0 ]; then
        # Interactive mode
        echo ""
        echo "Based on your system resources, we recommend the '$RECOMMENDED_TYPE' installation."
        echo ""
        echo "Please select installation type:"
        echo "1) Standard installation (full features, recommended for servers with 2+ cores and 2+ GB RAM)"
        echo "2) Low-resource installation (optimized for VPS with limited resources)"
        echo ""
        read -r -p "Enter your choice (1/2) [$RECOMMENDED_TYPE]: " choice
        
        if [[ "$choice" == "1" ]]; then
            INSTALL_TYPE="standard"
        elif [[ "$choice" == "2" ]]; then
            INSTALL_TYPE="low-resource"
        elif [[ -z "$choice" ]]; then
            # Default to recommended type if no selection made
            INSTALL_TYPE="$RECOMMENDED_TYPE"
        else
            echo "Invalid choice. Defaulting to $RECOMMENDED_TYPE installation."
            INSTALL_TYPE="$RECOMMENDED_TYPE"
        fi
    else
        # Non-interactive mode - use recommended type
        echo "Running in non-interactive mode. Using $RECOMMENDED_TYPE installation."
        INSTALL_TYPE="$RECOMMENDED_TYPE"
    fi
    
    echo ""
    echo "Proceeding with $INSTALL_TYPE installation..."
    echo ""
    
    # Optional: Run network performance test
    if [ -t 0 ]; then
        read -r -p "Would you like to run a network performance test? (y/n) [n]: " run_network_test
        if [[ "$run_network_test" == "y" ]]; then
            test_network_performance
        fi
    fi
    
    # Configure RTMP server based on selected installation type
    configure_rtmp_server "$INSTALL_TYPE"
    configure_firewall
    setup_ssl
    create_systemd_service
    
    # Display post-installation instructions
    echo "====================================================="
    echo "  Installation Complete!                            "
    echo "====================================================="
    
    # Detect public IP address (if available)
    PUBLIC_IP=$(curl -s https://api.ipify.org || curl -s https://ipinfo.io/ip || curl -s https://icanhazip.com)
    
    # Use local IP as fallback if public IP detection fails
    if [[ -z "$PUBLIC_IP" ]]; then
        echo "Warning: Could not detect public IP address."
        SERVER_IP=$(hostname -I | awk '{print $1}')
        
        # Check if the IP is a private address
        if [[ "$SERVER_IP" =~ ^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.) ]]; then
            echo "Warning: Server appears to have a private IP address ($SERVER_IP)."
            echo "For public access, you'll need to configure port forwarding or use a public IP address."
        fi
    else
        SERVER_IP="$PUBLIC_IP"
    fi
    
    echo "Server IP detected: ${SERVER_IP}"
    echo ""
    echo "RTMP Server: rtmp://${SERVER_IP}:1935/live"
    echo "HLS URL: http://${SERVER_IP}/hls/stream.m3u8"
    
    if [[ "$INSTALL_TYPE" == "standard" ]]; then
        echo "DASH URL: http://${SERVER_IP}/dash/stream.mpd"
        echo "Low Latency HLS: http://${SERVER_IP}/low_latency_hls/stream.m3u8"
    fi
    
    # Generate random admin password if not already set
    ADMIN_USERNAME="admin"
    if [ -z "$ADMIN_PASSWORD" ]; then
        ADMIN_PASSWORD=$(< /dev/urandom tr -dc A-Za-z0-9 | head -c12)
    fi
    
    # Create config file with initial admin credentials
    CONFIG_DIR="/etc/stream-manager"
    mkdir -p $CONFIG_DIR
    
    cat > $CONFIG_DIR/credentials.conf << EOF
ADMIN_USERNAME=$ADMIN_USERNAME
ADMIN_PASSWORD=$ADMIN_PASSWORD
DASHBOARD_PORT=5000
RTMP_PORT=1935
HTTP_PORT=80
EOF

    chmod 600 $CONFIG_DIR/credentials.conf
    
    # Show dashboard URL and login information
    echo ""
    echo "Video Stream Server Manager Dashboard:"
    echo "http://${SERVER_IP}:5000"
    echo ""
    echo "Default Admin Login:"
    echo "Username: $ADMIN_USERNAME"
    echo "Password: $ADMIN_PASSWORD"
    echo "!! SAVE THIS INFORMATION SECURELY !!"
    
    echo ""
    echo "Dashboard Port: 5000"
    echo "RTMP Port: 1935"
    echo "HTTP Port: 80"
    
    echo ""
    echo "Installation type: $INSTALL_TYPE"
    
    if [[ -n "$NETWORK_RECOMMENDATION" ]]; then
        echo "Network capability: $NETWORK_RECOMMENDATION"
    fi
    
    echo ""
    echo "Required ports for operation:"
    echo "- 1935/tcp: RTMP streaming"
    echo "- 80/tcp: HTTP (web interface & HLS playback)"
    echo "- 443/tcp: HTTPS (secure web interface)"
    echo "- 5000/tcp: API server"
    echo ""
    echo "To start the application:"
    echo "1. Navigate to your application directory"
    echo "2. Run 'npm run dev' or start with systemd: 'systemctl start stream-manager'"
    echo "====================================================="
}

# Run the installation
main

exit 0