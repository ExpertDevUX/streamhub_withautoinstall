/**
 * SSL Module for automatic SSL installation and configuration
 * Uses Let's Encrypt with Certbot for free SSL certificates
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import { log } from './vite';

const execAsync = promisify(exec);

export interface SSLStatus {
  installed: boolean;
  domain: string | null;
  expiryDate: Date | null;
  autoRenewal: boolean;
  lastRenewalAttempt: Date | null;
  certPath: string | null;
  keyPath: string | null;
}

export interface PortInfo {
  port: number;
  service: string;
  required: boolean;
  description: string;
}

/**
 * Check if Certbot is installed
 */
async function isCertbotInstalled(): Promise<boolean> {
  try {
    await execAsync('which certbot');
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Install Certbot if not already installed
 */
async function installCertbot(): Promise<boolean> {
  try {
    log('Installing Certbot...', 'ssl');
    await execAsync('apt-get update');
    await execAsync('apt-get install -y certbot python3-certbot-nginx');
    return true;
  } catch (error) {
    log(`Error installing Certbot: ${error}`, 'ssl');
    return false;
  }
}

/**
 * Check if a domain has valid SSL certificates
 */
async function checkSSLCertificate(domain: string): Promise<boolean> {
  try {
    const { stdout } = await execAsync(`certbot certificates -d ${domain}`);
    return stdout.includes(domain);
  } catch (error) {
    return false;
  }
}

/**
 * Request SSL certificate from Let's Encrypt
 */
async function requestSSLCertificate(domain: string, email: string): Promise<{ success: boolean, message: string }> {
  try {
    log(`Requesting SSL certificate for ${domain}...`, 'ssl');
    
    // Check if Certbot is installed
    if (!await isCertbotInstalled()) {
      log('Certbot not found, installing...', 'ssl');
      const installed = await installCertbot();
      if (!installed) {
        return { success: false, message: 'Failed to install Certbot. Please install it manually.' };
      }
    }
    
    // Request certificate using standalone mode (we'll configure nginx later)
    const { stdout, stderr } = await execAsync(
      `certbot certonly --standalone --non-interactive --agree-tos -m ${email} -d ${domain}`
    );
    
    if (stderr && stderr.includes('error')) {
      return { success: false, message: stderr };
    }
    
    log(`SSL certificate successfully obtained for ${domain}`, 'ssl');
    return { success: true, message: stdout };
  } catch (error) {
    log(`Error requesting SSL certificate: ${error}`, 'ssl');
    return { success: false, message: `Error requesting SSL certificate: ${error}` };
  }
}

/**
 * Configure Nginx with SSL certificates
 */
async function configureNginxSSL(domain: string): Promise<{ success: boolean, message: string }> {
  try {
    log(`Configuring Nginx SSL for ${domain}...`, 'ssl');
    
    // Create Nginx SSL configuration
    const sslConfig = `
server {
    listen 80;
    server_name ${domain};
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name ${domain};

    ssl_certificate /etc/letsencrypt/live/${domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${domain}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';

    # HLS streaming
    location /hls {
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Expose-Headers' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        
        root /var/www;
    }

    # Proxy to the backend Express server
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSockets for real-time metrics
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
`;

    // Write the configuration file
    const configPath = `/etc/nginx/sites-available/${domain}.conf`;
    await fs.writeFile(configPath, sslConfig, 'utf8');
    
    // Create a symlink in sites-enabled
    try {
      await fs.symlink(configPath, `/etc/nginx/sites-enabled/${domain}.conf`);
    } catch (error) {
      // If the symlink already exists, this will throw an error, which is fine
    }
    
    // Test and reload Nginx
    const { stdout: testOutput } = await execAsync('nginx -t');
    if (testOutput.includes('successful')) {
      await execAsync('systemctl reload nginx');
      return { success: true, message: 'Nginx SSL configuration has been applied successfully.' };
    } else {
      return { success: false, message: 'Nginx configuration test failed.' };
    }
  } catch (error) {
    log(`Error configuring Nginx SSL: ${error}`, 'ssl');
    return { success: false, message: `Error configuring Nginx SSL: ${error}` };
  }
}

/**
 * Set up auto-renewal for SSL certificates
 */
async function setupAutoRenewal(): Promise<boolean> {
  try {
    // Create a cron job for certificate renewal
    const cronJob = '0 0 * * * certbot renew --quiet';
    await execAsync(`(crontab -l 2>/dev/null; echo "${cronJob}") | crontab -`);
    
    log('SSL auto-renewal has been set up.', 'ssl');
    return true;
  } catch (error) {
    log(`Error setting up auto-renewal: ${error}`, 'ssl');
    return false;
  }
}

/**
 * Get SSL certificates status
 */
export async function getSSLStatus(domain?: string | null): Promise<SSLStatus> {
  try {
    if (!domain) {
      return {
        installed: false,
        domain: null,
        expiryDate: null,
        autoRenewal: false,
        lastRenewalAttempt: null,
        certPath: null,
        keyPath: null
      };
    }
    
    // Check if certificates exist for this domain
    const certificatesExist = await checkSSLCertificate(domain);
    
    if (!certificatesExist) {
      return {
        installed: false,
        domain,
        expiryDate: null,
        autoRenewal: false,
        lastRenewalAttempt: null,
        certPath: null,
        keyPath: null
      };
    }
    
    // Get certificate expiry date
    const { stdout } = await execAsync(`certbot certificates -d ${domain}`);
    
    // Parse expiry date from output
    const expiryDateMatch = stdout.match(/Expiry Date: ([\d-]+ [\d:]+)/);
    const expiryDate = expiryDateMatch ? new Date(expiryDateMatch[1]) : null;
    
    // Check for auto-renewal by looking at crontab
    const { stdout: crontab } = await execAsync('crontab -l');
    const autoRenewal = crontab.includes('certbot renew');
    
    // Get certificate paths
    const certPath = `/etc/letsencrypt/live/${domain}/fullchain.pem`;
    const keyPath = `/etc/letsencrypt/live/${domain}/privkey.pem`;
    
    return {
      installed: true,
      domain,
      expiryDate,
      autoRenewal,
      lastRenewalAttempt: null, // Would need access to logs to determine this
      certPath,
      keyPath
    };
  } catch (error) {
    log(`Error getting SSL status: ${error}`, 'ssl');
    return {
      installed: false,
      domain: domain || null,
      expiryDate: null,
      autoRenewal: false,
      lastRenewalAttempt: null,
      certPath: null,
      keyPath: null
    };
  }
}

/**
 * Install and configure SSL for a domain
 */
export async function installSSL(domain: string, email: string): Promise<{ success: boolean, message: string, status?: SSLStatus }> {
  try {
    // Check if SSL is already installed
    const currentStatus = await getSSLStatus(domain);
    
    if (currentStatus.installed) {
      return { 
        success: true, 
        message: 'SSL is already installed for this domain.',
        status: currentStatus
      };
    }
    
    // Request SSL certificate
    const requestResult = await requestSSLCertificate(domain, email);
    if (!requestResult.success) {
      return requestResult;
    }
    
    // Configure Nginx with SSL
    const configResult = await configureNginxSSL(domain);
    if (!configResult.success) {
      return configResult;
    }
    
    // Setup auto-renewal
    const renewalSuccess = await setupAutoRenewal();
    
    // Get updated status
    const newStatus = await getSSLStatus(domain);
    
    return {
      success: true,
      message: `SSL successfully installed for ${domain}. Auto-renewal: ${renewalSuccess ? 'Enabled' : 'Failed'}`,
      status: newStatus
    };
  } catch (error) {
    log(`Error installing SSL: ${error}`, 'ssl');
    return { success: false, message: `Error installing SSL: ${error}` };
  }
}

/**
 * Renew SSL certificates
 */
export async function renewSSL(domain: string): Promise<{ success: boolean, message: string, status?: SSLStatus }> {
  try {
    log(`Manually renewing SSL certificate for ${domain}...`, 'ssl');
    const { stdout, stderr } = await execAsync(`certbot renew --force-renewal -d ${domain}`);
    
    if (stderr && stderr.includes('error')) {
      return { success: false, message: stderr };
    }
    
    const newStatus = await getSSLStatus(domain);
    
    return {
      success: true,
      message: `SSL certificate for ${domain} has been renewed.`,
      status: newStatus
    };
  } catch (error) {
    log(`Error renewing SSL: ${error}`, 'ssl');
    return { success: false, message: `Error renewing SSL: ${error}` };
  }
}

/**
 * Get required ports information for the application
 */
export function getRequiredPorts(): PortInfo[] {
  return [
    {
      port: 80,
      service: 'HTTP',
      required: true,
      description: 'Required for initial Let\'s Encrypt verification and HTTP to HTTPS redirection'
    },
    {
      port: 443,
      service: 'HTTPS',
      required: true,
      description: 'Required for secure web traffic'
    },
    {
      port: 1935,
      service: 'RTMP',
      required: true,
      description: 'Required for RTMP streaming from broadcasting software'
    },
    {
      port: 8000,
      service: 'HTTP Media Server',
      required: false,
      description: 'Used for HLS streaming (can be configured to use standard HTTP/HTTPS ports instead)'
    },
    {
      port: 5000,
      service: 'Backend API',
      required: false,
      description: 'Internal use only, should NOT be exposed to the internet'
    }
  ];
}