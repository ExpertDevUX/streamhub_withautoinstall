import { sql } from 'drizzle-orm';
import { db } from './db';

/**
 * This script handles database migrations without interactive prompts
 * It checks for missing columns and adds them if needed
 */
async function migrate() {
  console.log('Starting database migration...');
  
  try {
    // Check if users table exists
    const usersTableExists = await checkTableExists('users');
    if (!usersTableExists) {
      console.log('Users table does not exist, skipping migration');
      return;
    }

    // Migrate user table
    await migrateUserTable();

    // Migrate streams table
    await migrateStreamsTable();

    // Create quality_profiles table if it doesn't exist
    await createQualityProfilesTable();
    
    // Create site_config table if it doesn't exist
    await createSiteConfigTable();

    console.log('Migration completed successfully');
  } catch (err) {
    console.error('Migration failed:', err);
  }
}

async function checkTableExists(tableName: string): Promise<boolean> {
  const result = await db.execute(sql`
    SELECT EXISTS (
      SELECT FROM information_schema.tables 
      WHERE table_name = ${tableName}
    );
  `);
  return result.rows[0]?.exists === true;
}

async function checkColumnExists(tableName: string, columnName: string): Promise<boolean> {
  const result = await db.execute(sql`
    SELECT EXISTS (
      SELECT FROM information_schema.columns 
      WHERE table_name = ${tableName} AND column_name = ${columnName}
    );
  `);
  return result.rows[0]?.exists === true;
}

async function migrateUserTable() {
  console.log('Migrating users table...');
  
  // Check and add logo_url column
  if (!(await checkColumnExists('users', 'logo_url'))) {
    console.log('Adding logo_url column to users table');
    await db.execute(sql`ALTER TABLE users ADD COLUMN logo_url TEXT`);
  }
  
  // Check and add custom_css column
  if (!(await checkColumnExists('users', 'custom_css'))) {
    console.log('Adding custom_css column to users table');
    await db.execute(sql`ALTER TABLE users ADD COLUMN custom_css TEXT`);
  }
  
  // Check and add theme column
  if (!(await checkColumnExists('users', 'theme'))) {
    console.log('Adding theme column to users table');
    await db.execute(sql`ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'default'`);
  }
}

async function migrateStreamsTable() {
  console.log('Migrating streams table...');
  
  // Check for all new stream columns and add them if needed
  const streamColumns = [
    { name: 'is_recording', type: 'BOOLEAN DEFAULT false' },
    { name: 'recording_path', type: 'TEXT' },
    { name: 'has_recordings', type: 'BOOLEAN DEFAULT false' },
    { name: 'enable_webrtc', type: 'BOOLEAN DEFAULT false' },
    { name: 'enable_hls', type: 'BOOLEAN DEFAULT true' },
    { name: 'enable_low_latency', type: 'BOOLEAN DEFAULT false' },
    { name: 'thumbnail_url', type: 'TEXT' },
    { name: 'last_recording_date', type: 'TIMESTAMP' },
    { name: 'description', type: 'TEXT' },
    { name: 'is_public', type: 'BOOLEAN DEFAULT true' },
    { name: 'category', type: 'TEXT' },
    { name: 'tags', type: 'TEXT[]' },
    { name: 'server_id', type: 'INTEGER' }
  ];
  
  for (const column of streamColumns) {
    if (!(await checkColumnExists('streams', column.name))) {
      console.log(`Adding ${column.name} column to streams table`);
      await db.execute(sql.raw(`ALTER TABLE streams ADD COLUMN ${column.name} ${column.type}`));
    }
  }
}

async function createQualityProfilesTable() {
  const tableExists = await checkTableExists('quality_profiles');
  if (!tableExists) {
    console.log('Creating quality_profiles table');
    await db.execute(sql`
      CREATE TABLE quality_profiles (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        video_bitrate INTEGER NOT NULL,
        audio_bitrate INTEGER NOT NULL,
        resolution TEXT NOT NULL,
        framerate INTEGER DEFAULT 30,
        keyframe_interval INTEGER DEFAULT 2,
        preset TEXT DEFAULT 'veryfast',
        profile TEXT DEFAULT 'main',
        is_default BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);
    
    // Create default quality profiles
    await createDefaultQualityProfiles();
  }
}

async function createDefaultQualityProfiles() {
  console.log('Creating default quality profiles');
  
  const defaultProfiles = [
    {
      name: '4K Ultra HD',
      userId: 1, // Admin user
      videoBitrate: 12000,
      audioBitrate: 192,
      resolution: '3840x2160',
      framerate: 60,
      keyframeInterval: 2,
      preset: 'veryfast',
      profile: 'high',
      isDefault: false
    },
    {
      name: '1080p Full HD',
      userId: 1,
      videoBitrate: 6000,
      audioBitrate: 128,
      resolution: '1920x1080',
      framerate: 60,
      keyframeInterval: 2,
      preset: 'veryfast',
      profile: 'main',
      isDefault: true
    },
    {
      name: '720p HD',
      userId: 1,
      videoBitrate: 3000,
      audioBitrate: 128,
      resolution: '1280x720',
      framerate: 60,
      keyframeInterval: 2,
      preset: 'veryfast',
      profile: 'main',
      isDefault: false
    },
    {
      name: '480p SD',
      userId: 1,
      videoBitrate: 1500,
      audioBitrate: 96,
      resolution: '854x480',
      framerate: 30,
      keyframeInterval: 2,
      preset: 'veryfast',
      profile: 'main',
      isDefault: false
    },
    {
      name: '360p Low',
      userId: 1,
      videoBitrate: 800,
      audioBitrate: 64,
      resolution: '640x360',
      framerate: 30,
      keyframeInterval: 2,
      preset: 'veryfast',
      profile: 'main',
      isDefault: false
    }
  ];
  
  for (const profile of defaultProfiles) {
    await db.execute(sql`
      INSERT INTO quality_profiles (
        name, user_id, video_bitrate, audio_bitrate,
        resolution, framerate, keyframe_interval,
        preset, profile, is_default
      ) VALUES (
        ${profile.name}, ${profile.userId}, ${profile.videoBitrate}, ${profile.audioBitrate},
        ${profile.resolution}, ${profile.framerate}, ${profile.keyframeInterval},
        ${profile.preset}, ${profile.profile}, ${profile.isDefault}
      )
    `);
  }
}

async function createSiteConfigTable() {
  const tableExists = await checkTableExists('site_config');
  if (!tableExists) {
    console.log('Creating site_config table');
    await db.execute(sql`
      CREATE TABLE site_config (
        id SERIAL PRIMARY KEY,
        site_name TEXT NOT NULL DEFAULT 'Stream Manager',
        domain TEXT,
        hostname TEXT,
        primary_color TEXT DEFAULT '#3b82f6',
        site_description TEXT DEFAULT 'Video Stream Server Management Platform',
        favicon_url TEXT,
        contact_email TEXT,
        db_name TEXT,
        db_user TEXT,
        db_host TEXT,
        is_configured BOOLEAN DEFAULT false,
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);
    
    // Insert default site configuration
    await createDefaultSiteConfig();
  }
}

async function createDefaultSiteConfig() {
  console.log('Creating default site configuration');
  
  // Get server hostname
  let hostname = '';
  try {
    const hostnameResult = await db.execute(sql`SELECT current_setting('server_version_num')`);
    hostname = `server-${Math.floor(Math.random() * 10000)}.example.com`;
  } catch (err) {
    console.log('Could not determine server hostname, using default');
    hostname = 'localhost';
  }
  
  await db.execute(sql`
    INSERT INTO site_config (
      site_name, domain, hostname, primary_color, 
      site_description, contact_email, is_configured
    ) VALUES (
      'Stream Manager', NULL, ${hostname}, '#3b82f6',
      'Video Stream Server Management Platform', 'admin@example.com', false
    )
  `);
}

export { migrate };

// If this script is executed directly
// Using ESM compatible check to detect if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  migrate()
    .then(() => {
      console.log('Migration script completed');
      process.exit(0);
    })
    .catch((err) => {
      console.error('Migration script failed:', err);
      process.exit(1);
    });
}