#!/bin/bash

# Stream Manager Auto Installation Script
# This script performs complete installation of the Stream Manager application
# including database setup, environment configuration, and RTMP server installation

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to show script usage
usage() {
  echo -e "${BLUE}Stream Manager Auto Installation Script${NC}"
  echo 
  echo "Usage: $0 [options]"
  echo
  echo "Options:"
  echo "  -h, --help                 Show this help message"
  echo "  -d, --db-name NAME         Database name (default: stream_manager)"
  echo "  -u, --db-user USER         Database username (default: stream_admin)"
  echo "  -p, --db-pass PASSWORD     Database password (auto-generated if not provided)"
  echo "  -H, --db-host HOST         Database host (default: localhost)"
  echo "  -P, --db-port PORT         Database port (default: 5432)"
  echo "  -a, --admin-user USER      Admin username (default: admin)"
  echo "  -A, --admin-pass PASSWORD  Admin password (default: auto-generated)"
  echo "  --rtmp-port PORT           RTMP server port (default: 1935)"
  echo "  --http-port PORT           HTTP server port (default: 8000)"
  echo "  --app-port PORT            Application server port (default: 5000)"
  echo "  --low-resource             Configure for low-resource VPS (less than 1GB RAM)"
  echo "  --skip-database            Skip database installation and configuration"
  echo "  --skip-rtmp                Skip RTMP server installation"
  echo "  --skip-node                Skip Node.js application setup"
  echo
  echo "Example:"
  echo "  $0 --db-name mystream --admin-user streamadmin"
  echo
}

# Default values
DB_NAME="stream_manager"
DB_USER="stream_admin"
DB_PASS=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)
DB_HOST="localhost"
DB_PORT="5432"
ADMIN_USER="admin"
ADMIN_PASS=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)
RTMP_PORT="1935"
HTTP_PORT="8000"
APP_PORT="5000"
LOW_RESOURCE=false
SKIP_DB=false
SKIP_RTMP=false
SKIP_NODE=false

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    -h|--help)
      usage
      exit 0
      ;;
    -d|--db-name)
      DB_NAME="$2"
      shift 2
      ;;
    -u|--db-user)
      DB_USER="$2"
      shift 2
      ;;
    -p|--db-pass)
      DB_PASS="$2"
      shift 2
      ;;
    -H|--db-host)
      DB_HOST="$2"
      shift 2
      ;;
    -P|--db-port)
      DB_PORT="$2"
      shift 2
      ;;
    -a|--admin-user)
      ADMIN_USER="$2"
      shift 2
      ;;
    -A|--admin-pass)
      ADMIN_PASS="$2"
      shift 2
      ;;
    --rtmp-port)
      RTMP_PORT="$2"
      shift 2
      ;;
    --http-port)
      HTTP_PORT="$2"
      shift 2
      ;;
    --app-port)
      APP_PORT="$2"
      shift 2
      ;;
    --low-resource)
      LOW_RESOURCE=true
      shift
      ;;
    --skip-database)
      SKIP_DB=true
      shift
      ;;
    --skip-rtmp)
      SKIP_RTMP=true
      shift
      ;;
    --skip-node)
      SKIP_NODE=true
      shift
      ;;
    *)
      echo -e "${RED}Error: Unknown option $1${NC}"
      usage
      exit 1
      ;;
  esac
done

# Function to log installation steps
log() {
  local level=$1
  local message=$2
  case $level in
    "info")
      echo -e "${GREEN}[INFO]${NC} $message"
      ;;
    "warn")
      echo -e "${YELLOW}[WARNING]${NC} $message"
      ;;
    "error")
      echo -e "${RED}[ERROR]${NC} $message"
      ;;
    *)
      echo -e "${BLUE}[LOG]${NC} $message"
      ;;
  esac
}

# Function to check if command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Function to install required system packages
install_system_deps() {
  log "info" "Checking system dependencies..."
  
  # Update package lists
  log "info" "Updating package lists..."
  apt-get update
  
  # Install basic dependencies
  log "info" "Installing basic dependencies..."
  apt-get install -y curl git build-essential openssl libssl-dev
  
  # Check if Node.js is installed
  if ! command_exists node; then
    log "info" "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
  else
    log "info" "Node.js is already installed."
  fi
  
  # Check PostgreSQL installation
  if ! command_exists psql && [ "$SKIP_DB" = "false" ]; then
    log "info" "Installing PostgreSQL..."
    apt-get install -y postgresql postgresql-contrib
    
    # Start PostgreSQL service
    systemctl enable postgresql
    systemctl start postgresql
  elif [ "$SKIP_DB" = "false" ]; then
    log "info" "PostgreSQL is already installed."
  fi
}

# Function to configure database
setup_database() {
  if [ "$SKIP_DB" = "true" ]; then
    log "info" "Skipping database setup as requested."
    return 0
  fi
  
  log "info" "Setting up database..."
  
  # Create database user
  log "info" "Creating database user: $DB_USER"
  sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || \
    log "warn" "User creation failed. User may already exist."
  
  # Check if database exists
  DB_EXISTS=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")
  
  if [ "$DB_EXISTS" != "1" ]; then
    # Create database
    log "info" "Creating database: $DB_NAME"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
  else
    log "info" "Database $DB_NAME already exists."
    # Grant privileges to user if database exists
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
  fi
  
  # Grant privileges
  log "info" "Granting privileges to user $DB_USER on database $DB_NAME"
  sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
  
  # Allow local connections (update pg_hba.conf if needed)
  PG_HBA_CONF=$(sudo -u postgres psql -tAc "SHOW hba_file;")
  if [ -f "$PG_HBA_CONF" ]; then
    log "info" "Updating PostgreSQL authentication configuration..."
    # Backup the original file
    cp "$PG_HBA_CONF" "${PG_HBA_CONF}.bak"
    
    # Add a line for the new user if it doesn't exist
    if ! grep -q "host.*$DB_USER.*md5" "$PG_HBA_CONF"; then
      echo "host    $DB_NAME    $DB_USER    0.0.0.0/0    md5" | sudo tee -a "$PG_HBA_CONF"
    fi
    
    # Reload PostgreSQL configuration
    systemctl reload postgresql
  fi
  
  # Update the DATABASE_URL in .env file
  DATABASE_URL="postgresql://$DB_USER:$DB_PASS@$DB_HOST:$DB_PORT/$DB_NAME"
  
  log "info" "Database setup completed successfully."
  log "info" "Database connection string: $DATABASE_URL"
}

# Function to install and configure RTMP server
install_rtmp_server() {
  if [ "$SKIP_RTMP" = "true" ]; then
    log "info" "Skipping RTMP server installation as requested."
    return 0
  fi
  
  log "info" "Installing RTMP server..."
  
  # Check if Nginx is installed
  if ! command_exists nginx; then
    log "info" "Installing Nginx..."
    apt-get install -y nginx
  else
    log "info" "Nginx is already installed."
  fi
  
  # Install dependencies for building Nginx with RTMP module
  log "info" "Installing build dependencies..."
  apt-get install -y build-essential libpcre3-dev libssl-dev zlib1g-dev
  
  # Create temp directory for building
  BUILD_DIR=$(mktemp -d)
  cd "$BUILD_DIR" || { 
    log "error" "Failed to create build directory"
    return 1
  }
  
  # Download Nginx source
  NGINX_VERSION="1.22.1"
  log "info" "Downloading Nginx source (version $NGINX_VERSION)..."
  wget "http://nginx.org/download/nginx-$NGINX_VERSION.tar.gz"
  tar -xzf "nginx-$NGINX_VERSION.tar.gz"
  
  # Download RTMP module
  log "info" "Downloading RTMP module..."
  git clone https://github.com/arut/nginx-rtmp-module.git
  
  # Configure and build Nginx with RTMP module
  log "info" "Configuring and building Nginx with RTMP module..."
  cd "nginx-$NGINX_VERSION" || {
    log "error" "Failed to enter Nginx source directory"
    return 1
  }
  
  # Apply different configurations based on available resources
  if [ "$LOW_RESOURCE" = "true" ]; then
    log "info" "Configuring for low-resource environment..."
    ./configure \
      --prefix=/usr/share/nginx \
      --sbin-path=/usr/sbin/nginx \
      --conf-path=/etc/nginx/nginx.conf \
      --pid-path=/var/run/nginx.pid \
      --lock-path=/var/lock/nginx.lock \
      --error-log-path=/var/log/nginx/error.log \
      --http-log-path=/var/log/nginx/access.log \
      --with-http_ssl_module \
      --with-http_v2_module \
      --with-http_stub_status_module \
      --with-http_realip_module \
      --with-http_auth_request_module \
      --with-threads \
      --with-stream \
      --with-file-aio \
      --with-stream_ssl_module \
      --add-module=../nginx-rtmp-module \
      --with-cc-opt='-g -O2 -fstack-protector-strong -Wformat -Werror=format-security -fPIC -Wdate-time -D_FORTIFY_SOURCE=2' \
      --with-ld-opt='-Wl,-z,relro -Wl,-z,now -fPIC' \
      --with-pcre
  else
    log "info" "Configuring for standard environment..."
    ./configure \
      --prefix=/usr/share/nginx \
      --sbin-path=/usr/sbin/nginx \
      --conf-path=/etc/nginx/nginx.conf \
      --pid-path=/var/run/nginx.pid \
      --lock-path=/var/lock/nginx.lock \
      --error-log-path=/var/log/nginx/error.log \
      --http-log-path=/var/log/nginx/access.log \
      --with-http_ssl_module \
      --with-http_v2_module \
      --with-http_stub_status_module \
      --with-http_realip_module \
      --with-http_auth_request_module \
      --with-threads \
      --with-stream \
      --with-file-aio \
      --with-stream_ssl_module \
      --add-module=../nginx-rtmp-module \
      --with-cc-opt='-g -O2 -fstack-protector-strong -Wformat -Werror=format-security -fPIC -Wdate-time -D_FORTIFY_SOURCE=2' \
      --with-ld-opt='-Wl,-z,relro -Wl,-z,now -fPIC' \
      --with-pcre
  fi
  
  # Build and install
  log "info" "Building and installing Nginx..."
  make -j$(nproc)
  make install
  
  # Create RTMP configuration
  log "info" "Creating RTMP configuration..."
  RTMP_CONF_FILE="/etc/nginx/conf.d/rtmp.conf"
  
  # Create conf.d directory if it doesn't exist
  mkdir -p /etc/nginx/conf.d/
  
  cat > "$RTMP_CONF_FILE" << EOF
rtmp {
    server {
        listen $RTMP_PORT;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS setup
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # DASH setup
            dash on;
            dash_path /var/www/html/dash;
            dash_fragment 3;
            dash_playlist_length 60;
        }
    }
}
EOF

  # Create HLS and DASH directories
  log "info" "Creating HLS and DASH directories..."
  mkdir -p /var/www/html/hls /var/www/html/dash
  chown -R www-data:www-data /var/www/html/hls /var/www/html/dash
  chmod -R 755 /var/www/html/hls /var/www/html/dash
  
  # Update Nginx main configuration
  log "info" "Updating Nginx main configuration..."
  NGINX_CONF="/etc/nginx/nginx.conf"
  # Backup original config
  cp "$NGINX_CONF" "${NGINX_CONF}.bak"
  
  # Update or create Nginx main config
  cat > "$NGINX_CONF" << EOF
user www-data;
worker_processes auto;
pid /var/run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    gzip on;
    
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
    
    server {
        listen $HTTP_PORT default_server;
        listen [::]:$HTTP_PORT default_server;
        
        root /var/www/html;
        index index.html index.htm;
        
        server_name _;
        
        location / {
            try_files \$uri \$uri/ =404;
        }
        
        location /hls {
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        location /dash {
            types {
                application/dash+xml mpd;
                video/mp4 mp4;
            }
            root /var/www/html;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        location /stat {
            rtmp_stat all;
            rtmp_stat_stylesheet stat.xsl;
            add_header Access-Control-Allow-Origin *;
        }
        
        location /stat.xsl {
            root /var/www/html;
        }
        
        location /control {
            rtmp_control all;
            add_header Access-Control-Allow-Origin *;
        }
    }
}

# Include RTMP configuration
include /etc/nginx/conf.d/rtmp.conf;
EOF

  # Download stat.xsl for RTMP statistics display
  log "info" "Downloading RTMP statistics stylesheet..."
  wget -O /var/www/html/stat.xsl https://raw.githubusercontent.com/arut/nginx-rtmp-module/master/stat.xsl
  
  # Set appropriate permissions
  chown www-data:www-data /var/www/html/stat.xsl
  chmod 644 /var/www/html/stat.xsl
  
  # Verify Nginx configuration
  log "info" "Verifying Nginx configuration..."
  nginx -t
  
  # Enable and start Nginx service
  log "info" "Enabling and starting Nginx service..."
  systemctl enable nginx
  systemctl restart nginx
  
  # Clean up build directory
  cd
  rm -rf "$BUILD_DIR"
  
  log "info" "RTMP server installation completed."
  log "info" "RTMP endpoint: rtmp://your-server-ip:${RTMP_PORT}/live"
  log "info" "HLS endpoint: http://your-server-ip:${HTTP_PORT}/hls"
  log "info" "DASH endpoint: http://your-server-ip:${HTTP_PORT}/dash"
  log "info" "Stats page: http://your-server-ip:${HTTP_PORT}/stat"
}

# Function to set up the Stream Manager application
setup_application() {
  if [ "$SKIP_NODE" = "true" ]; then
    log "info" "Skipping Node.js application setup as requested."
    return 0
  fi
  
  log "info" "Setting up Stream Manager application..."
  
  # Create application directory if it doesn't exist
  APP_DIR="/opt/stream-manager"
  log "info" "Creating application directory: $APP_DIR"
  mkdir -p "$APP_DIR"
  
  # Clone or copy application files
  if [ -d ".git" ]; then
    log "info" "Using existing repository in current directory..."
    rsync -a --exclude node_modules --exclude .git . "$APP_DIR/"
  else
    log "info" "Copying application files..."
    rsync -a --exclude node_modules . "$APP_DIR/"
  fi
  
  # Install application dependencies
  log "info" "Installing application dependencies..."
  cd "$APP_DIR" || {
    log "error" "Failed to enter application directory"
    return 1
  }
  npm install
  
  # Create or update .env file
  log "info" "Creating environment configuration..."
  cat > "$APP_DIR/.env" << EOF
# Database Configuration
DATABASE_URL="postgresql://$DB_USER:$DB_PASS@$DB_HOST:$DB_PORT/$DB_NAME"

# Application Settings
NODE_ENV=production
PORT=$APP_PORT
SESSION_SECRET="$(openssl rand -base64 32)"

# RTMP Server Configuration
RTMP_PORT=$RTMP_PORT
HTTP_PORT=$HTTP_PORT

# Site Configuration
SITE_NAME="Stream Manager"
SITE_DESCRIPTION="Video Stream Server Management Platform"
PRIMARY_COLOR="#3b82f6"

# Admin User Configuration
ADMIN_USER="$ADMIN_USER"
ADMIN_PASS="$ADMIN_PASS"
EOF
  
  # Initialize database schema
  log "info" "Initializing database schema..."
  npx tsx init-db.ts
  
  # Create systemd service
  log "info" "Creating systemd service for Stream Manager..."
  cat > /etc/systemd/system/stream-manager.service << EOF
[Unit]
Description=Stream Manager Application
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/npm run start
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
  
  # Enable and start service
  log "info" "Enabling and starting Stream Manager service..."
  systemctl daemon-reload
  systemctl enable stream-manager
  systemctl start stream-manager
  
  log "info" "Stream Manager application setup completed."
  log "info" "Application is running at: http://your-server-ip:${APP_PORT}"
  log "info" "Admin login: $ADMIN_USER / $ADMIN_PASS"
}

# Function to check for common issues and fix them
check_and_fix_issues() {
  log "info" "Checking for common issues..."
  
  # Check PostgreSQL service status
  if ! systemctl is-active --quiet postgresql && [ "$SKIP_DB" = "false" ]; then
    log "warn" "PostgreSQL service is not running. Attempting to start..."
    systemctl start postgresql
  fi
  
  # Check Nginx service status
  if ! systemctl is-active --quiet nginx && [ "$SKIP_RTMP" = "false" ]; then
    log "warn" "Nginx service is not running. Attempting to start..."
    systemctl start nginx
  fi
  
  # Check Stream Manager service status
  if ! systemctl is-active --quiet stream-manager && [ "$SKIP_NODE" = "false" ]; then
    log "warn" "Stream Manager service is not running. Attempting to start..."
    systemctl start stream-manager
  fi
  
  # Check for firewall (ufw) and open necessary ports
  if command_exists ufw; then
    log "info" "Checking firewall settings..."
    
    # Check if firewall is active
    if ufw status | grep -q "Status: active"; then
      log "info" "Firewall is active. Ensuring necessary ports are open..."
      
      # Open application port
      if ! ufw status | grep -q "$APP_PORT/tcp"; then
        log "info" "Opening application port: $APP_PORT"
        ufw allow "$APP_PORT/tcp"
      fi
      
      # Open RTMP port if RTMP setup was not skipped
      if [ "$SKIP_RTMP" = "false" ] && ! ufw status | grep -q "$RTMP_PORT/tcp"; then
        log "info" "Opening RTMP port: $RTMP_PORT"
        ufw allow "$RTMP_PORT/tcp"
      fi
      
      # Open HTTP port if RTMP setup was not skipped
      if [ "$SKIP_RTMP" = "false" ] && ! ufw status | grep -q "$HTTP_PORT/tcp"; then
        log "info" "Opening HTTP port: $HTTP_PORT"
        ufw allow "$HTTP_PORT/tcp"
      fi
    else
      log "info" "Firewall is not active. No port configuration needed."
    fi
  fi
  
  # Check disk space
  DISK_SPACE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
  if [ "$DISK_SPACE" -ge 90 ]; then
    log "warn" "Disk space is critically low (${DISK_SPACE}%). Consider freeing up space."
  elif [ "$DISK_SPACE" -ge 80 ]; then
    log "warn" "Disk space is running low (${DISK_SPACE}%)."
  fi
  
  # Check memory usage if in low resource mode
  if [ "$LOW_RESOURCE" = "true" ]; then
    log "info" "Low resource mode is enabled. Checking memory usage..."
    
    # Get available memory in MB
    AVAILABLE_MEM=$(free -m | awk '/^Mem:/{print $7}')
    
    if [ "$AVAILABLE_MEM" -lt 100 ]; then
      log "warn" "System is very low on memory (${AVAILABLE_MEM}MB available). Attempting to free up memory..."
      
      # Clear page cache
      sync; echo 1 > /proc/sys/vm/drop_caches
      
      # Configure swappiness for low memory systems
      echo vm.swappiness=60 > /proc/sys/vm/swappiness
      
      # Reduce Nginx and RTMP worker processes if RTMP was installed
      if [ "$SKIP_RTMP" = "false" ] && [ -f "/etc/nginx/nginx.conf" ]; then
        sed -i 's/worker_processes auto;/worker_processes 1;/' /etc/nginx/nginx.conf
        systemctl restart nginx
      fi
    fi
  fi
  
  log "info" "System check completed."
}

# Main script execution
echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}     Stream Manager Installation Script      ${NC}"
echo -e "${BLUE}==============================================${NC}"

# Record start time
START_TIME=$(date +%s)

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
  log "error" "This script must be run as root"
  exit 1
fi

# Display configuration
log "info" "Installation configuration:"
log "info" "- Database name: $DB_NAME"
log "info" "- Database user: $DB_USER"
log "info" "- Database host: $DB_HOST:$DB_PORT"
log "info" "- Admin user: $ADMIN_USER"
log "info" "- RTMP port: $RTMP_PORT"
log "info" "- HTTP port: $HTTP_PORT"
log "info" "- Application port: $APP_PORT"
log "info" "- Low resource mode: $LOW_RESOURCE"

# Run installation steps
install_system_deps
setup_database
install_rtmp_server
setup_application
check_and_fix_issues

# Calculate elapsed time
END_TIME=$(date +%s)
ELAPSED_TIME=$((END_TIME - START_TIME))
MINUTES=$((ELAPSED_TIME / 60))
SECONDS=$((ELAPSED_TIME % 60))

# Save credentials to a file
CREDS_FILE="stream_manager_credentials.txt"
log "info" "Saving credentials to $CREDS_FILE"
cat > "$CREDS_FILE" << EOF
Stream Manager Installation Credentials
======================================
Date: $(date)

Database Information:
- Name: $DB_NAME
- User: $DB_USER
- Password: $DB_PASS
- Host: $DB_HOST
- Port: $DB_PORT
- URL: postgresql://$DB_USER:$DB_PASS@$DB_HOST:$DB_PORT/$DB_NAME

Admin User:
- Username: $ADMIN_USER
- Password: $ADMIN_PASS

Server Configuration:
- RTMP Port: $RTMP_PORT
- HTTP Port: $HTTP_PORT
- App Port: $APP_PORT

Access Information:
- Web Interface: http://your-server-ip:$APP_PORT
- RTMP Streaming: rtmp://your-server-ip:$RTMP_PORT/live
- Stream Key: [Create in web interface]
- HLS Playback: http://your-server-ip:$HTTP_PORT/hls/[stream-key].m3u8
- DASH Playback: http://your-server-ip:$HTTP_PORT/dash/[stream-key].mpd
- Stats Page: http://your-server-ip:$HTTP_PORT/stat

KEEP THIS FILE SECURE!
EOF

# Secure credentials file
chmod 600 "$CREDS_FILE"

# Final summary
echo -e "${GREEN}==============================================${NC}"
echo -e "${GREEN}       Installation Completed Successfully    ${NC}"
echo -e "${GREEN}==============================================${NC}"
echo
echo -e "🕒 Installation time: ${BLUE}$MINUTES minutes and $SECONDS seconds${NC}"
echo
echo -e "📊 ${YELLOW}Stream Manager is now available at:${NC}"
echo -e "   ${GREEN}http://your-server-ip:$APP_PORT${NC}"
echo
echo -e "🔑 ${YELLOW}Admin login credentials:${NC}"
echo -e "   ${GREEN}Username: $ADMIN_USER${NC}"
echo -e "   ${GREEN}Password: $ADMIN_PASS${NC}"
echo
echo -e "📄 ${YELLOW}Detailed credentials have been saved to:${NC}"
echo -e "   ${GREEN}$CREDS_FILE${NC}"
echo
echo -e "📹 ${YELLOW}RTMP Streaming URL:${NC}"
echo -e "   ${GREEN}rtmp://your-server-ip:$RTMP_PORT/live${NC}"
echo
echo -e "🎥 ${YELLOW}Stream playback URLs:${NC}"
echo -e "   ${GREEN}HLS: http://your-server-ip:$HTTP_PORT/hls/[stream-key].m3u8${NC}"
echo -e "   ${GREEN}DASH: http://your-server-ip:$HTTP_PORT/dash/[stream-key].mpd${NC}"
echo
echo -e "🛠️  ${YELLOW}If you encounter any issues, run:${NC}"
echo -e "   ${GREEN}./quickfix.sh${NC}"
echo
echo -e "${BLUE}==============================================${NC}"