#!/bin/bash

# Stream Manager Quick Fix Script
# This script automatically detects and fixes common issues with Stream Manager installation

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to log messages
log() {
  local level=$1
  local message=$2
  case $level in
    "info")
      echo -e "${GREEN}[INFO]${NC} $message"
      ;;
    "warn")
      echo -e "${YELLOW}[WARNING]${NC} $message"
      ;;
    "error")
      echo -e "${RED}[ERROR]${NC} $message"
      ;;
    "success")
      echo -e "${GREEN}[SUCCESS]${NC} $message"
      ;;
    *)
      echo -e "${BLUE}[LOG]${NC} $message"
      ;;
  esac
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
  log "error" "This script must be run as root"
  echo "Please run: sudo ./quickfix.sh"
  exit 1
fi

# Display banner
echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}      Stream Manager Quick Fix Script         ${NC}"
echo -e "${BLUE}==============================================${NC}"
echo ""
log "info" "Starting system diagnostics..."

# Define paths and configuration values
APP_DIR="/opt/stream-manager"
NGINX_CONF="/etc/nginx/nginx.conf"
RTMP_CONF="/etc/nginx/conf.d/rtmp.conf"
PG_HBA_CONF=$(sudo -u postgres psql -tAc "SHOW hba_file;" 2>/dev/null)
SERVICE_FILE="/etc/systemd/system/stream-manager.service"

# Initialize counters
ISSUES_FOUND=0
ISSUES_FIXED=0

# Get environment variables from .env file if it exists
if [ -f "$APP_DIR/.env" ]; then
  source <(grep -v '^#' "$APP_DIR/.env" | sed -E 's/(.*)=(.*)/export \1="\2"/')
  log "info" "Loaded environment variables from $APP_DIR/.env"
else
  log "warn" "No .env file found at $APP_DIR/.env"
  # Set default values
  DB_NAME=${DB_NAME:-"stream_manager"}
  DB_USER=${DB_USER:-"stream_admin"}
  DB_HOST=${DB_HOST:-"localhost"}
  DB_PORT=${DB_PORT:-"5432"}
  RTMP_PORT=${RTMP_PORT:-"1935"}
  HTTP_PORT=${HTTP_PORT:-"8000"}
  APP_PORT=${APP_PORT:-"5000"}
fi

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Function to check service status
check_service_status() {
  systemctl is-active --quiet "$1"
  return $?
}

# Function to check if a port is in use
is_port_in_use() {
  netstat -tuln | grep -q ":$1 "
  return $?
}

# Function to check if PostgreSQL is installed and running
check_postgresql() {
  log "info" "Checking PostgreSQL installation..."
  
  if ! command_exists psql; then
    log "error" "PostgreSQL is not installed"
    ((ISSUES_FOUND++))
    
    log "info" "Installing PostgreSQL..."
    apt-get update
    apt-get install -y postgresql postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
    
    if check_service_status postgresql; then
      log "success" "PostgreSQL installed and started successfully"
      ((ISSUES_FIXED++))
    else
      log "error" "Failed to install or start PostgreSQL"
    fi
  else
    log "info" "PostgreSQL is installed"
    
    if ! check_service_status postgresql; then
      log "error" "PostgreSQL service is not running"
      ((ISSUES_FOUND++))
      
      log "info" "Starting PostgreSQL service..."
      systemctl start postgresql
      
      if check_service_status postgresql; then
        log "success" "PostgreSQL service started successfully"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to start PostgreSQL service"
      fi
    else
      log "success" "PostgreSQL service is running"
    fi
  fi
}

# Function to check database connection and setup
check_database_connection() {
  log "info" "Checking database connection..."
  
  # Try to connect to the database
  if ! sudo -u postgres psql -c "\l" | grep -q "$DB_NAME"; then
    log "error" "Database '$DB_NAME' does not exist"
    ((ISSUES_FOUND++))
    
    log "info" "Creating database '$DB_NAME'..."
    # Check if the user exists, if not create it
    if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1; then
      log "warn" "Database user '$DB_USER' does not exist"
      # Generate a random password if DB_PASS is not set
      DB_PASS=${DB_PASS:-$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)}
      sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
    fi
    
    # Create the database
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    
    if sudo -u postgres psql -c "\l" | grep -q "$DB_NAME"; then
      log "success" "Database '$DB_NAME' created successfully"
      ((ISSUES_FIXED++))
      
      # Update .env file with new connection details
      if [ -f "$APP_DIR/.env" ]; then
        sed -i "s|DATABASE_URL=.*|DATABASE_URL=\"postgresql://$DB_USER:$DB_PASS@$DB_HOST:$DB_PORT/$DB_NAME\"|g" "$APP_DIR/.env"
        log "info" "Updated DATABASE_URL in .env file"
      fi
    else
      log "error" "Failed to create database '$DB_NAME'"
    fi
  else
    log "success" "Database '$DB_NAME' exists"
    
    # Check if the user has the correct permissions
    OWNER=$(sudo -u postgres psql -tAc "SELECT pg_catalog.pg_get_userbyid(d.datdba) FROM pg_catalog.pg_database d WHERE d.datname = '$DB_NAME';")
    if [ "$(echo $OWNER | xargs)" != "$DB_USER" ]; then
      log "warn" "Database '$DB_NAME' is not owned by '$DB_USER'"
      ((ISSUES_FOUND++))
      
      log "info" "Granting privileges to '$DB_USER'..."
      sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
      log "success" "Privileges granted to '$DB_USER'"
      ((ISSUES_FIXED++))
    fi
  fi
  
  # Check pg_hba.conf for remote connections if needed
  if [ -n "$PG_HBA_CONF" ] && [ "$DB_HOST" != "localhost" ]; then
    if ! grep -q "host.*$DB_NAME.*$DB_USER" "$PG_HBA_CONF"; then
      log "warn" "No remote connection entry for '$DB_USER' in pg_hba.conf"
      ((ISSUES_FOUND++))
      
      log "info" "Adding remote connection entry to pg_hba.conf..."
      echo "host    $DB_NAME    $DB_USER    0.0.0.0/0    md5" | sudo tee -a "$PG_HBA_CONF"
      systemctl reload postgresql
      log "success" "Updated pg_hba.conf and reloaded PostgreSQL"
      ((ISSUES_FIXED++))
    fi
  fi
}

# Function to check if Node.js is installed
check_nodejs() {
  log "info" "Checking Node.js installation..."
  
  if ! command_exists node; then
    log "error" "Node.js is not installed"
    ((ISSUES_FOUND++))
    
    log "info" "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
    
    if command_exists node; then
      log "success" "Node.js installed successfully"
      ((ISSUES_FIXED++))
    else
      log "error" "Failed to install Node.js"
    fi
  else
    NODE_VERSION=$(node -v)
    log "success" "Node.js is installed (version $NODE_VERSION)"
    
    # Check if npm is installed
    if ! command_exists npm; then
      log "error" "npm is not installed"
      ((ISSUES_FOUND++))
      
      log "info" "Installing npm..."
      apt-get install -y npm
      
      if command_exists npm; then
        log "success" "npm installed successfully"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to install npm"
      fi
    else
      NPM_VERSION=$(npm -v)
      log "success" "npm is installed (version $NPM_VERSION)"
    fi
  fi
}

# Function to check NGINX and RTMP module
check_nginx_rtmp() {
  log "info" "Checking NGINX and RTMP module..."
  
  # Check if NGINX is installed
  if ! command_exists nginx; then
    log "error" "NGINX is not installed"
    ((ISSUES_FOUND++))
    
    log "info" "Please run the main installation script to install NGINX with RTMP support"
    log "info" "Example: ./install.sh --skip-database --skip-node"
  else
    log "success" "NGINX is installed"
    
    # Check if NGINX service is running
    if ! check_service_status nginx; then
      log "error" "NGINX service is not running"
      ((ISSUES_FOUND++))
      
      log "info" "Starting NGINX service..."
      systemctl start nginx
      
      if check_service_status nginx; then
        log "success" "NGINX service started successfully"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to start NGINX service"
        
        # Check NGINX configuration for errors
        log "info" "Checking NGINX configuration for errors..."
        NGINX_TEST=$(nginx -t 2>&1)
        
        if echo "$NGINX_TEST" | grep -q "test failed"; then
          log "error" "NGINX configuration has errors:"
          echo "$NGINX_TEST" | grep -i "error"
          
          # Try to fix common NGINX configuration issues
          if echo "$NGINX_TEST" | grep -q "rtmp"; then
            log "warn" "RTMP module might not be installed correctly"
            
            if [ -f "$NGINX_CONF" ] && ! grep -q "rtmp" "$NGINX_CONF"; then
              log "info" "Adding RTMP configuration include to nginx.conf..."
              sed -i '/^http {/i \rtmp {\n    include /etc/nginx/conf.d/rtmp.conf;\n}\n' "$NGINX_CONF"
              systemctl restart nginx
              
              if check_service_status nginx; then
                log "success" "Fixed NGINX configuration and restarted service"
                ((ISSUES_FIXED++))
              fi
            fi
          fi
        fi
      fi
    else
      log "success" "NGINX service is running"
    fi
    
    # Check if RTMP module is loaded
    if [ -f "$RTMP_CONF" ]; then
      log "success" "RTMP configuration file exists"
      
      # Check if RTMP port is in use
      if ! is_port_in_use "$RTMP_PORT"; then
        log "error" "RTMP port $RTMP_PORT is not in use"
        ((ISSUES_FOUND++))
        
        log "info" "Checking RTMP configuration..."
        if grep -q "listen $RTMP_PORT" "$RTMP_CONF"; then
          log "info" "RTMP configuration seems correct, restarting NGINX..."
          systemctl restart nginx
          
          if is_port_in_use "$RTMP_PORT"; then
            log "success" "RTMP port $RTMP_PORT is now in use"
            ((ISSUES_FIXED++))
          else
            log "error" "RTMP module might not be loaded correctly"
          fi
        else
          log "warn" "RTMP port in configuration doesn't match expected port $RTMP_PORT"
          sed -i "s/listen [0-9]\\+;/listen $RTMP_PORT;/" "$RTMP_CONF"
          systemctl restart nginx
          
          if is_port_in_use "$RTMP_PORT"; then
            log "success" "Fixed RTMP port in configuration and restarted NGINX"
            ((ISSUES_FIXED++))
          fi
        fi
      else
        log "success" "RTMP port $RTMP_PORT is in use"
      fi
    else
      log "error" "RTMP configuration file is missing"
      ((ISSUES_FOUND++))
      
      log "info" "Creating RTMP configuration file..."
      mkdir -p /etc/nginx/conf.d/
      
      cat > "$RTMP_CONF" << EOF
rtmp {
    server {
        listen $RTMP_PORT;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS setup
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # DASH setup
            dash on;
            dash_path /var/www/html/dash;
            dash_fragment 3;
            dash_playlist_length 60;
        }
    }
}
EOF
      
      # Create necessary directories
      mkdir -p /var/www/html/hls /var/www/html/dash
      chown -R www-data:www-data /var/www/html/hls /var/www/html/dash
      chmod -R 755 /var/www/html/hls /var/www/html/dash
      
      # Update nginx.conf to include rtmp
      if [ -f "$NGINX_CONF" ]; then
        if ! grep -q "include.*rtmp.conf" "$NGINX_CONF"; then
          echo "include /etc/nginx/conf.d/rtmp.conf;" >> "$NGINX_CONF"
        fi
      fi
      
      systemctl restart nginx
      
      if [ -f "$RTMP_CONF" ] && check_service_status nginx; then
        log "success" "Created RTMP configuration and restarted NGINX"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to create RTMP configuration"
      fi
    fi
  fi
}

# Function to check Stream Manager application
check_stream_manager() {
  log "info" "Checking Stream Manager application..."
  
  # Check if application directory exists
  if [ ! -d "$APP_DIR" ]; then
    log "error" "Stream Manager directory does not exist"
    ((ISSUES_FOUND++))
    
    log "info" "Creating application directory..."
    mkdir -p "$APP_DIR"
    log "info" "Please run the main installation script to set up the application"
    log "info" "Example: ./install.sh --skip-database --skip-rtmp"
  else
    log "success" "Stream Manager directory exists"
    
    # Check package.json
    if [ ! -f "$APP_DIR/package.json" ]; then
      log "error" "package.json is missing in $APP_DIR"
      ((ISSUES_FOUND++))
      
      # Check if we have it in the current directory
      if [ -f "./package.json" ]; then
        log "info" "Copying package.json from current directory..."
        cp "./package.json" "$APP_DIR/"
        log "success" "Copied package.json to $APP_DIR"
        ((ISSUES_FIXED++))
      else
        log "error" "Cannot find package.json to copy"
      fi
    else
      log "success" "package.json exists in $APP_DIR"
    fi
    
    # Check node_modules directory
    if [ ! -d "$APP_DIR/node_modules" ]; then
      log "error" "node_modules directory is missing"
      ((ISSUES_FOUND++))
      
      # Check if package.json exists
      if [ -f "$APP_DIR/package.json" ]; then
        log "info" "Installing dependencies..."
        cd "$APP_DIR" && npm install
        
        if [ -d "$APP_DIR/node_modules" ]; then
          log "success" "Dependencies installed successfully"
          ((ISSUES_FIXED++))
        else
          log "error" "Failed to install dependencies"
        fi
      else
        log "error" "Cannot install dependencies without package.json"
      fi
    else
      log "success" "node_modules directory exists"
    fi
    
    # Check service file
    if [ ! -f "$SERVICE_FILE" ]; then
      log "error" "Stream Manager service file is missing"
      ((ISSUES_FOUND++))
      
      log "info" "Creating service file..."
      cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Stream Manager Application
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/npm run start
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
      
      systemctl daemon-reload
      systemctl enable stream-manager
      
      if [ -f "$SERVICE_FILE" ]; then
        log "success" "Created service file and enabled service"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to create service file"
      fi
    else
      log "success" "Service file exists"
    fi
    
    # Check if service is running
    if ! check_service_status stream-manager; then
      log "error" "Stream Manager service is not running"
      ((ISSUES_FOUND++))
      
      log "info" "Starting Stream Manager service..."
      systemctl start stream-manager
      
      if check_service_status stream-manager; then
        log "success" "Stream Manager service started successfully"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to start Stream Manager service"
        
        # Check service logs for errors
        log "info" "Checking service logs for errors..."
        journalctl -u stream-manager -n 20 --no-pager | grep -i "error" || echo "No specific errors found in logs"
      fi
    else
      log "success" "Stream Manager service is running"
    fi
    
    # Check if application port is in use
    if ! is_port_in_use "$APP_PORT"; then
      log "error" "Application port $APP_PORT is not in use"
      ((ISSUES_FOUND++))
      
      log "info" "Checking if another process is using port $APP_PORT..."
      PROCESS_USING_PORT=$(netstat -tlnp 2>/dev/null | grep ":$APP_PORT" | awk '{print $7}' | cut -d'/' -f1)
      
      if [ -n "$PROCESS_USING_PORT" ]; then
        log "warn" "Port $APP_PORT is being used by process ID $PROCESS_USING_PORT"
        
        # Change the port in .env file
        NEW_APP_PORT=$((APP_PORT + 1))
        log "info" "Changing application port to $NEW_APP_PORT in .env file..."
        
        if [ -f "$APP_DIR/.env" ]; then
          sed -i "s/PORT=.*/PORT=$NEW_APP_PORT/" "$APP_DIR/.env"
          systemctl restart stream-manager
          
          if is_port_in_use "$NEW_APP_PORT"; then
            log "success" "Changed application port to $NEW_APP_PORT and restarted service"
            APP_PORT=$NEW_APP_PORT
            ((ISSUES_FIXED++))
          else
            log "error" "Failed to bind to new port $NEW_APP_PORT"
          fi
        fi
      else
        log "info" "Restarting Stream Manager service..."
        systemctl restart stream-manager
        
        if is_port_in_use "$APP_PORT"; then
          log "success" "Stream Manager is now using port $APP_PORT"
          ((ISSUES_FIXED++))
        else
          log "error" "Stream Manager failed to bind to port $APP_PORT"
        fi
      fi
    else
      log "success" "Application port $APP_PORT is in use"
    fi
  fi
}

# Function to check firewall settings
check_firewall() {
  log "info" "Checking firewall settings..."
  
  # Check if ufw is installed and active
  if command_exists ufw && ufw status | grep -q "Status: active"; then
    log "info" "Firewall (ufw) is active"
    
    # Check if application port is allowed
    if ! ufw status | grep -q "$APP_PORT/tcp"; then
      log "warn" "Application port $APP_PORT is not allowed in firewall"
      ((ISSUES_FOUND++))
      
      log "info" "Opening application port $APP_PORT in firewall..."
      ufw allow "$APP_PORT/tcp"
      
      if ufw status | grep -q "$APP_PORT/tcp"; then
        log "success" "Opened application port $APP_PORT in firewall"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to open application port $APP_PORT in firewall"
      fi
    else
      log "success" "Application port $APP_PORT is allowed in firewall"
    fi
    
    # Check if RTMP port is allowed
    if ! ufw status | grep -q "$RTMP_PORT/tcp"; then
      log "warn" "RTMP port $RTMP_PORT is not allowed in firewall"
      ((ISSUES_FOUND++))
      
      log "info" "Opening RTMP port $RTMP_PORT in firewall..."
      ufw allow "$RTMP_PORT/tcp"
      
      if ufw status | grep -q "$RTMP_PORT/tcp"; then
        log "success" "Opened RTMP port $RTMP_PORT in firewall"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to open RTMP port $RTMP_PORT in firewall"
      fi
    else
      log "success" "RTMP port $RTMP_PORT is allowed in firewall"
    fi
    
    # Check if HTTP port is allowed
    if ! ufw status | grep -q "$HTTP_PORT/tcp"; then
      log "warn" "HTTP port $HTTP_PORT is not allowed in firewall"
      ((ISSUES_FOUND++))
      
      log "info" "Opening HTTP port $HTTP_PORT in firewall..."
      ufw allow "$HTTP_PORT/tcp"
      
      if ufw status | grep -q "$HTTP_PORT/tcp"; then
        log "success" "Opened HTTP port $HTTP_PORT in firewall"
        ((ISSUES_FIXED++))
      else
        log "error" "Failed to open HTTP port $HTTP_PORT in firewall"
      fi
    else
      log "success" "HTTP port $HTTP_PORT is allowed in firewall"
    fi
  else
    log "info" "Firewall (ufw) is not active or not installed"
  fi
}

# Function to perform system maintenance
perform_maintenance() {
  log "info" "Performing system maintenance..."
  
  # Check disk space
  DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
  if [ "$DISK_USAGE" -ge 90 ]; then
    log "error" "Disk space is critically low ($DISK_USAGE%)"
    ((ISSUES_FOUND++))
    
    log "info" "Cleaning up disk space..."
    
    # Clean apt cache
    apt-get clean
    
    # Remove old log files
    find /var/log -type f -name "*.gz" -delete
    find /var/log -type f -name "*.1" -delete
    
    # Truncate large log files
    find /var/log -type f -size +50M -exec truncate -s 5M {} \;
    
    # Check new disk usage
    NEW_DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    log "success" "Disk space cleanup completed. Usage reduced from $DISK_USAGE% to $NEW_DISK_USAGE%"
    ((ISSUES_FIXED++))
  elif [ "$DISK_USAGE" -ge 80 ]; then
    log "warn" "Disk space is running low ($DISK_USAGE%)"
    ((ISSUES_FOUND++))
    
    log "info" "Cleaning up disk space..."
    apt-get clean
    
    # Check new disk usage
    NEW_DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    log "success" "Disk space cleanup completed. Usage reduced from $DISK_USAGE% to $NEW_DISK_USAGE%"
    ((ISSUES_FIXED++))
  else
    log "success" "Disk space usage is acceptable ($DISK_USAGE%)"
  fi
  
  # Check memory usage
  MEM_AVAILABLE=$(free -m | awk '/^Mem:/ {print $7}')
  MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
  MEM_USAGE_PERCENT=$((100 - (MEM_AVAILABLE * 100 / MEM_TOTAL)))
  
  if [ "$MEM_USAGE_PERCENT" -ge 90 ]; then
    log "error" "Memory usage is critically high ($MEM_USAGE_PERCENT%)"
    ((ISSUES_FOUND++))
    
    log "info" "Attempting to free up memory..."
    # Drop page cache
    sync && echo 3 > /proc/sys/vm/drop_caches
    
    # Restart services to free memory
    log "info" "Restarting services to free memory..."
    systemctl restart nginx
    systemctl restart stream-manager
    
    # Check new memory usage
    NEW_MEM_AVAILABLE=$(free -m | awk '/^Mem:/ {print $7}')
    NEW_MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
    NEW_MEM_USAGE_PERCENT=$((100 - (NEW_MEM_AVAILABLE * 100 / NEW_MEM_TOTAL)))
    
    log "success" "Memory cleanup completed. Usage reduced from $MEM_USAGE_PERCENT% to $NEW_MEM_USAGE_PERCENT%"
    ((ISSUES_FIXED++))
  else
    log "success" "Memory usage is acceptable ($MEM_USAGE_PERCENT%)"
  fi
}

# Run diagnostic checks
check_postgresql
check_database_connection
check_nodejs
check_nginx_rtmp
check_stream_manager
check_firewall
perform_maintenance

# Final summary
echo ""
echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}            Diagnostic Summary                ${NC}"
echo -e "${BLUE}==============================================${NC}"
echo ""

if [ "$ISSUES_FOUND" -eq 0 ]; then
  echo -e "${GREEN}No issues were found with your Stream Manager installation!${NC}"
  echo -e "Your system appears to be properly configured and running."
else
  echo -e "Found ${YELLOW}$ISSUES_FOUND${NC} issue(s) and fixed ${GREEN}$ISSUES_FIXED${NC} of them."
  
  if [ "$ISSUES_FOUND" -eq "$ISSUES_FIXED" ]; then
    echo -e "${GREEN}All issues have been successfully resolved!${NC}"
  else
    echo -e "${YELLOW}Some issues could not be fixed automatically.${NC}"
    echo -e "Please review the output above for more details on remaining issues."
  fi
fi

echo ""
echo -e "${BLUE}System Information:${NC}"
echo -e "- PostgreSQL: $(command_exists psql && echo "${GREEN}Installed${NC}" || echo "${RED}Not installed${NC}")"
echo -e "- Node.js: $(command_exists node && echo "${GREEN}Installed${NC} ($(node -v))" || echo "${RED}Not installed${NC}")"
echo -e "- NGINX: $(command_exists nginx && echo "${GREEN}Installed${NC} ($(nginx -v 2>&1 | grep -oP 'nginx/\K[0-9\.]+'))" || echo "${RED}Not installed${NC}")"
echo -e "- Stream Manager Service: $(systemctl is-active --quiet stream-manager && echo "${GREEN}Running${NC}" || echo "${RED}Not running${NC}")"
echo ""
echo -e "${BLUE}Connection Information:${NC}"
echo -e "- Application URL: ${GREEN}http://$(hostname -I | awk '{print $1}'):$APP_PORT${NC}"
echo -e "- RTMP Streaming URL: ${GREEN}rtmp://$(hostname -I | awk '{print $1}'):$RTMP_PORT/live${NC}"
echo -e "- HLS Streaming URL: ${GREEN}http://$(hostname -I | awk '{print $1}'):$HTTP_PORT/hls/[stream-key].m3u8${NC}"
echo -e "- DASH Streaming URL: ${GREEN}http://$(hostname -I | awk '{print $1}'):$HTTP_PORT/dash/[stream-key].mpd${NC}"
echo -e "- RTMP Statistics: ${GREEN}http://$(hostname -I | awk '{print $1}'):$HTTP_PORT/stat${NC}"
echo ""
echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}              Fix Complete                    ${NC}"
echo -e "${BLUE}==============================================${NC}"